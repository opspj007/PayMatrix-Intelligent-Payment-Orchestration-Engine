# PayMatrix Firestore Security Specification

## 1. Data Invariants
1. **Strict Ownership**: Every document under `/users/{userId}/...` belongs exclusively to the verified user whose `request.auth.uid == userId` and `request.auth.token.email_verified == true`.
2. **PII Isolation**: Operator email and identity metadata are stored strictly inside `/users/{userId}/private/profile` with zero public or cross-user read access.
3. **Immutable Ownership & Creation Timestamps**: `userId` / `uid` and `createdAt` can never be reassigned or altered during updates.
4. **Server Timestamp Enforcement**: `createdAt` (on create) and `updatedAt` (on create/update) must equal `request.time`.
5. **Bounded Payloads**: All strings, IDs, and numeric weights/thresholds have strict upper/lower bounds and key allowlists (`hasAll` + `hasOnly`).

## 2. The "Dirty Dozen" Adversarial Payloads
1. **Cross-User Profile Read**: User B attempts `get` on `/users/userA/private/profile` -> `PERMISSION_DENIED`.
2. **Unverified Email Spoof**: Token with `email_verified: false` attempts `create` on `/users/userA/presets/p1` -> `PERMISSION_DENIED`.
3. **Shadow Field Injection**: Create preset with extra field `isAdmin: true` -> `PERMISSION_DENIED`.
4. **Identity Spoofing**: User B creates preset under `/users/userB/presets/p1` with `userId: "userA"` -> `PERMISSION_DENIED`.
5. **Client Timestamp Forgery**: Create preset with `createdAt: Timestamp(2020-01-01)` -> `PERMISSION_DENIED`.
6. **ID Poisoning**: Create preset with ID `../../../etc/passwd` or 200-char ID -> `PERMISSION_DENIED`.
7. **Out-of-Bounds Weight**: Create preset with `successWeight: 99` -> `PERMISSION_DENIED`.
8. **Type Poisoning**: Update preset `fraudThreshold` to `"high"` string -> `PERMISSION_DENIED`.
9. **Immutable Field Mutation**: Update preset attempting to alter `createdAt` or `userId` -> `PERMISSION_DENIED`.
10. **Oversized Summary DoS**: Create investigation note with 50KB `summary` -> `PERMISSION_DENIED`.
11. **Unauthorized List Scraping**: User B attempts `list` on `/users/userA/investigations` -> `PERMISSION_DENIED`.
12. **Unmatched Collection Write**: Attempt write to `/admins/userB` or `/transactions/tx1` -> `PERMISSION_DENIED` (caught by default-deny).
