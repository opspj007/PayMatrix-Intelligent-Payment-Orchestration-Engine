import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity,
  BrainCircuit,
  FileCheck2,
  GitBranch,
  History,
  LogOut,
  Menu,
  Moon,
  Play,
  Send,
  ShieldCheck,
  Sun,
  Webhook,
  X,
} from 'lucide-react';
import { AuditTrailView } from './components/AuditTrailView';
import { DispatchSandboxView } from './components/DispatchSandboxView';
import { GatewaysPolicyView } from './components/GatewaysPolicyView';
import { IntelligenceLabView } from './components/IntelligenceLabView';
import { OverviewView } from './components/OverviewView';
import { ReconciliationView } from './components/ReconciliationView';
import { WebhooksView } from './components/WebhooksView';
import { useAuth } from './context/AuthContext';
import { apiFetch } from './lib/api';
import {
  deleteInvestigationNote,
  deleteRoutingPreset,
  saveInvestigationNote,
  saveRoutingPreset,
  subscribeInvestigations,
  subscribeRoutingPresets,
} from './lib/firebase';
import {
  DashboardData,
  InvestigationNote,
  RoutingPreset,
} from './types/paymatrix';

type NavTab =
  | 'overview'
  | 'dispatch'
  | 'gateways'
  | 'webhooks'
  | 'reconciliation'
  | 'intelligence'
  | 'audit';

const NAV_ITEMS: Array<{ id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'overview', label: 'Overview', icon: Activity },
  { id: 'dispatch', label: 'Payment Sandbox', icon: Send },
  { id: 'gateways', label: 'Gateways & Circuits', icon: GitBranch },
  { id: 'webhooks', label: 'Webhooks & Queue', icon: Webhook },
  { id: 'reconciliation', label: 'Reconciliation', icon: FileCheck2 },
  { id: 'intelligence', label: 'Intelligence Lab', icon: BrainCircuit },
  { id: 'audit', label: 'Audit Trail', icon: History },
];

export default function App() {
  const { user, loading: authLoading, authError, signInWithGoogle, signOutUser, getFreshToken } =
    useAuth();

  const [activeTab, setActiveTab] = useState<NavTab>('overview');
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [dashboard, setDashboard] = useState<DashboardData | null>(null);
  const [loadingData, setLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [wsConnected, setWsConnected] = useState(false);

  const [presets, setPresets] = useState<RoutingPreset[]>([]);
  const [investigations, setInvestigations] = useState<InvestigationNote[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const hasLoadedRef = useRef(false);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
  }, [darkMode]);

  const fetchDashboard = useCallback(async () => {
    const token = await getFreshToken();
    if (!token) return;
    if (!hasLoadedRef.current) {
      setLoadingData(true);
    }
    setDataError(null);
    try {
      const data = await apiFetch<DashboardData>('/api/dashboard', token);
      hasLoadedRef.current = true;
      setDashboard(data);
    } catch (err: any) {
      setDataError(err?.message || 'Failed to load dashboard data.');
    } finally {
      setLoadingData(false);
    }
  }, [getFreshToken]);

  useEffect(() => {
    if (!user) {
      hasLoadedRef.current = false;
      setDashboard(null);
      setPresets([]);
      setInvestigations([]);
      return;
    }

    void fetchDashboard();

    const unsubPresets = subscribeRoutingPresets(user.uid, setPresets, (err) => {
      console.error('Firestore presets error:', err);
    });
    const unsubInvestigations = subscribeInvestigations(user.uid, setInvestigations, (err) => {
      console.error('Firestore investigations error:', err);
    });

    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
    let closedByCleanup = false;

    const connectWs = async () => {
      const token = await getFreshToken();
      if (!token || closedByCleanup) return;
      const proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${proto}//${window.location.host}/ws?token=${encodeURIComponent(token)}`);
      wsRef.current = ws;

      ws.onopen = () => setWsConnected(true);
      ws.onclose = () => {
        setWsConnected(false);
        if (!closedByCleanup) {
          reconnectTimer = setTimeout(() => {
            void connectWs();
          }, 4000);
        }
      };
      ws.onmessage = (msg) => {
        try {
          const parsed = JSON.parse(msg.data);
          if (parsed?.type && parsed.type !== 'ws:connected') {
            void fetchDashboard();
          }
        } catch {
          // Ignore malformed frame
        }
      };
    };

    void connectWs();

    return () => {
      closedByCleanup = true;
      if (reconnectTimer) clearTimeout(reconnectTimer);
      wsRef.current?.close();
      unsubPresets();
      unsubInvestigations();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.uid]);

  const withToken = async <T,>(fn: (token: string) => Promise<T>): Promise<T> => {
    const token = await getFreshToken();
    if (!token) throw new Error('Session expired. Please sign in again.');
    return fn(token);
  };

  const handleDispatch = async (payload: Record<string, unknown>) => {
    const res = await withToken((token) =>
      apiFetch<any>('/api/payments/dispatch', token, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    );
    await fetchDashboard();
    return res;
  };

  const handleRunBurst = async () => {
    setActionLoading('burst');
    try {
      await withToken((token) =>
        apiFetch('/api/payments/burst', token, { method: 'POST', body: JSON.stringify({}) })
      );
      await fetchDashboard();
    } finally {
      setActionLoading(null);
    }
  };

  const handleRunReconciliation = async (gatewayCode = 'ALL', injectDiscrepancy = false) => {
    setActionLoading('reconcile');
    try {
      await withToken((token) =>
        apiFetch('/api/reconciliation/run', token, {
          method: 'POST',
          body: JSON.stringify({ gatewayCode, injectDiscrepancy }),
        })
      );
      await fetchDashboard();
    } finally {
      setActionLoading(null);
    }
  };

  const handleResolveDiscrepancy = async (id: number, resolutionNote: string) => {
    await withToken((token) =>
      apiFetch(`/api/reconciliation/discrepancies/${id}/resolve`, token, {
        method: 'POST',
        body: JSON.stringify({ resolutionNote }),
      })
    );
    await fetchDashboard();
  };

  const handleUpdateGateway = async (code: string, updates: Record<string, unknown>) => {
    await withToken((token) =>
      apiFetch(`/api/gateways/${code}`, token, {
        method: 'PATCH',
        body: JSON.stringify(updates),
      })
    );
    await fetchDashboard();
  };

  const handleUpdatePolicy = async (updates: Record<string, unknown>) => {
    await withToken((token) =>
      apiFetch('/api/policy', token, {
        method: 'PUT',
        body: JSON.stringify(updates),
      })
    );
    await fetchDashboard();
  };

  const handleRetryWebhook = async (id: number) => {
    await withToken((token) =>
      apiFetch(`/api/webhooks/${id}/retry`, token, { method: 'POST', body: JSON.stringify({}) })
    );
    await fetchDashboard();
  };

  const handleSimulateInboundWebhook = async (payload: {
    gatewayCode: string;
    eventType: string;
    tamperSignature: boolean;
    amountCents: number;
  }) => {
    await withToken((token) =>
      apiFetch('/api/webhooks/simulate-inbound', token, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    );
    await fetchDashboard();
  };

  const handleFastFraudTriage = async (transactionId: number) => {
    return withToken((token) =>
      apiFetch<{ model: string; latencyMs: number; analysis: string }>('/api/ai/fraud-triage', token, {
        method: 'POST',
        body: JSON.stringify({ transactionId }),
      })
    );
  };

  const handleDeepDiagnose = async (question: string) => {
    return withToken((token) =>
      apiFetch<{ model: string; thinkingLevel: string; latencyMs: number; analysis: string }>(
        '/api/ai/deep-diagnose',
        token,
        {
          method: 'POST',
          body: JSON.stringify({ question }),
        }
      )
    );
  };

  const handleCreateRule = async (payload: Record<string, unknown>) => {
    await withToken((token) =>
      apiFetch('/api/routing-rules', token, {
        method: 'POST',
        body: JSON.stringify(payload),
      })
    );
    await fetchDashboard();
  };

  const handleToggleRule = async (ruleId: number, isActive: boolean) => {
    await withToken((token) =>
      apiFetch(`/api/routing-rules/${ruleId}`, token, {
        method: 'PATCH',
        body: JSON.stringify({ isActive }),
      })
    );
    await fetchDashboard();
  };

  const handleDeleteRule = async (ruleId: number) => {
    await withToken((token) =>
      apiFetch(`/api/routing-rules/${ruleId}`, token, {
        method: 'DELETE',
      })
    );
    await fetchDashboard();
  };

  const handleSynthesizeRule = async (instruction: string) => {
    return withToken((token) =>
      apiFetch<{
        model: string;
        latencyMs: number;
        rule: {
          name: string;
          conditionCurrency: string;
          conditionMethod: string;
          conditionMinAmountCents: number;
          conditionCountry: string;
          actionType: 'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY';
          targetGatewayCode: string;
          canaryGatewayCode: string | null;
          canaryPct: number;
        };
      }>('/api/ai/synthesize-rule', token, {
        method: 'POST',
        body: JSON.stringify({ instruction }),
      })
    );
  };

  const handleIssueRefund = async (
    transactionId: number,
    amountCents: number,
    reason: string
  ) => {
    await withToken((token) =>
      apiFetch(`/api/payments/${transactionId}/refund`, token, {
        method: 'POST',
        body: JSON.stringify({ amountCents, reason }),
      })
    );
    await fetchDashboard();
  };

  if (authLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-50 dark:bg-slate-950">
        <div className="space-y-3 text-center">
          <div className="mx-auto h-6 w-6 animate-spin rounded-full border-2 border-slate-300 border-t-slate-900 dark:border-slate-700 dark:border-t-slate-100" />
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Initializing PayMatrix Workspace...
          </p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex min-h-screen flex-col bg-slate-50 dark:bg-slate-950">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-6 py-4 dark:border-slate-800 dark:bg-slate-900">
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-slate-50">
            PayMatrix
          </span>
          <button
            type="button"
            onClick={() => setDarkMode((d) => !d)}
            className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            aria-label="Toggle theme"
          >
            {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
        </header>

        <main className="flex flex-1 items-center justify-center px-6 py-12">
          <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 dark:border-slate-800 dark:bg-slate-900">
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400">
              <ShieldCheck className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
              <span>Multi-Gateway Payment Orchestration</span>
            </div>

            <h1 className="mt-3 text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
              Sign in to PayMatrix Control Plane
            </h1>
            <p className="mt-2 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
              Authenticate with Google to access your isolated PostgreSQL payment ledger, live WebSocket event stream, circuit breaker controls, and AI diagnostics.
            </p>

            {authError && (
              <div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300">
                {authError}
              </div>
            )}

            <button
              type="button"
              onClick={() => void signInWithGoogle()}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-sm font-medium text-white transition-colors hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
            >
              <span>Continue with Google</span>
            </button>
          </div>
        </main>
      </div>
    );
  }

  const activeNavLabel = NAV_ITEMS.find((n) => n.id === activeTab)?.label ?? 'Overview';

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 lg:flex">
        <div className="flex h-16 items-center border-b border-slate-200 px-6 dark:border-slate-800">
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 dark:text-slate-50">
            PayMatrix
          </span>
        </div>

        <nav className="flex-1 space-y-1 p-4">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 p-4 dark:border-slate-800">
          <div className="truncate text-xs font-medium text-slate-800 dark:text-slate-200">
            {user.displayName || 'Operator'}
          </div>
          <div className="truncate text-[11px] text-slate-500 dark:text-slate-400">
            {user.email}
          </div>
          <button
            type="button"
            onClick={() => void signOutUser()}
            className="mt-3 flex w-full items-center gap-2 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <LogOut className="h-3.5 w-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex w-64 flex-col border-r border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
            <div className="flex h-16 items-center justify-between border-b border-slate-200 px-6 dark:border-slate-800">
              <span className="font-display text-lg font-bold tracking-tight">PayMatrix</span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-lg p-1 text-slate-500"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 p-4">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex w-full items-center gap-3 rounded-lg px-3 py-2 text-xs font-medium ${
                      active
                        ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="border-t border-slate-200 p-4 dark:border-slate-800">
              <button
                type="button"
                onClick={() => void signOutUser()}
                className="flex w-full items-center gap-2 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium dark:border-slate-700"
              >
                <LogOut className="h-3.5 w-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Viewport */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 items-center justify-between gap-8 border-b border-slate-200 bg-white px-6 dark:border-slate-800 dark:bg-slate-900">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="rounded-lg p-1.5 text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800 lg:hidden"
              aria-label="Open navigation"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap shrink-0">
              <span>PayMatrix</span>
              <span aria-hidden="true">/</span>
              <span className="text-slate-900 dark:text-slate-100">{activeNavLabel}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setDarkMode((d) => !d)}
              className="rounded-lg border border-slate-200 p-2 text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              aria-label="Toggle color theme"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('dispatch')}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white whitespace-nowrap shrink-0"
            >
              <Play className="h-3.5 w-3.5" />
              <span>Dispatch Payment</span>
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 p-6 lg:p-8">
          {dataError && (
            <div className="mb-6 flex items-center justify-between rounded-xl border border-rose-200 bg-rose-50 px-5 py-3 text-xs text-rose-800 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-200">
              <span>{dataError}</span>
              <button
                type="button"
                onClick={() => void fetchDashboard()}
                className="font-medium underline"
              >
                Retry
              </button>
            </div>
          )}

          {loadingData && !dashboard ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
                {[1, 2, 3, 4].map((k) => (
                  <div
                    key={k}
                    className="h-28 animate-pulse rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900"
                  />
                ))}
              </div>
              <div className="h-80 animate-pulse rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900" />
            </div>
          ) : dashboard ? (
            <>
              {activeTab === 'overview' && (
                <OverviewView
                  data={dashboard}
                  wsConnected={wsConnected}
                  onRunBurst={handleRunBurst}
                  onRunReconciliation={() => handleRunReconciliation('ALL', false)}
                  onFastFraudTriage={handleFastFraudTriage}
                  onIssueRefund={handleIssueRefund}
                  onNavigate={(tab) => setActiveTab(tab as NavTab)}
                  actionLoading={actionLoading}
                />
              )}

              {activeTab === 'dispatch' && (
                <DispatchSandboxView
                  gateways={dashboard.gateways}
                  rateLimiter={dashboard.metrics.rateLimiter}
                  onDispatch={handleDispatch}
                  onRefreshDashboard={fetchDashboard}
                />
              )}

              {activeTab === 'gateways' && (
                <GatewaysPolicyView
                  gateways={dashboard.gateways}
                  policy={dashboard.policy}
                  routingRules={dashboard.routingRules ?? []}
                  rateLimiter={dashboard.metrics.rateLimiter}
                  presets={presets}
                  onUpdateGateway={handleUpdateGateway}
                  onUpdatePolicy={handleUpdatePolicy}
                  onCreateRule={handleCreateRule}
                  onToggleRule={handleToggleRule}
                  onDeleteRule={handleDeleteRule}
                  onSynthesizeRule={handleSynthesizeRule}
                  onSavePreset={(preset) => saveRoutingPreset(user.uid, preset)}
                  onDeletePreset={(id) => deleteRoutingPreset(user.uid, id)}
                />
              )}

              {activeTab === 'webhooks' && (
                <WebhooksView
                  gateways={dashboard.gateways}
                  webhooks={dashboard.webhooks}
                  onRetryWebhook={handleRetryWebhook}
                  onSimulateInbound={handleSimulateInboundWebhook}
                />
              )}

              {activeTab === 'reconciliation' && (
                <ReconciliationView
                  gateways={dashboard.gateways}
                  batches={dashboard.reconciliationBatches}
                  discrepancies={dashboard.discrepancies}
                  onRunReconciliation={handleRunReconciliation}
                  onResolveDiscrepancy={handleResolveDiscrepancy}
                />
              )}

              {activeTab === 'intelligence' && (
                <IntelligenceLabView
                  transactions={dashboard.transactions}
                  investigations={investigations}
                  onDeepDiagnose={handleDeepDiagnose}
                  onFastTriage={handleFastFraudTriage}
                  onSaveInvestigation={(note) => saveInvestigationNote(user.uid, note)}
                  onDeleteInvestigation={(id) => deleteInvestigationNote(user.uid, id)}
                />
              )}

              {activeTab === 'audit' && <AuditTrailView logs={dashboard.auditLogs} />}
            </>
          ) : null}
        </main>
      </div>
    </div>
  );
}
