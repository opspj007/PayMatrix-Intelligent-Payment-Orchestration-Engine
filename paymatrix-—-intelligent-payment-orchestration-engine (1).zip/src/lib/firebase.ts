import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, User } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDocFromServer,
  getFirestore,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  where,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { InvestigationNote, RoutingPreset } from '../types/paymatrix';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testFirestoreConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}
void testFirestoreConnection();

const VALID_ID_REGEX = /^[a-zA-Z0-9_-]+$/;

function sanitizeDocId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 64);
  return VALID_ID_REGEX.test(cleaned) && cleaned.length > 0 ? cleaned : `id_${Date.now()}`;
}

export async function syncOperatorProfile(user: User) {
  if (!user.email) return;
  const path = `users/${user.uid}/private/profile`;
  try {
    await setDoc(doc(db, 'users', user.uid, 'private', 'profile'), {
      uid: user.uid,
      email: user.email.slice(0, 256),
      displayName: (user.displayName ?? user.email.split('@')[0]).slice(0, 120),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

function toEpochMs(ts: unknown): number {
  if (ts && typeof ts === 'object' && 'toMillis' in ts && typeof (ts as { toMillis: () => number }).toMillis === 'function') {
    return (ts as { toMillis: () => number }).toMillis();
  }
  return 0;
}

export function subscribeRoutingPresets(
  uid: string,
  onData: (presets: RoutingPreset[]) => void,
  onError?: (err: Error) => void
) {
  const path = `users/${uid}/presets`;
  const q = query(collection(db, 'users', uid, 'presets'), where('userId', '==', uid));

  return onSnapshot(
    q,
    (snap) => {
      const items: RoutingPreset[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<RoutingPreset, 'id'>),
        }))
        .sort((a, b) => toEpochMs(b.updatedAt) - toEpochMs(a.updatedAt));
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (e) {
        if (onError && e instanceof Error) onError(e);
      }
    }
  );
}

export async function saveRoutingPreset(
  uid: string,
  preset: {
    name: string;
    successWeight: number;
    latencyWeight: number;
    costWeight: number;
    fraudThreshold: number;
    maxRetries: number;
  }
) {
  const presetId = sanitizeDocId(`preset_${Date.now()}`);
  const path = `users/${uid}/presets/${presetId}`;
  try {
    await setDoc(doc(db, 'users', uid, 'presets', presetId), {
      userId: uid,
      name: preset.name.trim().slice(0, 80) || 'Custom Policy',
      successWeight: Math.max(0, Math.min(1, Number(preset.successWeight))),
      latencyWeight: Math.max(0, Math.min(1, Number(preset.latencyWeight))),
      costWeight: Math.max(0, Math.min(1, Number(preset.costWeight))),
      fraudThreshold: Math.max(0, Math.min(100, Math.round(preset.fraudThreshold))),
      maxRetries: Math.max(0, Math.min(5, Math.round(preset.maxRetries))),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteRoutingPreset(uid: string, presetId: string) {
  const safeId = sanitizeDocId(presetId);
  const path = `users/${uid}/presets/${safeId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'presets', safeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeInvestigations(
  uid: string,
  onData: (notes: InvestigationNote[]) => void,
  onError?: (err: Error) => void
) {
  const path = `users/${uid}/investigations`;
  const q = query(collection(db, 'users', uid, 'investigations'), where('userId', '==', uid));

  return onSnapshot(
    q,
    (snap) => {
      const items: InvestigationNote[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<InvestigationNote, 'id'>),
        }))
        .sort((a, b) => toEpochMs(b.updatedAt) - toEpochMs(a.updatedAt));
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (e) {
        if (onError && e instanceof Error) onError(e);
      }
    }
  );
}

export async function saveInvestigationNote(
  uid: string,
  note: {
    title: string;
    modelUsed: string;
    txCode?: string;
    summary: string;
  }
) {
  const invId = sanitizeDocId(`inv_${Date.now()}`);
  const path = `users/${uid}/investigations/${invId}`;
  const payload: Record<string, unknown> = {
    userId: uid,
    title: note.title.trim().slice(0, 160) || 'Diagnostic Report',
    modelUsed: note.modelUsed.trim().slice(0, 64),
    summary: note.summary.trim().slice(0, 16000),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
  if (note.txCode && note.txCode.trim().length > 0) {
    payload.txCode = note.txCode.trim().slice(0, 64);
  }

  try {
    await setDoc(doc(db, 'users', uid, 'investigations', invId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function deleteInvestigationNote(uid: string, id: string) {
  const safeId = sanitizeDocId(id);
  const path = `users/${uid}/investigations/${safeId}`;
  try {
    await deleteDoc(doc(db, 'users', uid, 'investigations', safeId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}
