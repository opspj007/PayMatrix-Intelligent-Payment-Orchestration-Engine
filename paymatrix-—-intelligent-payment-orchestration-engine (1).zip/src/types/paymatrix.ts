export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface Gateway {
  id: number;
  code: string;
  name: string;
  region: string;
  baseFeeBps: number;
  fixedFeeCents: number;
  avgLatencyMs: number;
  successRate: number;
  circuitState: CircuitState;
  failureCount: number;
  failureThreshold: number;
  cooldownUntil: string | null;
  isActive: boolean;
  simulatedFailureRate: number;
  simulatedLatencyMs: number;
  totalVolumeCents: number;
  totalTransactions: number;
  latencyAlertThresholdMs: number;
  errorRateThresholdEnabled: boolean;
  errorRateThresholdPct: number;
  updatedAt: string;
}

export interface TransactionAttempt {
  id: number;
  transactionId: number;
  gatewayCode: string;
  attemptNumber: number;
  status: string;
  latencyMs: number;
  errorCode: string | null;
  errorMessage: string | null;
  circuitStateAtAttempt: string;
  createdAt: string;
}

export interface Transaction {
  id: number;
  txCode: string;
  userId: number;
  idempotencyKey: string;
  payloadHash: string;
  orderRef: string;
  amountCents: number;
  currency: string;
  paymentMethod: string;
  customerEmail: string;
  customerCountry: string;
  selectedGatewayId: number | null;
  selectedGatewayCode: string | null;
  status: 'PENDING' | 'SUCCEEDED' | 'FAILED' | 'FLAGGED_FRAUD' | 'RECONCILED' | 'REFUNDED';
  attemptCount: number;
  latencyMs: number;
  feeCents: number;
  refundedCents: number;
  riskScore: number;
  riskReason: string | null;
  routingScore: number | null;
  routingReason: string | null;
  reconciledAt: string | null;
  createdAt: string;
  updatedAt: string;
  attempts: TransactionAttempt[];
  refunds?: Refund[];
}

export interface Refund {
  id: number;
  refundCode: string;
  userId: number;
  transactionId: number;
  gatewayCode: string;
  amountCents: number;
  reason: string;
  status: string;
  createdAt: string;
}

export interface RoutingRule {
  id: number;
  userId: number;
  name: string;
  priority: number;
  isActive: boolean;
  conditionCurrency: string;
  conditionMethod: string;
  conditionMinAmountCents: number;
  conditionCountry: string;
  actionType: 'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY';
  targetGatewayCode: string;
  canaryGatewayCode: string | null;
  canaryPct: number;
  hitCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface RoutingPolicy {
  id: number;
  userId: number;
  successWeight: number;
  latencyWeight: number;
  costWeight: number;
  autoRetryEnabled: boolean;
  maxRetries: number;
  fraudThreshold: number;
  idempotencyTtlSec: number;
  latencyAlertThresholdMs: number;
  rateLimitRps: number;
  rateLimitBurst: number;
  updatedAt: string;
}

export interface WebhookEvent {
  id: number;
  eventCode: string;
  userId: number;
  transactionId: number | null;
  gatewayCode: string;
  eventType: string;
  deliveryStatus: 'QUEUED' | 'DELIVERED' | 'RETRYING' | 'DEAD_LETTER';
  signatureValid: boolean;
  hmacSignature: string;
  attemptCount: number;
  payload: Record<string, unknown>;
  createdAt: string;
}

export interface ReconciliationBatch {
  id: number;
  batchCode: string;
  userId: number;
  gatewayCode: string;
  totalChecked: number;
  matchedCount: number;
  discrepancyCount: number;
  totalVolumeCents: number;
  status: 'MATCHED' | 'DISCREPANCY_FOUND' | 'RESOLVED';
  summary: string;
  createdAt: string;
}

export interface ReconciliationDiscrepancy {
  id: number;
  batchId: number;
  transactionId: number;
  expectedCents: number;
  settledCents: number;
  discrepancyType: string;
  resolved: boolean;
  resolutionNote: string | null;
  createdAt: string;
}

export interface AuditLog {
  id: number;
  userId: number;
  entityType: string;
  entityId: string;
  action: string;
  actorEmail: string;
  metadata: Record<string, unknown>;
  createdAt: string;
}

export interface DashboardMetrics {
  totalTransactions: number;
  successRatePct: number;
  totalVolumeCents: number;
  avgLatencyMs: number;
  fraudBlocked: number;
  retrySaves: number;
  openCircuits: number;
  queueDepth: number;
  latencyBreaches: number;
  p50LatencyMs: number;
  p95LatencyMs: number;
  p99LatencyMs: number;
  estimatedFeeSavingsCents: number;
  totalRefundedCents: number;
  rateLimiter: {
    remainingTokens: number;
    capacity: number;
    rps: number;
    rejectedCount: number;
    acceptedCount: number;
  };
}

export interface ThroughputPoint {
  hourIso: string;
  hourLabel: string;
  total: number;
  succeeded: number;
  failed: number;
  stripe: number;
  adyen: number;
  checkout: number;
  razorpay: number;
  braintree: number;
}

export interface DashboardData {
  user: {
    id: number;
    uid: string;
    email: string;
    displayName: string | null;
  };
  gateways: Gateway[];
  transactions: Transaction[];
  policy: RoutingPolicy | null;
  routingRules: RoutingRule[];
  refunds: Refund[];
  webhooks: WebhookEvent[];
  reconciliationBatches: ReconciliationBatch[];
  discrepancies: ReconciliationDiscrepancy[];
  auditLogs: AuditLog[];
  throughput24h: ThroughputPoint[];
  metrics: DashboardMetrics;
}

export interface RoutingPreset {
  id: string;
  userId: string;
  name: string;
  successWeight: number;
  latencyWeight: number;
  costWeight: number;
  fraudThreshold: number;
  maxRetries: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface InvestigationNote {
  id: string;
  userId: string;
  title: string;
  modelUsed: string;
  txCode?: string;
  summary: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}
