import React, { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { formatDateTime } from '../lib/format';
import { AuditLog } from '../types/paymatrix';

interface AuditTrailViewProps {
  logs: AuditLog[];
}

export const AuditTrailView: React.FC<AuditTrailViewProps> = ({ logs }) => {
  const [entityFilter, setEntityFilter] = useState('ALL');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return logs.filter((l) => {
      const matchType = entityFilter === 'ALL' || l.entityType === entityFilter;
      if (!q) return matchType;
      return (
        matchType &&
        (l.action.toLowerCase().includes(q) ||
          l.entityId.toLowerCase().includes(q) ||
          l.actorEmail.toLowerCase().includes(q))
      );
    });
  }, [logs, entityFilter, search]);

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          Immutable Audit Trail
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Cryptographically ordered PostgreSQL ledger of payment orchestrations, circuit breaker trips, policy mutations, and reconciliations.
        </p>
      </div>

      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search action, entity ID, actor..."
              className="w-64 rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-8 pr-3 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
            {['ALL', 'transaction', 'gateway', 'routing_policy', 'webhook', 'reconciliation'].map(
              (type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setEntityFilter(type)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    entityFilter === type
                      ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  {type === 'ALL' ? 'All Events' : type}
                </button>
              )
            )}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <th className="px-5 py-3 font-medium">Action</th>
                <th className="px-5 py-3 font-medium">Entity</th>
                <th className="px-5 py-3 font-medium">Actor</th>
                <th className="px-5 py-3 font-medium">Metadata</th>
                <th className="px-5 py-3 text-right font-medium">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
              {filtered.map((log) => (
                <tr key={log.id} className="h-10">
                  <td className="px-5 py-2.5 font-mono font-medium text-slate-900 dark:text-slate-100">
                    {log.action}
                  </td>
                  <td className="px-5 py-2.5 font-mono text-slate-600 dark:text-slate-300">
                    {log.entityType}:{log.entityId}
                  </td>
                  <td className="px-5 py-2.5 text-slate-600 dark:text-slate-400">
                    {log.actorEmail}
                  </td>
                  <td className="max-w-md truncate px-5 py-2.5 font-mono text-[11px] text-slate-500 dark:text-slate-400">
                    {JSON.stringify(log.metadata)}
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    {formatDateTime(log.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
