import React, { useState } from 'react';
import { CheckCircle2, RefreshCw, Send, ShieldAlert, ShieldCheck, XCircle } from 'lucide-react';
import { formatDateTime } from '../lib/format';
import { Gateway, WebhookEvent } from '../types/paymatrix';

interface WebhooksViewProps {
  gateways: Gateway[];
  webhooks: WebhookEvent[];
  onRetryWebhook: (id: number) => Promise<void>;
  onSimulateInbound: (payload: {
    gatewayCode: string;
    eventType: string;
    tamperSignature: boolean;
    amountCents: number;
  }) => Promise<void>;
}

export const WebhooksView: React.FC<WebhooksViewProps> = ({
  gateways,
  webhooks,
  onRetryWebhook,
  onSimulateInbound,
}) => {
  const [gatewayCode, setGatewayCode] = useState(gateways[0]?.code ?? 'stripe');
  const [eventType, setEventType] = useState('charge.captured');
  const [tamperSignature, setTamperSignature] = useState(false);
  const [simulating, setSimulating] = useState(false);
  const [retryingId, setRetryingId] = useState<number | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<WebhookEvent | null>(null);

  const handleSimulate = async (e: React.FormEvent) => {
    e.preventDefault();
    setSimulating(true);
    try {
      await onSimulateInbound({
        gatewayCode,
        eventType,
        tamperSignature,
        amountCents: 35000,
      });
    } finally {
      setSimulating(false);
    }
  };

  const handleRetry = async (id: number) => {
    setRetryingId(id);
    try {
      await onRetryWebhook(id);
    } finally {
      setRetryingId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          Webhooks & Async Event Queue
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Verify HMAC-SHA256 provider signatures, inspect asynchronous event payloads, and replay retrying or dead-letter deliveries.
        </p>
      </div>

      {/* Inbound Webhook Simulator */}
      <form
        onSubmit={handleSimulate}
        className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:flex-row lg:items-end"
      >
        <div className="flex-1">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
            Source Provider
          </label>
          <select
            value={gatewayCode}
            onChange={(e) => setGatewayCode(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          >
            {gateways.map((g) => (
              <option key={g.code} value={g.code}>
                {g.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex-1">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
            Webhook Event Type
          </label>
          <select
            value={eventType}
            onChange={(e) => setEventType(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          >
            <option value="charge.captured">charge.captured</option>
            <option value="charge.refunded">charge.refunded</option>
            <option value="dispute.created">dispute.created</option>
            <option value="payout.settled">payout.settled</option>
          </select>
        </div>

        <label className="flex cursor-pointer items-center gap-2 pb-2 text-xs font-medium text-slate-700 dark:text-slate-300">
          <input
            type="checkbox"
            checked={tamperSignature}
            onChange={(e) => setTamperSignature(e.target.checked)}
            className="h-4 w-4 rounded border-slate-300"
          />
          <span>Tamper HMAC Signature (Test DLQ)</span>
        </label>

        <button
          type="submit"
          disabled={simulating}
          className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 whitespace-nowrap shrink-0"
        >
          <Send className="h-3.5 w-3.5" />
          <span>{simulating ? 'Processing...' : 'Ingest Inbound Webhook'}</span>
        </button>
      </form>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        <div className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900 lg:col-span-8">
          <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Event Delivery Ledger ({webhooks.length})
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
                  <th className="px-4 py-3 font-medium">Event ID</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Provider</th>
                  <th className="px-4 py-3 font-medium">HMAC</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                  <th className="px-4 py-3 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {webhooks.map((wh) => (
                  <tr
                    key={wh.id}
                    onClick={() => setSelectedEvent(wh)}
                    className={`h-10 cursor-pointer transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                      selectedEvent?.id === wh.id ? 'bg-slate-50 dark:bg-slate-800/50' : ''
                    }`}
                  >
                    <td className="px-4 py-2.5 font-mono text-slate-900 dark:text-slate-100">
                      {wh.eventCode}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-slate-700 dark:text-slate-300">
                      {wh.eventType}
                    </td>
                    <td className="px-4 py-2.5 font-mono text-slate-600 dark:text-slate-400">
                      {wh.gatewayCode}
                    </td>
                    <td className="px-4 py-2.5">
                      {wh.signatureValid ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                          <ShieldCheck className="h-3.5 w-3.5" />
                          Verified
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400">
                          <ShieldAlert className="h-3.5 w-3.5" />
                          Invalid
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5">
                      {wh.deliveryStatus === 'DELIVERED' ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          Delivered
                        </span>
                      ) : wh.deliveryStatus === 'DEAD_LETTER' ? (
                        <span className="inline-flex items-center gap-1 text-rose-600 dark:text-rose-400">
                          <XCircle className="h-3.5 w-3.5" />
                          Dead Letter
                        </span>
                      ) : (
                        <span className="text-amber-700 dark:text-amber-400">
                          {wh.deliveryStatus} ({wh.attemptCount})
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          void handleRetry(wh.id);
                        }}
                        disabled={retryingId === wh.id}
                        className="inline-flex items-center gap-1 rounded border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                      >
                        <RefreshCw
                          className={`h-3 w-3 ${retryingId === wh.id ? 'animate-spin' : ''}`}
                        />
                        <span>Replay</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:col-span-4">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Payload & Signature Inspector
          </h2>
          {!selectedEvent ? (
            <p className="mt-6 text-xs text-slate-500 dark:text-slate-400">
              Select a webhook event row to inspect its HMAC-SHA256 digest and raw JSON payload.
            </p>
          ) : (
            <div className="mt-4 space-y-3 text-xs">
              <div>
                <p className="text-slate-500 dark:text-slate-400">Timestamp</p>
                <p className="font-mono text-slate-900 dark:text-slate-100">
                  {formatDateTime(selectedEvent.createdAt)}
                </p>
              </div>
              <div>
                <p className="text-slate-500 dark:text-slate-400">HMAC-SHA256 Signature</p>
                <p className="break-all font-mono text-[11px] text-slate-800 dark:text-slate-200">
                  {selectedEvent.hmacSignature}
                </p>
              </div>
              <div>
                <p className="mb-1 text-slate-500 dark:text-slate-400">JSON Payload</p>
                <pre className="max-h-72 overflow-auto rounded-lg border border-slate-200 bg-slate-50 p-3 font-mono text-[11px] text-slate-800 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-200">
                  {JSON.stringify(selectedEvent.payload, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
