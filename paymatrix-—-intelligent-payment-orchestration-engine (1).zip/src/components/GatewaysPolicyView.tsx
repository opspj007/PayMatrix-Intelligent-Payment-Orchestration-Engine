import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  BookmarkPlus,
  CheckCircle2,
  GitFork,
  Plus,
  Save,
  Sparkles,
  Trash2,
  XCircle,
} from 'lucide-react';
import {
  DashboardMetrics,
  Gateway,
  RoutingPolicy,
  RoutingPreset,
  RoutingRule,
} from '../types/paymatrix';
import { GatewayErrorThresholdControl } from './GatewayErrorThresholdControl';

interface SynthesizedRulePayload {
  model: string;
  latencyMs: number;
  rule: {
    name: string;
    conditionCurrency: string;
    conditionMethod: string;
    conditionMinAmountCents: number;
    conditionCountry: string;
    actionType: 'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY';
    targetGatewayCode: string;
    canaryGatewayCode: string | null;
    canaryPct: number;
  };
}

interface GatewaysPolicyViewProps {
  gateways: Gateway[];
  policy: RoutingPolicy | null;
  routingRules: RoutingRule[];
  rateLimiter: DashboardMetrics['rateLimiter'];
  presets: RoutingPreset[];
  onUpdateGateway: (code: string, updates: Record<string, unknown>) => Promise<void>;
  onUpdatePolicy: (updates: Record<string, unknown>) => Promise<void>;
  onCreateRule: (payload: Record<string, unknown>) => Promise<void>;
  onToggleRule: (ruleId: number, isActive: boolean) => Promise<void>;
  onDeleteRule: (ruleId: number) => Promise<void>;
  onSynthesizeRule: (instruction: string) => Promise<SynthesizedRulePayload>;
  onSavePreset: (preset: {
    name: string;
    successWeight: number;
    latencyWeight: number;
    costWeight: number;
    fraudThreshold: number;
    maxRetries: number;
  }) => Promise<void>;
  onDeletePreset: (presetId: string) => Promise<void>;
}

export const GatewaysPolicyView: React.FC<GatewaysPolicyViewProps> = ({
  gateways,
  policy,
  routingRules,
  rateLimiter,
  presets,
  onUpdateGateway,
  onUpdatePolicy,
  onCreateRule,
  onToggleRule,
  onDeleteRule,
  onSynthesizeRule,
  onSavePreset,
  onDeletePreset,
}) => {
  const [successWeight, setSuccessWeight] = useState(policy?.successWeight ?? 0.5);
  const [latencyWeight, setLatencyWeight] = useState(policy?.latencyWeight ?? 0.25);
  const [costWeight, setCostWeight] = useState(policy?.costWeight ?? 0.25);
  const [autoRetryEnabled, setAutoRetryEnabled] = useState(policy?.autoRetryEnabled ?? true);
  const [maxRetries, setMaxRetries] = useState(policy?.maxRetries ?? 2);
  const [fraudThreshold, setFraudThreshold] = useState(policy?.fraudThreshold ?? 75);
  const [latencyAlertThresholdMs, setLatencyAlertThresholdMs] = useState(
    policy?.latencyAlertThresholdMs ?? 250
  );
  const [rateLimitRps, setRateLimitRps] = useState(policy?.rateLimitRps ?? 15);
  const [rateLimitBurst, setRateLimitBurst] = useState(policy?.rateLimitBurst ?? 25);

  const [gatewayThresholds, setGatewayThresholds] = useState<Record<string, number>>({});
  const [presetName, setPresetName] = useState('');
  const [savingPolicy, setSavingPolicy] = useState(false);
  const [policyStatus, setPolicyStatus] = useState<string | null>(null);
  const [busyGw, setBusyGw] = useState<string | null>(null);

  // Conditional Routing Rules & AI Synthesizer state
  const [aiPrompt, setAiPrompt] = useState('');
  const [synthesizing, setSynthesizing] = useState(false);
  const [ruleError, setRuleError] = useState<string | null>(null);
  const [ruleStatus, setRuleStatus] = useState<string | null>(null);

  const [ruleName, setRuleName] = useState('');
  const [rulePriority, setRulePriority] = useState(10);
  const [conditionCurrency, setConditionCurrency] = useState('ALL');
  const [conditionMethod, setConditionMethod] = useState('ALL');
  const [conditionMinDollars, setConditionMinDollars] = useState('0');
  const [conditionCountry, setConditionCountry] = useState('ALL');
  const [actionType, setActionType] = useState<'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY'>(
    'FORCE_GATEWAY'
  );
  const [targetGatewayCode, setTargetGatewayCode] = useState('stripe');
  const [canaryGatewayCode, setCanaryGatewayCode] = useState('razorpay');
  const [canaryPct, setCanaryPct] = useState(20);
  const [creatingRule, setCreatingRule] = useState(false);

  useEffect(() => {
    if (policy) {
      setSuccessWeight(policy.successWeight);
      setLatencyWeight(policy.latencyWeight);
      setCostWeight(policy.costWeight);
      setAutoRetryEnabled(policy.autoRetryEnabled);
      setMaxRetries(policy.maxRetries);
      setFraudThreshold(policy.fraudThreshold);
      setLatencyAlertThresholdMs(policy.latencyAlertThresholdMs ?? 250);
      setRateLimitRps(policy.rateLimitRps ?? 15);
      setRateLimitBurst(policy.rateLimitBurst ?? 25);
    }
  }, [policy]);

  useEffect(() => {
    setGatewayThresholds((prev) => {
      const next = { ...prev };
      for (const gw of gateways) {
        if (next[gw.code] === undefined) {
          next[gw.code] = gw.latencyAlertThresholdMs ?? 250;
        }
      }
      return next;
    });
  }, [gateways]);

  const handleSavePolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPolicy(true);
    setPolicyStatus(null);
    try {
      await onUpdatePolicy({
        successWeight,
        latencyWeight,
        costWeight,
        autoRetryEnabled,
        maxRetries,
        fraudThreshold,
        latencyAlertThresholdMs,
        rateLimitRps,
        rateLimitBurst,
      });
      setPolicyStatus('Routing policy persisted to Cloud SQL.');
    } catch (err: any) {
      setPolicyStatus(err?.message || 'Failed to save routing policy.');
    } finally {
      setSavingPolicy(false);
    }
  };

  const handleCreatePreset = async () => {
    if (!presetName.trim()) return;
    await onSavePreset({
      name: presetName.trim(),
      successWeight,
      latencyWeight,
      costWeight,
      fraudThreshold,
      maxRetries,
    });
    setPresetName('');
  };

  const applyPreset = async (p: RoutingPreset) => {
    setSuccessWeight(p.successWeight);
    setLatencyWeight(p.latencyWeight);
    setCostWeight(p.costWeight);
    setFraudThreshold(p.fraudThreshold);
    setMaxRetries(p.maxRetries);
    await onUpdatePolicy({
      successWeight: p.successWeight,
      latencyWeight: p.latencyWeight,
      costWeight: p.costWeight,
      autoRetryEnabled,
      maxRetries: p.maxRetries,
      fraudThreshold: p.fraudThreshold,
      latencyAlertThresholdMs,
      rateLimitRps,
      rateLimitBurst,
    });
    setPolicyStatus(`Applied preset "${p.name}" to active orchestration engine.`);
  };

  const handleGatewayAction = async (code: string, updates: Record<string, unknown>) => {
    setBusyGw(code);
    try {
      await onUpdateGateway(code, updates);
    } finally {
      setBusyGw(null);
    }
  };

  const handleAiSynthesize = async () => {
    if (!aiPrompt.trim()) return;
    setSynthesizing(true);
    setRuleError(null);
    setRuleStatus(null);
    try {
      const res = await onSynthesizeRule(aiPrompt.trim());
      setRuleName(res.rule.name);
      setConditionCurrency(res.rule.conditionCurrency);
      setConditionMethod(res.rule.conditionMethod);
      setConditionMinDollars(String(Math.round(res.rule.conditionMinAmountCents / 100)));
      setConditionCountry(res.rule.conditionCountry);
      setActionType(res.rule.actionType);
      setTargetGatewayCode(res.rule.targetGatewayCode);
      if (res.rule.canaryGatewayCode) {
        setCanaryGatewayCode(res.rule.canaryGatewayCode);
      }
      setCanaryPct(res.rule.canaryPct || 20);
      setRuleStatus(
        `Synthesized rule schema with ${res.model} in ${res.latencyMs}ms. Review and click Add Rule.`
      );
    } catch (err: any) {
      setRuleError(err?.message || 'Failed to synthesize routing rule.');
    } finally {
      setSynthesizing(false);
    }
  };

  const handleCreateRuleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName.trim()) return;
    setCreatingRule(true);
    setRuleError(null);
    setRuleStatus(null);
    try {
      const minDollars = parseFloat(conditionMinDollars);
      const conditionMinAmountCents = Number.isFinite(minDollars)
        ? Math.max(0, Math.round(minDollars * 100))
        : 0;
      await onCreateRule({
        name: ruleName.trim(),
        priority: rulePriority,
        conditionCurrency,
        conditionMethod,
        conditionMinAmountCents,
        conditionCountry: conditionCountry.trim() || 'ALL',
        actionType,
        targetGatewayCode,
        canaryGatewayCode: actionType === 'CANARY_SPLIT' ? canaryGatewayCode : null,
        canaryPct: actionType === 'CANARY_SPLIT' ? canaryPct : 0,
      });
      setRuleName('');
      setAiPrompt('');
      setRuleStatus('Conditional routing rule saved and activated.');
    } catch (err: any) {
      setRuleError(err?.message || 'Failed to create rule.');
    } finally {
      setCreatingRule(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          Gateways, Routing Rules & Circuit Breakers
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Tune multi-objective provider scoring, token-bucket rate limits, conditional canary rules, and circuit breaker states.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Routing Policy Controls */}
        <form
          onSubmit={handleSavePolicy}
          className="space-y-5 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6"
        >
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Intelligent Routing Weights & Rate Limits
          </h2>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300">
                <span>Success Rate Priority</span>
                <span className="font-mono tabular-nums">{(successWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={successWeight}
                onChange={(e) => setSuccessWeight(parseFloat(e.target.value))}
                className="mt-1.5 w-full accent-slate-900 dark:accent-slate-100"
              />
            </div>

            <div>
              <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300">
                <span>Low Latency Priority</span>
                <span className="font-mono tabular-nums">{(latencyWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={latencyWeight}
                onChange={(e) => setLatencyWeight(parseFloat(e.target.value))}
                className="mt-1.5 w-full accent-slate-900 dark:accent-slate-100"
              />
            </div>

            <div>
              <div className="flex justify-between font-medium text-slate-700 dark:text-slate-300">
                <span>Fee Cost Optimization</span>
                <span className="font-mono tabular-nums">{(costWeight * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={costWeight}
                onChange={(e) => setCostWeight(parseFloat(e.target.value))}
                className="mt-1.5 w-full accent-slate-900 dark:accent-slate-100"
              />
            </div>

            <div className="grid grid-cols-1 gap-4 pt-2 sm:grid-cols-3">
              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Max Auto-Retries
                </label>
                <input
                  type="number"
                  min={0}
                  max={4}
                  value={maxRetries}
                  onChange={(e) => setMaxRetries(Number(e.target.value))}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-600 dark:text-slate-400">
                  Fraud Block Threshold
                </label>
                <input
                  type="number"
                  min={10}
                  max={100}
                  value={fraudThreshold}
                  onChange={(e) => setFraudThreshold(Number(e.target.value))}
                  className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                />
              </div>

              <div className="flex items-end pb-1">
                <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={autoRetryEnabled}
                    onChange={(e) => setAutoRetryEnabled(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-300"
                  />
                  <span>Auto-Failover</span>
                </label>
              </div>
            </div>

            {/* Token-Bucket Rate Limiter Configuration */}
            <div className="border-t border-slate-100 pt-4 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <span className="font-medium text-slate-700 dark:text-slate-300">
                  Token-Bucket Rate Limiter & Load Shedding
                </span>
                <span className="font-mono text-[11px] tabular-nums text-slate-500 dark:text-slate-400">
                  {rateLimiter.remainingTokens}/{rateLimiter.capacity} tokens · {rateLimiter.rejectedCount} shed
                </span>
              </div>
              <div className="mt-2 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Sustained Refill (req/sec)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={200}
                    value={rateLimitRps}
                    onChange={(e) => setRateLimitRps(Number(e.target.value))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    Burst Bucket Capacity (tokens)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    value={rateLimitBurst}
                    onChange={(e) => setRateLimitBurst(Number(e.target.value))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 dark:border-slate-800">
              <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                <div className="flex-1">
                  <label className="block font-medium text-slate-700 dark:text-slate-300">
                    Global Transaction Latency Alert Threshold (ms)
                  </label>
                  <p className="mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                    Triggers dashboard alert indicators when mean or transaction latency exceeds this limit.
                  </p>
                  <input
                    type="number"
                    min={50}
                    max={5000}
                    step={10}
                    value={latencyAlertThresholdMs}
                    onChange={(e) => setLatencyAlertThresholdMs(Number(e.target.value))}
                    className="mt-2 w-40 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                  />
                </div>
                <div className="flex items-center gap-1.5">
                  {[150, 250, 500].map((presetMs) => (
                    <button
                      key={presetMs}
                      type="button"
                      onClick={() => setLatencyAlertThresholdMs(presetMs)}
                      className={`rounded-md border px-2.5 py-1.5 font-mono text-[11px] tabular-nums transition-colors ${
                        latencyAlertThresholdMs === presetMs
                          ? 'border-slate-900 bg-slate-900 text-white dark:border-slate-100 dark:bg-slate-100 dark:text-slate-900'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300'
                      }`}
                    >
                      {presetMs} ms
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="submit"
              disabled={savingPolicy}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
            >
              <Save className="h-3.5 w-3.5" />
              <span>{savingPolicy ? 'Saving...' : 'Apply Routing Policy'}</span>
            </button>
            {policyStatus && (
              <span className="text-xs text-emerald-700 dark:text-emerald-400">{policyStatus}</span>
            )}
          </div>
        </form>

        {/* Firestore Saved Presets */}
        <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Saved Operator Policy Presets (Firestore)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Save named weight profiles to your personal Firestore workspace for instant switching.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={presetName}
              onChange={(e) => setPresetName(e.target.value)}
              placeholder="Preset name (e.g. APAC Cost Saver)"
              maxLength={80}
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <button
              type="button"
              onClick={handleCreatePreset}
              disabled={!presetName.trim()}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200"
            >
              <BookmarkPlus className="h-3.5 w-3.5" />
              <span>Save Preset</span>
            </button>
          </div>

          {presets.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-200 p-6 text-center text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              No saved presets yet. Configure weights on the left and save your first preset.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 rounded-lg border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
              {presets.map((p) => (
                <div key={p.id} className="flex items-center justify-between px-4 py-3 text-xs">
                  <div>
                    <p className="font-medium text-slate-900 dark:text-slate-100">{p.name}</p>
                    <p className="mt-0.5 font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      SR {(p.successWeight * 100).toFixed(0)}% · Lat {(p.latencyWeight * 100).toFixed(0)}% · Cost{' '}
                      {(p.costWeight * 100).toFixed(0)}% · Fraud {p.fraudThreshold}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void applyPreset(p)}
                      className="rounded-md border border-slate-200 px-2.5 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                    >
                      Apply
                    </button>
                    <button
                      type="button"
                      onClick={() => void onDeletePreset(p.id)}
                      className="rounded-md p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                      aria-label={`Delete ${p.name}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Conditional Routing Rules & Canary Traffic Splitting */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-6 py-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <GitFork className="h-4 w-4 text-slate-700 dark:text-slate-300" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Conditional Routing Rules & Canary Traffic Splitting
            </h2>
          </div>
          <p className="mt-0.5 text-xs text-slate-500 dark:text-slate-400">
            Deterministic priority-ordered rules evaluated before composite scoring. Supports forced routes, canary traffic percentages, and geo-blocking.
          </p>
        </div>

        <div className="space-y-6 p-6">
          {/* Natural-Language AI Rule Synthesizer */}
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
            <input
              type="text"
              value={aiPrompt}
              onChange={(e) => setAiPrompt(e.target.value)}
              placeholder='Describe a rule in plain English (e.g. "Send 25% of USD card payments over $500 to Adyen canary")'
              className="flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <button
              type="button"
              onClick={() => void handleAiSynthesize()}
              disabled={synthesizing || !aiPrompt.trim()}
              className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 whitespace-nowrap shrink-0"
            >
              <Sparkles className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              <span>{synthesizing ? 'Synthesizing...' : 'Synthesize Rule (Gemini)'}</span>
            </button>
          </div>

          {ruleError && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 px-4 py-2.5 text-xs text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300">
              {ruleError}
            </div>
          )}
          {ruleStatus && (
            <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs text-emerald-800 dark:border-emerald-900/50 dark:bg-emerald-950/30 dark:text-emerald-300">
              {ruleStatus}
            </div>
          )}

          {/* Manual Rule Builder */}
          <form
            onSubmit={handleCreateRuleSubmit}
            className="grid grid-cols-1 gap-3 border-t border-slate-100 pt-5 text-xs dark:border-slate-800 sm:grid-cols-2 lg:grid-cols-6"
          >
            <div className="lg:col-span-2">
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Rule Name
              </label>
              <input
                type="text"
                value={ruleName}
                onChange={(e) => setRuleName(e.target.value)}
                placeholder="e.g. High-ticket USD -> Adyen"
                required
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Priority
              </label>
              <input
                type="number"
                min={1}
                max={999}
                value={rulePriority}
                onChange={(e) => setRulePriority(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Currency
              </label>
              <select
                value={conditionCurrency}
                onChange={(e) => setConditionCurrency(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
              >
                <option value="ALL">ALL</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="GBP">GBP</option>
                <option value="SGD">SGD</option>
                <option value="INR">INR</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Method
              </label>
              <select
                value={conditionMethod}
                onChange={(e) => setConditionMethod(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
              >
                <option value="ALL">ALL</option>
                <option value="card">card</option>
                <option value="wallet">wallet</option>
                <option value="sepa_debit">sepa_debit</option>
                <option value="ach">ach</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Country (ISO / ALL)
              </label>
              <input
                type="text"
                maxLength={3}
                value={conditionCountry}
                onChange={(e) => setConditionCountry(e.target.value.toUpperCase())}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs uppercase dark:border-slate-700 dark:bg-slate-950"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Min Amount ($)
              </label>
              <input
                type="number"
                min={0}
                step="1"
                value={conditionMinDollars}
                onChange={(e) => setConditionMinDollars(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Action Type
              </label>
              <select
                value={actionType}
                onChange={(e) =>
                  setActionType(
                    e.target.value as 'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY'
                  )
                }
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
              >
                <option value="FORCE_GATEWAY">FORCE_GATEWAY</option>
                <option value="CANARY_SPLIT">CANARY_SPLIT</option>
                <option value="BLOCK_COUNTRY">BLOCK_COUNTRY</option>
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-600 dark:text-slate-400">
                Primary Gateway
              </label>
              <select
                value={targetGatewayCode}
                onChange={(e) => setTargetGatewayCode(e.target.value)}
                disabled={actionType === 'BLOCK_COUNTRY'}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs disabled:opacity-50 dark:border-slate-700 dark:bg-slate-950"
              >
                {gateways.map((g) => (
                  <option key={g.code} value={g.code}>
                    {g.code}
                  </option>
                ))}
              </select>
            </div>

            {actionType === 'CANARY_SPLIT' && (
              <>
                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">
                    Canary Gateway
                  </label>
                  <select
                    value={canaryGatewayCode}
                    onChange={(e) => setCanaryGatewayCode(e.target.value)}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs dark:border-slate-700 dark:bg-slate-950"
                  >
                    {gateways.map((g) => (
                      <option key={g.code} value={g.code}>
                        {g.code}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-600 dark:text-slate-400">
                    Canary Split (%)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={99}
                    value={canaryPct}
                    onChange={(e) => setCanaryPct(Number(e.target.value))}
                    className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                  />
                </div>
              </>
            )}

            <div className="flex items-end">
              <button
                type="submit"
                disabled={creatingRule || !ruleName.trim()}
                className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>{creatingRule ? 'Adding...' : 'Add Rule'}</span>
              </button>
            </div>
          </form>

          {/* Active Rules Table */}
          {routingRules.length === 0 ? (
            <div className="rounded-lg border border-dashed border-slate-200 p-6 text-center text-xs text-slate-500 dark:border-slate-800 dark:text-slate-400">
              No conditional routing rules configured. Add a rule above or synthesize one with Gemini.
            </div>
          ) : (
            <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
                    <th className="px-4 py-2.5 font-medium">Priority</th>
                    <th className="px-4 py-2.5 font-medium">Rule Name</th>
                    <th className="px-4 py-2.5 font-medium">Match Predicate</th>
                    <th className="px-4 py-2.5 font-medium">Action</th>
                    <th className="px-4 py-2.5 text-right font-medium">Hits</th>
                    <th className="px-4 py-2.5 text-right font-medium">Controls</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {routingRules.map((rule) => (
                    <tr key={rule.id} className={rule.isActive ? '' : 'opacity-55'}>
                      <td className="px-4 py-3 font-mono tabular-nums text-slate-600 dark:text-slate-400">
                        #{rule.priority}
                      </td>
                      <td className="px-4 py-3 font-medium text-slate-900 dark:text-slate-100">
                        {rule.name}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-600 dark:text-slate-300">
                        {rule.conditionCurrency} · {rule.conditionMethod} · {rule.conditionCountry}
                        {rule.conditionMinAmountCents > 0
                          ? ` · >= $${(rule.conditionMinAmountCents / 100).toFixed(0)}`
                          : ''}
                      </td>
                      <td className="px-4 py-3 font-mono text-slate-800 dark:text-slate-200">
                        {rule.actionType === 'CANARY_SPLIT'
                          ? `${rule.canaryPct}% ${rule.canaryGatewayCode} / ${100 - rule.canaryPct}% ${rule.targetGatewayCode}`
                          : rule.actionType === 'BLOCK_COUNTRY'
                            ? `BLOCK (${rule.conditionCountry})`
                            : `FORCE -> ${rule.targetGatewayCode}`}
                      </td>
                      <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                        {rule.hitCount}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => void onToggleRule(rule.id, !rule.isActive)}
                            className="rounded border border-slate-200 px-2.5 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                          >
                            {rule.isActive ? 'Disable' : 'Enable'}
                          </button>
                          <button
                            type="button"
                            onClick={() => void onDeleteRule(rule.id)}
                            className="rounded p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                            aria-label={`Delete ${rule.name}`}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>

      {/* Gateway Circuit Breaker Matrix */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Sandbox Provider Nodes & Circuit Breakers
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Simulate degraded latency or fault rates to trigger automatic circuit breaker trips and failover routing.
          </p>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {gateways.map((gw) => (
            <div key={gw.code} className="space-y-3 px-5 py-4">
              <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                      {gw.name}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                      {gw.region}
                    </span>
                    <span className="text-xs text-slate-400">·</span>
                    {gw.circuitState === 'CLOSED' && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        CLOSED
                      </span>
                    )}
                    {gw.circuitState === 'HALF_OPEN' && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-700 dark:text-amber-400">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        HALF_OPEN
                      </span>
                    )}
                    {gw.circuitState === 'OPEN' && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-rose-700 dark:text-rose-400">
                        <XCircle className="h-3.5 w-3.5" />
                        OPEN ({gw.failureCount}/{gw.failureThreshold} faults)
                      </span>
                    )}
                  </div>
                  <p className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
                    SR: {(gw.successRate * 100).toFixed(1)}% · Latency:{' '}
                    <span
                      className={
                        gw.avgLatencyMs > gw.latencyAlertThresholdMs
                          ? 'font-semibold text-amber-700 dark:text-amber-400'
                          : ''
                      }
                    >
                      {gw.avgLatencyMs}ms
                    </span>{' '}
                    (Alert &gt; {gw.latencyAlertThresholdMs}ms) · Fee: {(gw.baseFeeBps / 100).toFixed(2)}% + $
                    {(gw.fixedFeeCents / 100).toFixed(2)} · Fault Rate: {(gw.simulatedFailureRate * 100).toFixed(0)}%
                  </p>
                  {gw.avgLatencyMs > gw.latencyAlertThresholdMs && (
                    <p className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
                      <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                      <span>
                        Latency threshold exceeded ({gw.avgLatencyMs} ms vs {gw.latencyAlertThresholdMs} ms limit)
                      </span>
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <div className="flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2 py-1 dark:border-slate-700 dark:bg-slate-950">
                    <label
                      htmlFor={`gw-lat-${gw.code}`}
                      className="text-[11px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap"
                    >
                      Alert (ms)
                    </label>
                    <input
                      id={`gw-lat-${gw.code}`}
                      type="number"
                      min={50}
                      max={5000}
                      step={10}
                      value={gatewayThresholds[gw.code] ?? gw.latencyAlertThresholdMs ?? 250}
                      onChange={(e) =>
                        setGatewayThresholds((prev) => ({
                          ...prev,
                          [gw.code]: Number(e.target.value),
                        }))
                      }
                      className="w-16 bg-transparent font-mono text-xs tabular-nums text-slate-900 focus:outline-none dark:text-slate-100"
                    />
                    <button
                      type="button"
                      disabled={busyGw === gw.code}
                      onClick={() =>
                        void handleGatewayAction(gw.code, {
                          latencyAlertThresholdMs:
                            gatewayThresholds[gw.code] ?? gw.latencyAlertThresholdMs ?? 250,
                        })
                      }
                      className="rounded bg-slate-900 px-2 py-0.5 text-[11px] font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900"
                    >
                      Save
                    </button>
                  </div>

                  <button
                    type="button"
                    disabled={busyGw === gw.code}
                    onClick={() => void handleGatewayAction(gw.code, { isActive: !gw.isActive })}
                    className="rounded-lg border border-slate-200 px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    {gw.isActive ? 'Disable Node' : 'Enable Node'}
                  </button>

                  <button
                    type="button"
                    disabled={busyGw === gw.code}
                    onClick={() =>
                      void handleGatewayAction(gw.code, {
                        simulatedFailureRate: gw.simulatedFailureRate > 0.2 ? 0.03 : 0.85,
                        simulatedLatencyMs: gw.simulatedFailureRate > 0.2 ? 160 : 420,
                      })
                    }
                    className="rounded-lg border border-slate-200 px-3 py-1.5 font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    {gw.simulatedFailureRate > 0.2 ? 'Restore Healthy Sim' : 'Inject 85% Fault Rate'}
                  </button>

                  {gw.circuitState !== 'CLOSED' ? (
                    <button
                      type="button"
                      disabled={busyGw === gw.code}
                      onClick={() => void handleGatewayAction(gw.code, { circuitState: 'CLOSED' })}
                      className="rounded-lg bg-slate-900 px-3 py-1.5 font-medium text-white hover:bg-slate-800 dark:bg-slate-100 dark:text-slate-900"
                    >
                      Reset Circuit CLOSED
                    </button>
                  ) : (
                    <button
                      type="button"
                      disabled={busyGw === gw.code}
                      onClick={() => void handleGatewayAction(gw.code, { circuitState: 'OPEN' })}
                      className="rounded-lg border border-rose-200 px-3 py-1.5 font-medium text-rose-700 hover:bg-rose-50 dark:border-rose-900/50 dark:text-rose-400 dark:hover:bg-rose-950/30"
                    >
                      Trip Circuit OPEN
                    </button>
                  )}
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3 dark:border-slate-800/70">
                <GatewayErrorThresholdControl
                  gateway={gw}
                  busy={busyGw === gw.code}
                  onUpdate={(updates) => handleGatewayAction(gw.code, updates)}
                />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

