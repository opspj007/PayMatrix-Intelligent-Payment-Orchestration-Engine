import React, { useState } from 'react';
import { Copy, Gauge, KeyRound, Play, RefreshCw, ShieldAlert, Zap } from 'lucide-react';
import { formatMoney } from '../lib/format';
import { DashboardMetrics, Gateway, Transaction, TransactionAttempt } from '../types/paymatrix';

interface DispatchResponse {
  transaction: Transaction;
  attempts: TransactionAttempt[];
  idempotentReplay: boolean;
  cacheLayer: string;
}

interface DispatchSandboxViewProps {
  gateways: Gateway[];
  rateLimiter: DashboardMetrics['rateLimiter'];
  onDispatch: (payload: Record<string, unknown>) => Promise<DispatchResponse>;
  onRefreshDashboard: () => Promise<void>;
}

export const DispatchSandboxView: React.FC<DispatchSandboxViewProps> = ({
  gateways,
  rateLimiter,
  onDispatch,
  onRefreshDashboard,
}) => {
  const [orderRef, setOrderRef] = useState(`ORD-${Math.floor(10000 + Math.random() * 89999)}`);
  const [amountDollars, setAmountDollars] = useState('249.00');
  const [currency, setCurrency] = useState('USD');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [customerEmail, setCustomerEmail] = useState('checkout@acme-saas.io');
  const [customerCountry, setCustomerCountry] = useState('US');
  const [idempotencyKey, setIdempotencyKey] = useState(
    `idem_${Math.random().toString(36).slice(2, 10)}`
  );
  const [preferredGatewayCode, setPreferredGatewayCode] = useState('AUTO');
  const [forceFailGatewayCode, setForceFailGatewayCode] = useState('NONE');

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [stressSummary, setStressSummary] = useState<{
    total: number;
    accepted: number;
    loadShed: number;
    firstError?: string;
  } | null>(null);
  const [results, setResults] = useState<Array<{ label: string; res: DispatchResponse }>>([]);

  const regenerateKey = () => {
    setIdempotencyKey(`idem_${Math.random().toString(36).slice(2, 10)}`);
    setOrderRef(`ORD-${Math.floor(10000 + Math.random() * 89999)}`);
  };

  const buildPayload = (overrideAmountCents?: number, overrideKey?: string) => {
    const parsedDollars = parseFloat(amountDollars);
    const amountCents =
      overrideAmountCents ??
      Math.max(100, Math.round((Number.isFinite(parsedDollars) ? parsedDollars : 100) * 100));
    return {
      orderRef,
      amountCents,
      currency,
      paymentMethod,
      customerEmail,
      customerCountry,
      idempotencyKey: overrideKey ?? idempotencyKey,
      preferredGatewayCode,
      forceFailGatewayCode,
    };
  };

  const handleSingleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    setErrorMsg(null);
    setStressSummary(null);
    try {
      const res = await onDispatch(buildPayload());
      setResults([{ label: 'Primary Dispatch', res }]);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Dispatch failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConcurrencyTest = async () => {
    setSubmitting(true);
    setErrorMsg(null);
    setStressSummary(null);
    const payload = buildPayload();
    try {
      const [r1, r2] = await Promise.all([onDispatch(payload), onDispatch(payload)]);
      setResults([
        { label: 'Concurrent Worker A', res: r1 },
        { label: 'Concurrent Worker B', res: r2 },
      ]);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Concurrency test failed.');
    } finally {
      setSubmitting(false);
    }
  };

  const handlePayloadConflictTest = async () => {
    setSubmitting(true);
    setErrorMsg(null);
    setStressSummary(null);
    try {
      const baseAmount = Math.max(100, Math.round((parseFloat(amountDollars) || 100) * 100));
      await onDispatch(buildPayload(baseAmount));
      await onDispatch(buildPayload(baseAmount + 500));
    } catch (err: any) {
      setErrorMsg(
        `409 Conflict Verified: ${err?.message || 'Idempotency key rejected mismatched payload.'}`
      );
    } finally {
      setSubmitting(false);
    }
  };

  const handleRateLimitStressTest = async () => {
    setSubmitting(true);
    setErrorMsg(null);
    setStressSummary(null);
    const batchId = Math.random().toString(36).slice(2, 7);
    const requests = Array.from({ length: 12 }, (_, idx) =>
      onDispatch(buildPayload(undefined, `idem_rl_${batchId}_${idx}`))
    );
    const outcomes = await Promise.allSettled(requests);
    const acceptedResults: Array<{ label: string; res: DispatchResponse }> = [];
    let loadShed = 0;
    let firstError: string | undefined;

    outcomes.forEach((o, i) => {
      if (o.status === 'fulfilled') {
        acceptedResults.push({ label: `Burst #${i + 1}`, res: o.value });
      } else {
        loadShed += 1;
        if (!firstError) {
          firstError = o.reason?.message || '429 Rate Limit Exceeded';
        }
      }
    });

    setResults(acceptedResults.slice(0, 3));
    setStressSummary({
      total: 12,
      accepted: acceptedResults.length,
      loadShed,
      firstError,
    });
    await onRefreshDashboard();
    setSubmitting(false);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-3 border-b border-slate-200 pb-6 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            Payment Dispatch & Chaos Sandbox
          </h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
            Test conditional routing rules, concurrent idempotency locking, failover retries, and token-bucket rate limiting.
          </p>
        </div>
        <div className="font-mono text-xs tabular-nums text-slate-600 dark:text-slate-300">
          Token Bucket: {rateLimiter.remainingTokens}/{rateLimiter.capacity} tokens · {rateLimiter.rps} req/s ·{' '}
          {rateLimiter.rejectedCount} load-shed
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Left: Dispatch Form */}
        <form
          onSubmit={handleSingleDispatch}
          className="space-y-5 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Payment Payload & Fault Controls
            </h2>
            <button
              type="button"
              onClick={regenerateKey}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 hover:underline dark:text-blue-400"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              <span>New Order & Key</span>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Order Reference
              </label>
              <input
                type="text"
                value={orderRef}
                onChange={(e) => setOrderRef(e.target.value)}
                required
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Amount ({currency})
              </label>
              <input
                type="number"
                step="0.01"
                min="1"
                value={amountDollars}
                onChange={(e) => setAmountDollars(e.target.value)}
                required
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs tabular-nums text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Currency
              </label>
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="USD">USD — US Dollar</option>
                <option value="EUR">EUR — Euro</option>
                <option value="GBP">GBP — British Pound</option>
                <option value="SGD">SGD — Singapore Dollar</option>
                <option value="INR">INR — Indian Rupee</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="card">Credit / Debit Card</option>
                <option value="wallet">Digital Wallet</option>
                <option value="sepa_debit">SEPA Direct Debit</option>
                <option value="ach">ACH Bank Transfer</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Customer Email
              </label>
              <input
                type="email"
                value={customerEmail}
                onChange={(e) => setCustomerEmail(e.target.value)}
                required
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Customer Country (ISO-2)
              </label>
              <input
                type="text"
                maxLength={2}
                value={customerCountry}
                onChange={(e) => setCustomerCountry(e.target.value.toUpperCase())}
                required
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs uppercase text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Idempotency-Key Header
            </label>
            <div className="mt-1 flex items-center gap-2">
              <div className="relative flex-1">
                <KeyRound className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={idempotencyKey}
                  onChange={(e) => setIdempotencyKey(e.target.value)}
                  required
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-8 pr-3 font-mono text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                />
              </div>
              <button
                type="button"
                onClick={() => navigator.clipboard?.writeText(idempotencyKey)}
                className="rounded-lg border border-slate-200 px-3 py-2 text-xs text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                title="Copy key"
              >
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Routing Mode
              </label>
              <select
                value={preferredGatewayCode}
                onChange={(e) => setPreferredGatewayCode(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="AUTO">Rules + Composite Scoring</option>
                {gateways.map((g) => (
                  <option key={g.code} value={g.code}>
                    Prefer {g.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
                Chaos Injection (Force Gateway Fault)
              </label>
              <select
                value={forceFailGatewayCode}
                onChange={(e) => setForceFailGatewayCode(e.target.value)}
                className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              >
                <option value="NONE">None (Normal Sandbox Rates)</option>
                {gateways.map((g) => (
                  <option key={g.code} value={g.code}>
                    Force 502 Failure on {g.code}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
            >
              <Play className="h-3.5 w-3.5" />
              <span>{submitting ? 'Orchestrating...' : 'Dispatch Payment'}</span>
            </button>

            <button
              type="button"
              onClick={handleConcurrencyTest}
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Zap className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
              <span>Fire 2 Concurrent Duplicates</span>
            </button>

            <button
              type="button"
              onClick={handlePayloadConflictTest}
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <ShieldAlert className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
              <span>Test 409 Payload Mismatch</span>
            </button>

            <button
              type="button"
              onClick={() => void handleRateLimitStressTest()}
              disabled={submitting}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <Gauge className="h-3.5 w-3.5 text-rose-600 dark:text-rose-400" />
              <span>Stress-Test Rate Limiter (12 Concurrent)</span>
            </button>
          </div>
        </form>

        {/* Right: Orchestration Trace Output */}
        <div className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-6">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Execution Trace & Idempotency Cache Inspector
          </h2>

          {stressSummary && (
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-950">
              <div className="flex items-center justify-between font-semibold text-slate-900 dark:text-slate-100">
                <span>Rate Limiter Burst Summary ({stressSummary.total} concurrent requests)</span>
                <span className="font-mono tabular-nums">
                  {stressSummary.accepted} OK · {stressSummary.loadShed} Shed (429)
                </span>
              </div>
              {stressSummary.firstError && (
                <p className="mt-1.5 font-mono text-amber-700 dark:text-amber-400">
                  {stressSummary.firstError}
                </p>
              )}
              {stressSummary.loadShed === 0 && (
                <p className="mt-1.5 text-slate-500 dark:text-slate-400">
                  All 12 fit inside burst capacity ({rateLimiter.capacity}). Lower burst capacity in Gateways & Circuits to observe 429 shedding.
                </p>
              )}
            </div>
          )}

          {errorMsg && (
            <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900 dark:border-amber-900/50 dark:bg-amber-950/30 dark:text-amber-200">
              {errorMsg}
            </div>
          )}

          {results.length === 0 && !errorMsg && !stressSummary && (
            <div className="flex h-64 flex-col items-center justify-center rounded-lg border border-dashed border-slate-200 text-center dark:border-slate-800">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Ready to trace orchestration execution
              </p>
              <p className="mt-1 max-w-sm text-xs text-slate-400 dark:text-slate-500">
                Dispatch a payment, test concurrent duplicates, or stress-test token-bucket rate limiting.
              </p>
            </div>
          )}

          {results.map(({ label, res }, idx) => (
            <div
              key={idx}
              className="space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-950"
            >
              <div className="flex items-center justify-between border-b border-slate-200 pb-2 dark:border-slate-800">
                <span className="font-semibold text-slate-900 dark:text-slate-100">{label}</span>
                <span className="font-mono text-slate-600 dark:text-slate-400">
                  {res.idempotentReplay
                    ? `REPLAYED (${res.cacheLayer})`
                    : 'FRESH EXECUTION'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-y-1.5 text-slate-600 dark:text-slate-400">
                <span>Transaction Code</span>
                <span className="font-mono text-slate-900 dark:text-slate-100">
                  {res.transaction.txCode}
                </span>
                <span>Final Status</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-slate-100">
                  {res.transaction.status}
                </span>
                <span>Selected Provider</span>
                <span className="font-mono text-slate-900 dark:text-slate-100">
                  {res.transaction.selectedGatewayCode ?? 'Blocked pre-dispatch'}
                </span>
                <span>Amount / Fee</span>
                <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {formatMoney(res.transaction.amountCents, res.transaction.currency)} /{' '}
                  {formatMoney(res.transaction.feeCents, res.transaction.currency)}
                </span>
                <span>Total Latency</span>
                <span className="font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {res.transaction.latencyMs} ms
                </span>
                <span>Routing Rationale</span>
                <span className="text-slate-800 dark:text-slate-200">
                  {res.transaction.routingReason}
                </span>
              </div>

              {res.attempts.length > 0 && (
                <div className="pt-2">
                  <p className="mb-1.5 font-medium text-slate-700 dark:text-slate-300">
                    Attempt Sequence
                  </p>
                  <div className="space-y-1">
                    {res.attempts.map((a) => (
                      <div
                        key={a.id}
                        className="flex items-center justify-between rounded border border-slate-200 bg-white px-2.5 py-1.5 font-mono dark:border-slate-800 dark:bg-slate-900"
                      >
                        <span>
                          #{a.attemptNumber} {a.gatewayCode} ({a.circuitStateAtAttempt})
                        </span>
                        <span
                          className={
                            a.status === 'SUCCEEDED'
                              ? 'text-emerald-700 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }
                        >
                          {a.status} · {a.latencyMs}ms
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

