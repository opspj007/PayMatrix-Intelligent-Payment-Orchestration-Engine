import React, { useEffect, useState } from 'react';
import { AlertTriangle, Check } from 'lucide-react';
import { Gateway } from '../types/paymatrix';

interface GatewayErrorThresholdControlProps {
  gateway: Gateway;
  busy: boolean;
  onUpdate: (updates: {
    errorRateThresholdEnabled?: boolean;
    errorRateThresholdPct?: number;
  }) => Promise<void>;
}

export const GatewayErrorThresholdControl: React.FC<GatewayErrorThresholdControlProps> = ({
  gateway,
  busy,
  onUpdate,
}) => {
  const [thresholdInput, setThresholdInput] = useState<string>(
    String(gateway.errorRateThresholdPct ?? 10)
  );
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    setThresholdInput(String(gateway.errorRateThresholdPct ?? 10));
  }, [gateway.errorRateThresholdPct]);

  const currentErrorRatePct = Number(((1 - gateway.successRate) * 100).toFixed(1));
  const enabled = Boolean(gateway.errorRateThresholdEnabled);
  const activeThreshold = gateway.errorRateThresholdPct ?? 10;
  const breached = enabled && currentErrorRatePct >= activeThreshold;

  const handleToggle = async () => {
    await onUpdate({ errorRateThresholdEnabled: !enabled });
  };

  const handleSave = async () => {
    const parsed = parseFloat(thresholdInput);
    const clamped = Number.isFinite(parsed)
      ? Math.round(Math.max(0.5, Math.min(95, parsed)) * 10) / 10
      : 10;
    setThresholdInput(String(clamped));
    await onUpdate({
      errorRateThresholdPct: clamped,
      errorRateThresholdEnabled: enabled,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 1800);
  };

  return (
    <div className="flex flex-wrap items-center gap-3 text-xs">
      <button
        type="button"
        role="switch"
        aria-checked={enabled}
        aria-label={`Toggle custom error-rate circuit breaker for ${gateway.name}`}
        disabled={busy}
        onClick={() => void handleToggle()}
        className="inline-flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
      >
        <span
          className={`relative inline-flex h-4 w-7 shrink-0 items-center rounded-full transition-colors ${
            enabled ? 'bg-slate-900 dark:bg-slate-100' : 'bg-slate-300 dark:bg-slate-700'
          }`}
        >
          <span
            className={`inline-block h-3 w-3 transform rounded-full bg-white transition-transform dark:bg-slate-900 ${
              enabled ? 'translate-x-3.5' : 'translate-x-0.5'
            }`}
          />
        </span>
        <span>Error-Rate Trip: {enabled ? 'On' : 'Off'}</span>
      </button>

      <div
        className={`flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1 dark:border-slate-700 dark:bg-slate-950 ${
          enabled ? '' : 'opacity-65'
        }`}
      >
        <label
          htmlFor={`gw-err-${gateway.code}`}
          className="text-[11px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap"
        >
          Trip Limit (%)
        </label>
        <input
          id={`gw-err-${gateway.code}`}
          type="number"
          min={0.5}
          max={95}
          step={0.5}
          value={thresholdInput}
          onChange={(e) => setThresholdInput(e.target.value)}
          className="w-14 bg-transparent font-mono text-xs tabular-nums text-slate-900 focus:outline-none dark:text-slate-100"
        />
        <button
          type="button"
          disabled={busy}
          onClick={() => void handleSave()}
          className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-0.5 text-[11px] font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white whitespace-nowrap"
        >
          {savedNotice ? <Check className="h-3 w-3" /> : null}
          <span>{savedNotice ? 'Saved' : 'Save'}</span>
        </button>
      </div>

      <span
        className={`font-mono text-[11px] tabular-nums whitespace-nowrap ${
          breached
            ? 'inline-flex items-center gap-1 font-medium text-rose-700 dark:text-rose-400'
            : 'text-slate-500 dark:text-slate-400'
        }`}
      >
        {breached && <AlertTriangle className="h-3.5 w-3.5 shrink-0" />}
        <span>
          Rolling Error: {currentErrorRatePct.toFixed(1)}%
          {enabled ? ` / ${activeThreshold.toFixed(1)}% max` : ' (threshold paused)'}
        </span>
      </span>
    </div>
  );
};
