import React, { useEffect, useState } from 'react';
import { BookmarkPlus, BrainCircuit, Sparkles, Trash2, Zap } from 'lucide-react';
import { InvestigationNote, Transaction } from '../types/paymatrix';

interface IntelligenceLabViewProps {
  transactions: Transaction[];
  investigations: InvestigationNote[];
  onDeepDiagnose: (
    question: string
  ) => Promise<{ model: string; thinkingLevel: string; latencyMs: number; analysis: string }>;
  onFastTriage: (
    txId: number
  ) => Promise<{ model: string; latencyMs: number; analysis: string }>;
  onSaveInvestigation: (note: {
    title: string;
    modelUsed: string;
    txCode?: string;
    summary: string;
  }) => Promise<void>;
  onDeleteInvestigation: (id: string) => Promise<void>;
}

const DIAGNOSTIC_PROMPTS = [
  'Analyze open circuit breakers, failover latency cascades, and suggest optimal routing weights.',
  'Audit our current fee-vs-success trade-off across Stripe, Adyen, Checkout, and Razorpay.',
  'Investigate unresolved reconciliation discrepancies and fraud blocks in our recent ledger.',
];

export const IntelligenceLabView: React.FC<IntelligenceLabViewProps> = ({
  transactions,
  investigations,
  onDeepDiagnose,
  onFastTriage,
  onSaveInvestigation,
  onDeleteInvestigation,
}) => {
  const [question, setQuestion] = useState(DIAGNOSTIC_PROMPTS[0]);
  const [deepLoading, setDeepLoading] = useState(false);
  const [deepError, setDeepError] = useState<string | null>(null);
  const [deepResult, setDeepResult] = useState<{
    model: string;
    thinkingLevel: string;
    latencyMs: number;
    analysis: string;
  } | null>(null);

  const [selectedTxId, setSelectedTxId] = useState<number>(transactions[0]?.id ?? 0);

  useEffect(() => {
    if (transactions.length > 0 && !transactions.some((t) => t.id === selectedTxId)) {
      setSelectedTxId(transactions[0].id);
    }
  }, [transactions, selectedTxId]);
  const [fastLoading, setFastLoading] = useState(false);
  const [fastError, setFastError] = useState<string | null>(null);
  const [fastResult, setFastResult] = useState<{
    model: string;
    latencyMs: number;
    analysis: string;
    txCode?: string;
  } | null>(null);

  const [savingNote, setSavingNote] = useState(false);

  const handleDeepRun = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;
    setDeepLoading(true);
    setDeepError(null);
    try {
      const res = await onDeepDiagnose(question.trim());
      setDeepResult(res);
    } catch (err: any) {
      setDeepError(err?.message || 'Deep diagnostic failed.');
    } finally {
      setDeepLoading(false);
    }
  };

  const handleFastRun = async () => {
    if (!selectedTxId) return;
    setFastLoading(true);
    setFastError(null);
    try {
      const tx = transactions.find((t) => t.id === selectedTxId);
      const res = await onFastTriage(selectedTxId);
      setFastResult({ ...res, txCode: tx?.txCode });
    } catch (err: any) {
      setFastError(err?.message || 'Fast triage failed.');
    } finally {
      setFastLoading(false);
    }
  };

  const handleArchive = async (
    title: string,
    modelUsed: string,
    summary: string,
    txCode?: string
  ) => {
    setSavingNote(true);
    try {
      await onSaveInvestigation({ title, modelUsed, summary, txCode });
    } finally {
      setSavingNote(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          Orchestration Intelligence Lab
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Combine deep-thinking root-cause diagnostics (ThinkingLevel.HIGH) with sub-second transaction fraud triage (gemini-3.1-flash-lite).
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        {/* Deep Thinking Diagnostics */}
        <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-7">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BrainCircuit className="h-4 w-4 text-blue-600 dark:text-blue-400" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                Deep Incident & Architecture Diagnostics
              </h2>
            </div>
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
              gemini-4-hydrogen · ThinkingLevel.HIGH
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {DIAGNOSTIC_PROMPTS.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setQuestion(p)}
                className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-left text-xs text-slate-700 hover:bg-slate-100 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                {p}
              </button>
            ))}
          </div>

          <form onSubmit={handleDeepRun} className="space-y-3">
            <textarea
              rows={3}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask a complex question about live circuit breakers, routing weights, latency spikes, or reconciliation variances..."
              className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-900 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
            <button
              type="submit"
              disabled={deepLoading}
              className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>{deepLoading ? 'Reasoning on live telemetry...' : 'Run Deep Diagnosis'}</span>
            </button>
          </form>

          {deepError && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300">
              {deepError}
            </div>
          )}

          {deepResult && (
            <div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-950">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2 dark:border-slate-800">
                <span className="font-mono text-slate-600 dark:text-slate-400">
                  {deepResult.model} · Thinking {deepResult.thinkingLevel} ·{' '}
                  <span className="tabular-nums">{deepResult.latencyMs} ms</span>
                </span>
                <button
                  type="button"
                  disabled={savingNote}
                  onClick={() =>
                    void handleArchive(
                      question.slice(0, 120),
                      deepResult.model,
                      deepResult.analysis
                    )
                  }
                  className="inline-flex items-center gap-1 font-medium text-blue-600 hover:underline dark:text-blue-400"
                >
                  <BookmarkPlus className="h-3.5 w-3.5" />
                  <span>Save to Firestore</span>
                </button>
              </div>
              <div className="whitespace-pre-wrap leading-relaxed text-slate-800 dark:text-slate-200">
                {deepResult.analysis}
              </div>
            </div>
          )}
        </section>

        {/* Low Latency Triage */}
        <section className="space-y-4 rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 lg:col-span-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                Low-Latency Fraud Triage
              </h2>
            </div>
            <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
              gemini-3.1-flash-lite
            </span>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
              Select Transaction from Ledger
            </label>
            <select
              value={selectedTxId}
              onChange={(e) => setSelectedTxId(Number(e.target.value))}
              className="w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 font-mono text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            >
              {transactions.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.txCode} · {t.status} · Risk {t.riskScore}/100 · ${(t.amountCents / 100).toFixed(2)}
                </option>
              ))}
            </select>

            <button
              type="button"
              onClick={handleFastRun}
              disabled={fastLoading || !selectedTxId}
              className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-800 hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-100"
            >
              <Zap className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
              <span>{fastLoading ? 'Triaging...' : 'Evaluate Risk Signal'}</span>
            </button>
          </div>

          {fastError && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300">
              {fastError}
            </div>
          )}

          {fastResult && (
            <div className="space-y-2 rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs dark:border-slate-800 dark:bg-slate-950">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2 dark:border-slate-800">
                <span className="font-mono text-slate-600 dark:text-slate-400">
                  {fastResult.model} · <span className="tabular-nums">{fastResult.latencyMs} ms</span>
                </span>
                <button
                  type="button"
                  disabled={savingNote}
                  onClick={() =>
                    void handleArchive(
                      `Fraud Triage: ${fastResult.txCode ?? 'Transaction'}`,
                      fastResult.model,
                      fastResult.analysis,
                      fastResult.txCode
                    )
                  }
                  className="inline-flex items-center gap-1 font-medium text-blue-600 hover:underline dark:text-blue-400"
                >
                  <BookmarkPlus className="h-3.5 w-3.5" />
                  <span>Save</span>
                </button>
              </div>
              <p className="whitespace-pre-wrap leading-relaxed text-slate-800 dark:text-slate-200">
                {fastResult.analysis}
              </p>
            </div>
          )}
        </section>
      </div>

      {/* Saved Investigations Archive (Firestore) */}
      <section className="rounded-xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
        <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
          Saved Diagnostic & Triage Archive (Firestore)
        </h2>

        {investigations.length === 0 ? (
          <p className="mt-4 text-xs text-slate-500 dark:text-slate-400">
            No archived reports yet. Run a diagnosis above and click "Save to Firestore" to persist it across sessions.
          </p>
        ) : (
          <div className="mt-4 divide-y divide-slate-100 rounded-lg border border-slate-200 dark:divide-slate-800 dark:border-slate-800">
            {investigations.map((note) => (
              <div key={note.id} className="space-y-2 p-4 text-xs">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-semibold text-slate-900 dark:text-slate-100">{note.title}</p>
                    <p className="mt-0.5 font-mono text-slate-500 dark:text-slate-400">
                      {note.modelUsed}
                      {note.txCode ? ` · ${note.txCode}` : ''}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => void onDeleteInvestigation(note.id)}
                    className="rounded p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    aria-label="Delete archived report"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
                <p className="whitespace-pre-wrap leading-relaxed text-slate-700 dark:text-slate-300">
                  {note.summary}
                </p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
