import React, { useState } from 'react';
import { AlertTriangle, CheckCircle2, RefreshCw } from 'lucide-react';
import { formatDateTime, formatMoney } from '../lib/format';
import {
  Gateway,
  ReconciliationBatch,
  ReconciliationDiscrepancy,
} from '../types/paymatrix';

interface ReconciliationViewProps {
  gateways: Gateway[];
  batches: ReconciliationBatch[];
  discrepancies: ReconciliationDiscrepancy[];
  onRunReconciliation: (gatewayCode: string, injectDiscrepancy: boolean) => Promise<void>;
  onResolveDiscrepancy: (id: number, note: string) => Promise<void>;
}

export const ReconciliationView: React.FC<ReconciliationViewProps> = ({
  gateways,
  batches,
  discrepancies,
  onRunReconciliation,
  onResolveDiscrepancy,
}) => {
  const [gatewayCode, setGatewayCode] = useState('ALL');
  const [injectDiscrepancy, setInjectDiscrepancy] = useState(false);
  const [running, setRunning] = useState(false);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [resolvingId, setResolvingId] = useState<number | null>(null);

  const handleRun = async (e: React.FormEvent) => {
    e.preventDefault();
    setRunning(true);
    try {
      await onRunReconciliation(gatewayCode, injectDiscrepancy);
    } finally {
      setRunning(false);
    }
  };

  const handleResolve = async (id: number) => {
    setResolvingId(id);
    try {
      await onResolveDiscrepancy(
        id,
        notes[id] || 'Confirmed provider interchange fee variance and settled ledger.'
      );
    } finally {
      setResolvingId(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="border-b border-slate-200 pb-6 dark:border-slate-800">
        <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          Automatic Payment Reconciliation
        </h1>
        <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">
          Cross-check PayMatrix authorization records against provider settlement batches and resolve fee or amount variances.
        </p>
      </div>

      {/* Run Reconciliation Bar */}
      <form
        onSubmit={handleRun}
        className="flex flex-col gap-4 rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 sm:flex-row sm:items-end"
      >
        <div className="flex-1">
          <label className="block text-xs font-medium text-slate-600 dark:text-slate-400">
            Settlement Scope
          </label>
          <select
            value={gatewayCode}
            onChange={(e) => setGatewayCode(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
          >
            <option value="ALL">All Unreconciled Gateways</option>
            {gateways.map((g) => (
              <option key={g.code} value={g.code}>
                {g.name}
              </option>
            ))}
          </select>
        </div>

        <label className="flex cursor-pointer items-center gap-2 pb-2 text-xs font-medium text-slate-700 dark:text-slate-300">
          <input
            type="checkbox"
            checked={injectDiscrepancy}
            onChange={(e) => setInjectDiscrepancy(e.target.checked)}
            className="h-4 w-4 rounded border-slate-300"
          />
          <span>Simulate Provider Settlement Mismatch</span>
        </label>

        <button
          type="submit"
          disabled={running}
          className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${running ? 'animate-spin' : ''}`} />
          <span>{running ? 'Reconciling...' : 'Execute Settlement Match'}</span>
        </button>
      </form>

      {/* Discrepancy Queue */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Settlement Discrepancies ({discrepancies.filter((d) => !d.resolved).length} Open)
          </h2>
        </div>

        {discrepancies.length === 0 ? (
          <div className="px-5 py-8 text-center text-xs text-slate-500 dark:text-slate-400">
            No discrepancies flagged across recent batches.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {discrepancies.map((d) => (
              <div
                key={d.id}
                className="flex flex-col gap-4 px-5 py-4 lg:flex-row lg:items-center lg:justify-between"
              >
                <div className="space-y-1 text-xs">
                  <div className="flex items-center gap-2">
                    {d.resolved ? (
                      <span className="inline-flex items-center gap-1 font-medium text-emerald-700 dark:text-emerald-400">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        Resolved
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 font-medium text-amber-700 dark:text-amber-400">
                        <AlertTriangle className="h-3.5 w-3.5" />
                        {d.discrepancyType}
                      </span>
                    )}
                    <span className="text-slate-400">·</span>
                    <span className="font-mono text-slate-600 dark:text-slate-300">
                      Tx #{d.transactionId}
                    </span>
                  </div>
                  <p className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    Expected {formatMoney(d.expectedCents)} vs Settled {formatMoney(d.settledCents)}{' '}
                    (Delta {formatMoney(d.expectedCents - d.settledCents)})
                  </p>
                  {d.resolutionNote && (
                    <p className="text-slate-500 dark:text-slate-400">Note: {d.resolutionNote}</p>
                  )}
                </div>

                {!d.resolved && (
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="text"
                      value={notes[d.id] ?? ''}
                      onChange={(e) => setNotes((p) => ({ ...p, [d.id]: e.target.value }))}
                      placeholder="Audit resolution note..."
                      className="w-60 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs text-slate-900 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                    />
                    <button
                      type="button"
                      disabled={resolvingId === d.id}
                      onClick={() => void handleResolve(d.id)}
                      className="rounded-lg bg-slate-900 px-3.5 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900"
                    >
                      {resolvingId === d.id ? 'Resolving...' : 'Resolve & Reconcile'}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Reconciliation Batch History */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Reconciliation Batch History
          </h2>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <th className="px-5 py-3 font-medium">Batch Code</th>
                <th className="px-5 py-3 font-medium">Scope</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 text-right font-medium">Checked / Matched</th>
                <th className="px-5 py-3 text-right font-medium">Volume</th>
                <th className="px-5 py-3 font-medium">Summary</th>
                <th className="px-5 py-3 text-right font-medium">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
              {batches.map((b) => (
                <tr key={b.id} className="h-10">
                  <td className="px-5 py-2.5 font-mono text-slate-900 dark:text-slate-100">
                    {b.batchCode}
                  </td>
                  <td className="px-5 py-2.5 font-mono text-slate-600 dark:text-slate-300">
                    {b.gatewayCode}
                  </td>
                  <td className="px-5 py-2.5 font-medium text-slate-800 dark:text-slate-200">
                    {b.status}
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    {b.totalChecked} / {b.matchedCount}
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {formatMoney(b.totalVolumeCents)}
                  </td>
                  <td className="px-5 py-2.5 text-slate-600 dark:text-slate-400">{b.summary}</td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-500 dark:text-slate-400">
                    {formatDateTime(b.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
