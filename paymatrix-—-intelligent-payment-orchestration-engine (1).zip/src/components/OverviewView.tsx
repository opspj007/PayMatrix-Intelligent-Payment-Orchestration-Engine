import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Download,
  Play,
  RefreshCw,
  RotateCcw,
  Search,
  ShieldAlert,
  Sparkles,
  XCircle,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { formatDateTime, formatMoney } from '../lib/format';
import { DashboardData, Transaction } from '../types/paymatrix';

interface OverviewViewProps {
  data: DashboardData;
  wsConnected: boolean;
  onRunBurst: () => Promise<void>;
  onRunReconciliation: () => Promise<void>;
  onFastFraudTriage: (txId: number) => Promise<{ model: string; latencyMs: number; analysis: string }>;
  onIssueRefund: (txId: number, amountCents: number, reason: string) => Promise<void>;
  onNavigate: (tab: string) => void;
  actionLoading: string | null;
}

export const OverviewView: React.FC<OverviewViewProps> = ({
  data,
  wsConnected,
  onRunBurst,
  onRunReconciliation,
  onFastFraudTriage,
  onIssueRefund,
  onNavigate,
  actionLoading,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [expandedTxId, setExpandedTxId] = useState<number | null>(null);
  const [triageResults, setTriageResults] = useState<
    Record<number, { model: string; latencyMs: number; analysis: string }>
  >({});
  const [triageLoadingId, setTriageLoadingId] = useState<number | null>(null);
  const [triageError, setTriageError] = useState<string | null>(null);

  const [refundInputs, setRefundInputs] = useState<Record<number, { amount: string; reason: string }>>({});
  const [refundBusyId, setRefundBusyId] = useState<number | null>(null);
  const [refundMsg, setRefundMsg] = useState<Record<number, string>>({});
  const [throughputMode, setThroughputMode] = useState<'status' | 'gateway'>('status');

  const globalThreshold = data.policy?.latencyAlertThresholdMs ?? 250;

  const gatewayThresholdMap = useMemo(() => {
    const map = new Map<string, number>();
    for (const gw of data.gateways) {
      map.set(gw.code, gw.latencyAlertThresholdMs ?? globalThreshold);
    }
    return map;
  }, [data.gateways, globalThreshold]);

  const getEffectiveThreshold = (tx: Transaction) =>
    (tx.selectedGatewayCode && gatewayThresholdMap.get(tx.selectedGatewayCode)) || globalThreshold;

  const breachingGateways = useMemo(
    () => data.gateways.filter((g) => g.avgLatencyMs > (g.latencyAlertThresholdMs ?? globalThreshold)),
    [data.gateways, globalThreshold]
  );

  const breachingTransactions = useMemo(
    () => data.transactions.filter((tx) => tx.latencyMs > getEffectiveThreshold(tx)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [data.transactions, gatewayThresholdMap, globalThreshold]
  );

  const meanLatencyBreached = data.metrics.avgLatencyMs > globalThreshold;

  const filteredTransactions = useMemo(() => {
    return data.transactions.filter((tx) => {
      const matchesStatus =
        statusFilter === 'ALL'
          ? true
          : statusFilter === 'LATENCY_BREACH'
            ? tx.latencyMs > getEffectiveThreshold(tx)
            : tx.status === statusFilter;
      const q = searchQuery.trim().toLowerCase();
      if (!q) return matchesStatus;
      return (
        matchesStatus &&
        (tx.txCode.toLowerCase().includes(q) ||
          tx.orderRef.toLowerCase().includes(q) ||
          tx.customerEmail.toLowerCase().includes(q) ||
          (tx.selectedGatewayCode ?? '').toLowerCase().includes(q) ||
          tx.idempotencyKey.toLowerCase().includes(q))
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data.transactions, searchQuery, statusFilter, gatewayThresholdMap, globalThreshold]);

  const providerVolumeDist = useMemo(() => {
    const total = data.gateways.reduce((acc, g) => acc + g.totalVolumeCents, 0) || 1;
    return [...data.gateways]
      .sort((a, b) => b.totalVolumeCents - a.totalVolumeCents)
      .map((g) => ({
        code: g.code,
        name: g.name,
        volumeCents: g.totalVolumeCents,
        sharePct: Number(((g.totalVolumeCents / total) * 100).toFixed(1)),
      }));
  }, [data.gateways]);

  const throughputSeries = useMemo(() => {
    const points = data.throughput24h ?? [];
    return points.map((pt) => {
      const dt = new Date(pt.hourIso);
      const localHour = Number.isNaN(dt.getTime())
        ? pt.hourLabel
        : `${String(dt.getHours()).padStart(2, '0')}:00`;
      return {
        ...pt,
        localHour,
      };
    });
  }, [data.throughput24h]);

  const throughputStats = useMemo(() => {
    const total24h = throughputSeries.reduce((acc, p) => acc + p.total, 0);
    const peakPerHour = throughputSeries.reduce((max, p) => Math.max(max, p.total), 0);
    const activeHours = throughputSeries.filter((p) => p.total > 0).length;
    return { total24h, peakPerHour, activeHours };
  }, [throughputSeries]);

  const handleTriage = async (tx: Transaction) => {
    setTriageError(null);
    setTriageLoadingId(tx.id);
    try {
      const res = await onFastFraudTriage(tx.id);
      setTriageResults((prev) => ({ ...prev, [tx.id]: res }));
    } catch (err: any) {
      setTriageError(err?.message || 'Fraud triage failed.');
    } finally {
      setTriageLoadingId(null);
    }
  };

  const handleRefundSubmit = async (tx: Transaction) => {
    const remainingCents = tx.amountCents - (tx.refundedCents ?? 0);
    const input = refundInputs[tx.id] ?? {
      amount: (remainingCents / 100).toFixed(2),
      reason: 'Customer requested refund',
    };
    const parsed = parseFloat(input.amount);
    const amountCents = Math.round((Number.isFinite(parsed) ? parsed : 0) * 100);
    setRefundBusyId(tx.id);
    setRefundMsg((prev) => ({ ...prev, [tx.id]: '' }));
    try {
      await onIssueRefund(tx.id, amountCents, input.reason);
      setRefundMsg((prev) => ({
        ...prev,
        [tx.id]: `Refund of ${formatMoney(amountCents, tx.currency)} issued & webhook dispatched.`,
      }));
    } catch (err: any) {
      setRefundMsg((prev) => ({ ...prev, [tx.id]: err?.message || 'Refund failed.' }));
    } finally {
      setRefundBusyId(null);
    }
  };

  const handleExportCsv = () => {
    const headers = [
      'txCode',
      'orderRef',
      'status',
      'gateway',
      'amount',
      'currency',
      'feeCents',
      'refundedCents',
      'latencyMs',
      'riskScore',
      'customerEmail',
      'customerCountry',
      'createdAt',
    ];
    const escapeCsv = (val: unknown) => {
      const s = String(val ?? '');
      return s.includes(',') || s.includes('"') ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const rows = filteredTransactions.map((t) =>
      [
        t.txCode,
        t.orderRef,
        t.status,
        t.selectedGatewayCode ?? '',
        (t.amountCents / 100).toFixed(2),
        t.currency,
        t.feeCents,
        t.refundedCents ?? 0,
        t.latencyMs,
        t.riskScore,
        t.customerEmail,
        t.customerCountry,
        t.createdAt,
      ]
        .map(escapeCsv)
        .join(',')
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `paymatrix-ledger-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const renderStatusLabel = (status: Transaction['status']) => {
    switch (status) {
      case 'SUCCEEDED':
      case 'RECONCILED':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
            <span>{status === 'RECONCILED' ? 'Reconciled' : 'Succeeded'}</span>
          </span>
        );
      case 'REFUNDED':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 dark:text-blue-400">
            <RotateCcw className="h-3.5 w-3.5 shrink-0" />
            <span>Refunded</span>
          </span>
        );
      case 'FLAGGED_FRAUD':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
            <ShieldAlert className="h-3.5 w-3.5 shrink-0" />
            <span>Fraud Blocked</span>
          </span>
        );
      case 'FAILED':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 dark:text-rose-400">
            <XCircle className="h-3.5 w-3.5 shrink-0" />
            <span>Failed</span>
          </span>
        );
      default:
        return (
          <span className="text-xs font-medium text-slate-600 dark:text-slate-400">{status}</span>
        );
    }
  };

  const renderCircuitLabel = (state: string) => {
    if (state === 'CLOSED') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400">
          <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
          <span>CLOSED</span>
        </span>
      );
    }
    if (state === 'HALF_OPEN') {
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 dark:text-amber-400">
          <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
          <span>HALF_OPEN</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 dark:text-rose-400">
        <XCircle className="h-3.5 w-3.5 shrink-0" />
        <span>OPEN</span>
      </span>
    );
  };

  return (
    <div className="space-y-8">
      {/* Top Action & Real-Time Stream Bar */}
      <div className="flex flex-col gap-4 border-b border-slate-200 pb-6 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
            Orchestration Overview
          </h1>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span
              className={`inline-flex items-center gap-1.5 font-medium ${
                wsConnected
                  ? 'text-emerald-700 dark:text-emerald-400'
                  : 'text-amber-700 dark:text-amber-400'
              }`}
            >
              <span
                className={`h-1.5 w-1.5 rounded-full ${
                  wsConnected ? 'bg-emerald-600 dark:bg-emerald-400' : 'bg-amber-500'
                }`}
              />
              {wsConnected ? 'WebSocket Stream Connected' : 'WebSocket Reconnecting'}
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              Queue Depth: {data.metrics.queueDepth}
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              Open Circuits: {data.metrics.openCircuits}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onRunBurst}
            disabled={actionLoading === 'burst'}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-medium text-slate-800 transition-colors hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
          >
            <Play className="h-3.5 w-3.5" />
            <span>{actionLoading === 'burst' ? 'Dispatching...' : 'Simulate Traffic Burst'}</span>
          </button>

          <button
            type="button"
            onClick={onRunReconciliation}
            disabled={actionLoading === 'reconcile'}
            className="inline-flex items-center gap-2 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${actionLoading === 'reconcile' ? 'animate-spin' : ''}`} />
            <span>{actionLoading === 'reconcile' ? 'Reconciling...' : 'Run Reconciliation'}</span>
          </button>
        </div>
      </div>

      {/* Latency Alert Threshold Breach Banner */}
      {(meanLatencyBreached || breachingGateways.length > 0 || breachingTransactions.length > 0) && (
        <div
          role="alert"
          className="flex flex-col gap-3 rounded-xl border border-amber-300 bg-amber-50 px-5 py-4 text-xs text-amber-950 dark:border-amber-800/70 dark:bg-amber-950/30 dark:text-amber-100 sm:flex-row sm:items-center sm:justify-between"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-700 dark:text-amber-400" />
            <div className="space-y-0.5">
              <p className="font-semibold">
                Transaction Latency Alert Triggered
              </p>
              <p className="text-amber-900/90 dark:text-amber-200/90 tabular-nums">
                {meanLatencyBreached
                  ? `Mean orchestration latency (${data.metrics.avgLatencyMs} ms) exceeds global ${globalThreshold} ms limit. `
                  : ''}
                {breachingGateways.length > 0
                  ? `${breachingGateways.length} gateway node(s) above configured latency threshold. `
                  : ''}
                {breachingTransactions.length > 0
                  ? `${breachingTransactions.length} transaction(s) exceeded latency threshold.`
                  : ''}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {breachingTransactions.length > 0 && (
              <button
                type="button"
                onClick={() => setStatusFilter('LATENCY_BREACH')}
                className="rounded-lg border border-amber-400/70 bg-white px-3 py-1.5 text-xs font-medium text-amber-950 hover:bg-amber-100 dark:border-amber-700 dark:bg-slate-900 dark:text-amber-100 dark:hover:bg-slate-800 whitespace-nowrap"
              >
                Isolate Breaches ({breachingTransactions.length})
              </button>
            )}
            <button
              type="button"
              onClick={() => onNavigate('gateways')}
              className="rounded-lg bg-amber-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-amber-800 dark:bg-amber-400 dark:text-slate-950 whitespace-nowrap"
            >
              Adjust Thresholds
            </button>
          </div>
        </div>
      )}

      {/* 4-Column KPI Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Cleared Volume
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums dark:text-slate-50">
            {formatMoney(data.metrics.totalVolumeCents, 'USD')}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {data.metrics.totalTransactions} orchestrated payments
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Authorization Rate
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums dark:text-slate-50">
            {data.metrics.successRatePct}%
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
            {data.metrics.retrySaves} saved via auto-failover
          </p>
        </div>

        <div
          className={`rounded-xl border p-5 ${
            meanLatencyBreached
              ? 'border-amber-300 bg-amber-50/60 dark:border-amber-800/70 dark:bg-amber-950/20'
              : 'border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900'
          }`}
        >
          <div className="flex items-center justify-between gap-2">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              Mean Orchestration Latency
            </p>
            {meanLatencyBreached && (
              <AlertTriangle className="h-4 w-4 shrink-0 text-amber-700 dark:text-amber-400" />
            )}
          </div>
          <p
            className={`mt-2 font-mono text-2xl font-semibold tracking-tight tabular-nums ${
              meanLatencyBreached
                ? 'text-amber-800 dark:text-amber-300'
                : 'text-slate-900 dark:text-slate-50'
            }`}
          >
            {data.metrics.avgLatencyMs} ms
          </p>
          <p
            className={`mt-1 text-xs tabular-nums ${
              meanLatencyBreached
                ? 'font-medium text-amber-800 dark:text-amber-400'
                : 'text-slate-500 dark:text-slate-400'
            }`}
          >
            {meanLatencyBreached
              ? `Exceeds ${globalThreshold} ms threshold`
              : `Within ${globalThreshold} ms threshold · ${breachingTransactions.length} breach(es)`}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Fraud Pre-Dispatch Blocks
          </p>
          <p className="mt-2 font-mono text-2xl font-semibold tracking-tight text-slate-900 tabular-nums dark:text-slate-50">
            {data.metrics.fraudBlocked}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Threshold {data.policy?.fraudThreshold ?? 75}/100 risk score
          </p>
        </div>
      </div>

      {/* Latency Percentiles, Fee Savings & Provider Volume Share */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:col-span-5">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
            Tail Latency & Cost Optimization
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Percentile distribution and fee savings vs 2.9% + $0.30 baseline
          </p>

          <div className="mt-4 grid grid-cols-3 gap-4 border-b border-slate-100 pb-4 dark:border-slate-800">
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">p50</p>
              <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-50">
                {data.metrics.p50LatencyMs} ms
              </p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">p95</p>
              <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-50">
                {data.metrics.p95LatencyMs} ms
              </p>
            </div>
            <div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">p99</p>
              <p className="mt-1 font-mono text-lg font-semibold tabular-nums text-slate-900 dark:text-slate-50">
                {data.metrics.p99LatencyMs} ms
              </p>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-4 text-xs">
            <div>
              <p className="text-slate-500 dark:text-slate-400">Estimated Fee Savings</p>
              <p className="mt-1 font-mono text-base font-semibold tabular-nums text-emerald-700 dark:text-emerald-400">
                {formatMoney(data.metrics.estimatedFeeSavingsCents ?? 0, 'USD')}
              </p>
            </div>
            <div>
              <p className="text-slate-500 dark:text-slate-400">Total Refunded</p>
              <p className="mt-1 font-mono text-base font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                {formatMoney(data.metrics.totalRefundedCents ?? 0, 'USD')}
              </p>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 lg:col-span-7">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
                Provider Volume Distribution
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Cumulative volume share across active payment rails
              </p>
            </div>
            <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
              Rate Bucket: {data.metrics.rateLimiter?.remainingTokens ?? 0}/
              {data.metrics.rateLimiter?.capacity ?? 25}
            </span>
          </div>

          <div className="mt-4 space-y-3">
            {providerVolumeDist.map((pv) => (
              <div key={pv.code} className="space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-800 dark:text-slate-200">
                    {pv.name}
                  </span>
                  <span className="font-mono tabular-nums text-slate-600 dark:text-slate-400">
                    {formatMoney(pv.volumeCents, 'USD')} ({pv.sharePct}%)
                  </span>
                </div>
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
                  <div
                    className="h-full rounded-full bg-slate-900 dark:bg-slate-200"
                    style={{ width: `${Math.max(2, pv.sharePct)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Gateway Throughput (24-Hour Historical API Transaction Counts) */}
      <section className="rounded-xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-3 border-b border-slate-100 pb-4 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Gateway Throughput
            </h2>
            <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>Historical API transaction counts over the last 24 hours</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                24h Total: {throughputStats.total24h}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                Peak/hr: {throughputStats.peakPerHour}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1 self-start rounded-lg bg-slate-100 p-1 dark:bg-slate-800 sm:self-auto">
            <button
              type="button"
              onClick={() => setThroughputMode('status')}
              className={`rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                throughputMode === 'status'
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              By Outcome
            </button>
            <button
              type="button"
              onClick={() => setThroughputMode('gateway')}
              className={`rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                throughputMode === 'gateway'
                  ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              By Gateway
            </button>
          </div>
        </div>

        <div className="mt-4 h-64 w-full">
          {throughputSeries.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center rounded-lg border border-dashed border-slate-200 text-center dark:border-slate-800">
              <p className="text-xs font-medium text-slate-600 dark:text-slate-400">
                No throughput telemetry available for the last 24 hours.
              </p>
              <button
                type="button"
                onClick={() => onNavigate('dispatch')}
                className="mt-3 rounded-lg bg-slate-900 px-3 py-1.5 text-xs font-medium text-white dark:bg-slate-100 dark:text-slate-900"
              >
                Dispatch Payment
              </button>
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={throughputSeries}
                margin={{ top: 8, right: 12, left: -16, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="currentColor"
                  className="text-slate-200 dark:text-slate-800"
                />
                <XAxis
                  dataKey="localHour"
                  tick={{ fontSize: 11, fill: '#64748B' }}
                  tickLine={false}
                  axisLine={false}
                  interval={2}
                />
                <YAxis
                  allowDecimals={false}
                  tick={{ fontSize: 11, fill: '#64748B' }}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip
                  cursor={{ fill: 'rgba(148, 163, 184, 0.12)' }}
                  content={({ active, payload, label }) => {
                    if (!active || !payload || payload.length === 0) return null;
                    const row = payload[0]?.payload as (typeof throughputSeries)[number] | undefined;
                    return (
                      <div className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs shadow-sm dark:border-slate-800 dark:bg-slate-900">
                        <div className="mb-1.5 flex items-center justify-between gap-4 border-b border-slate-100 pb-1 font-mono tabular-nums dark:border-slate-800">
                          <span className="font-semibold text-slate-900 dark:text-slate-100">
                            {label}
                          </span>
                          <span className="text-slate-500 dark:text-slate-400">
                            Total: {row?.total ?? 0}
                          </span>
                        </div>
                        <div className="space-y-1">
                          {payload.map((entry) => (
                            <div
                              key={String(entry.dataKey)}
                              className="flex items-center justify-between gap-4 font-mono tabular-nums"
                            >
                              <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                                <span
                                  className="inline-block h-2 w-2 rounded-xs"
                                  style={{ backgroundColor: entry.color }}
                                />
                                {entry.name}
                              </span>
                              <span className="font-medium text-slate-900 dark:text-slate-100">
                                {entry.value}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  }}
                />
                <Legend
                  wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }}
                  iconType="square"
                  iconSize={8}
                />
                {throughputMode === 'status' ? (
                  <>
                    <Bar
                      dataKey="succeeded"
                      name="Succeeded / Reconciled"
                      stackId="a"
                      fill="#10b981"
                      radius={[0, 0, 0, 0]}
                    />
                    <Bar
                      dataKey="failed"
                      name="Failed / Fraud Blocked"
                      stackId="a"
                      fill="#ef4444"
                      radius={[3, 3, 0, 0]}
                    />
                  </>
                ) : (
                  <>
                    <Bar dataKey="stripe" name="Stripe" stackId="gw" fill="#3b82f6" />
                    <Bar dataKey="adyen" name="Adyen" stackId="gw" fill="#10b981" />
                    <Bar dataKey="checkout" name="Checkout.com" stackId="gw" fill="#6366f1" />
                    <Bar dataKey="razorpay" name="Razorpay" stackId="gw" fill="#f59e0b" />
                    <Bar
                      dataKey="braintree"
                      name="Braintree"
                      stackId="gw"
                      fill="#64748b"
                      radius={[3, 3, 0, 0]}
                    />
                  </>
                )}
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </section>

      {/* Gateway Provider Health Snapshot */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-800">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Active Payment Provider Matrix
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Live circuit breaker states, rolling authorization rates, and fee schedules
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('gateways')}
            className="text-xs font-medium text-blue-600 hover:underline dark:text-blue-400 whitespace-nowrap shrink-0"
          >
            Configure Routing & Circuits
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
                <th className="px-5 py-3 font-medium">Provider</th>
                <th className="px-5 py-3 font-medium">Region</th>
                <th className="px-5 py-3 font-medium">Circuit State</th>
                <th className="px-5 py-3 text-right font-medium">Success Rate</th>
                <th className="px-5 py-3 text-right font-medium">Avg Latency</th>
                <th className="px-5 py-3 text-right font-medium">Fee Schedule</th>
                <th className="px-5 py-3 text-right font-medium">Processed</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
              {data.gateways.map((gw) => (
                <tr
                  key={gw.code}
                  className="h-10 transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/40"
                >
                  <td className="px-5 py-2.5 font-medium text-slate-900 dark:text-slate-100">
                    {gw.name}
                    {!gw.isActive && (
                      <span className="ml-2 text-slate-400">(Disabled)</span>
                    )}
                  </td>
                  <td className="px-5 py-2.5 text-slate-500 dark:text-slate-400">{gw.region}</td>
                  <td className="px-5 py-2.5">{renderCircuitLabel(gw.circuitState)}</td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                    {(gw.successRate * 100).toFixed(1)}%
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums">
                    {gw.avgLatencyMs > (gw.latencyAlertThresholdMs ?? globalThreshold) ? (
                      <span className="inline-flex items-center justify-end gap-1.5 font-medium text-amber-700 dark:text-amber-400">
                        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                        <span>
                          {gw.avgLatencyMs} ms (&gt; {gw.latencyAlertThresholdMs ?? globalThreshold} ms)
                        </span>
                      </span>
                    ) : (
                      <span className="text-slate-600 dark:text-slate-300">
                        {gw.avgLatencyMs} ms
                      </span>
                    )}
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    {(gw.baseFeeBps / 100).toFixed(2)}% + ${(gw.fixedFeeCents / 100).toFixed(2)}
                  </td>
                  <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    {gw.totalTransactions.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Live Transaction Stream Table */}
      <section className="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
        <div className="flex flex-col gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-50">
              Real-Time Transaction Ledger
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Expand any row to inspect failover hop telemetry, idempotency keys, and AI fraud triage
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tx, order, key, email..."
                className="w-56 rounded-lg border border-slate-200 bg-slate-50 py-1.5 pl-8 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
              />
            </div>

            <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1 dark:bg-slate-800">
              {[
                'ALL',
                'SUCCEEDED',
                'RECONCILED',
                'REFUNDED',
                'LATENCY_BREACH',
                'FLAGGED_FRAUD',
                'FAILED',
              ].map((st) => (
                <button
                  key={st}
                  type="button"
                  onClick={() => setStatusFilter(st)}
                  className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    statusFilter === st
                      ? 'bg-white text-slate-900 shadow-sm dark:bg-slate-900 dark:text-slate-100'
                      : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
                  }`}
                >
                  {st === 'ALL'
                    ? 'All'
                    : st === 'FLAGGED_FRAUD'
                      ? 'Fraud'
                      : st === 'LATENCY_BREACH'
                        ? `Slow (${breachingTransactions.length})`
                        : st.charAt(0) + st.slice(1).toLowerCase()}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {triageError && (
          <div className="border-b border-rose-200 bg-rose-50 px-5 py-2.5 text-xs text-rose-700 dark:border-rose-900/50 dark:bg-rose-950/30 dark:text-rose-300">
            {triageError}
          </div>
        )}

        {filteredTransactions.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              No transactions match your current filter.
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Dispatch a payment in the sandbox or clear your search filter.
            </p>
            <button
              type="button"
              onClick={() => onNavigate('dispatch')}
              className="mt-4 rounded-lg bg-slate-900 px-4 py-2 text-xs font-medium text-white dark:bg-slate-100 dark:text-slate-900"
            >
              Open Payment Sandbox
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 dark:border-slate-800 dark:text-slate-400">
                  <th className="w-8 px-3 py-3"></th>
                  <th className="px-3 py-3 font-medium">Transaction</th>
                  <th className="px-3 py-3 font-medium">Status</th>
                  <th className="px-3 py-3 font-medium">Gateway</th>
                  <th className="px-3 py-3 text-right font-medium">Amount</th>
                  <th className="px-3 py-3 text-right font-medium">Attempts</th>
                  <th className="px-3 py-3 text-right font-medium">Latency</th>
                  <th className="px-3 py-3 text-right font-medium">Risk</th>
                  <th className="px-5 py-3 text-right font-medium">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                {filteredTransactions.map((tx) => {
                  const isExpanded = expandedTxId === tx.id;
                  const triage = triageResults[tx.id];
                  return (
                    <React.Fragment key={tx.id}>
                      <tr
                        onClick={() => setExpandedTxId(isExpanded ? null : tx.id)}
                        className="h-10 cursor-pointer transition-colors hover:bg-slate-50 dark:hover:bg-slate-800/40"
                      >
                        <td className="px-3 py-2.5 text-slate-400">
                          {isExpanded ? (
                            <ChevronDown className="h-3.5 w-3.5" />
                          ) : (
                            <ChevronRight className="h-3.5 w-3.5" />
                          )}
                        </td>
                        <td className="px-3 py-2.5">
                          <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
                            {tx.txCode}
                          </span>
                          <span className="ml-2 text-slate-400">· {tx.orderRef}</span>
                        </td>
                        <td className="px-3 py-2.5">{renderStatusLabel(tx.status)}</td>
                        <td className="px-3 py-2.5 font-mono text-slate-700 dark:text-slate-300">
                          {tx.selectedGatewayCode ?? '—'}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums font-medium text-slate-900 dark:text-slate-100">
                          {formatMoney(tx.amountCents, tx.currency)}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {tx.attemptCount}
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono tabular-nums">
                          {tx.latencyMs > getEffectiveThreshold(tx) ? (
                            <span className="inline-flex items-center justify-end gap-1 font-medium text-amber-700 dark:text-amber-400">
                              <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                              <span>
                                {tx.latencyMs} ms (&gt;{getEffectiveThreshold(tx)})
                              </span>
                            </span>
                          ) : (
                            <span className="text-slate-600 dark:text-slate-300">
                              {tx.latencyMs} ms
                            </span>
                          )}
                        </td>
                        <td
                          className={`px-3 py-2.5 text-right font-mono tabular-nums font-medium ${
                            tx.riskScore >= 75
                              ? 'text-rose-600 dark:text-rose-400'
                              : tx.riskScore >= 40
                                ? 'text-amber-600 dark:text-amber-400'
                                : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {tx.riskScore}/100
                        </td>
                        <td className="px-5 py-2.5 text-right font-mono tabular-nums text-slate-500 dark:text-slate-400">
                          {formatDateTime(tx.createdAt)}
                        </td>
                      </tr>

                      {isExpanded && (
                        <tr className="bg-slate-50/70 dark:bg-slate-950/60">
                          <td colSpan={9} className="px-6 py-4">
                            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
                              <div className="space-y-2 text-xs">
                                <p className="font-semibold text-slate-900 dark:text-slate-100">
                                  Orchestration & Idempotency Telemetry
                                </p>
                                <div className="grid grid-cols-2 gap-y-1.5 text-slate-600 dark:text-slate-400">
                                  <span>Customer</span>
                                  <span className="font-mono text-slate-900 dark:text-slate-200">
                                    {tx.customerEmail} ({tx.customerCountry})
                                  </span>
                                  <span>Idempotency Key</span>
                                  <span className="font-mono text-slate-900 dark:text-slate-200 truncate">
                                    {tx.idempotencyKey}
                                  </span>
                                  <span>Gateway Fee</span>
                                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-200">
                                    {formatMoney(tx.feeCents, tx.currency)}
                                  </span>
                                  <span>Refunded Balance</span>
                                  <span className="font-mono tabular-nums text-slate-900 dark:text-slate-200">
                                    {formatMoney(tx.refundedCents ?? 0, tx.currency)} /{' '}
                                    {formatMoney(tx.amountCents, tx.currency)}
                                  </span>
                                  <span>Routing Decision</span>
                                  <span className="text-slate-800 dark:text-slate-200">
                                    {tx.routingReason}
                                  </span>
                                  <span>Risk Evaluation</span>
                                  <span className="text-slate-800 dark:text-slate-200">
                                    {tx.riskReason}
                                  </span>
                                </div>

                                <div className="pt-2">
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      void handleTriage(tx);
                                    }}
                                    disabled={triageLoadingId === tx.id}
                                    className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                                  >
                                    <Sparkles className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                                    <span>
                                      {triageLoadingId === tx.id
                                        ? 'Running Flash-Lite Triage...'
                                        : 'Run Low-Latency Fraud Triage'}
                                    </span>
                                  </button>
                                </div>

                                {triage && (
                                  <div className="mt-3 rounded-lg border border-slate-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900">
                                    <div className="mb-1 flex items-center justify-between text-slate-500 dark:text-slate-400">
                                      <span className="font-mono">{triage.model}</span>
                                      <span className="font-mono tabular-nums">
                                        {triage.latencyMs} ms
                                      </span>
                                    </div>
                                    <p className="whitespace-pre-wrap leading-relaxed text-slate-800 dark:text-slate-200">
                                      {triage.analysis}
                                    </p>
                                  </div>
                                )}

                                {(tx.status === 'SUCCEEDED' || tx.status === 'RECONCILED') &&
                                  tx.amountCents - (tx.refundedCents ?? 0) > 0 && (
                                    <div
                                      onClick={(e) => e.stopPropagation()}
                                      className="mt-3 space-y-2 rounded-lg border border-slate-200 bg-white p-3 text-xs dark:border-slate-800 dark:bg-slate-900"
                                    >
                                      <p className="font-semibold text-slate-900 dark:text-slate-100">
                                        Issue Full or Partial Refund
                                      </p>
                                      <div className="flex flex-wrap items-center gap-2">
                                        <input
                                          type="number"
                                          step="0.01"
                                          min="0.01"
                                          max={((tx.amountCents - (tx.refundedCents ?? 0)) / 100).toFixed(2)}
                                          value={
                                            refundInputs[tx.id]?.amount ??
                                            ((tx.amountCents - (tx.refundedCents ?? 0)) / 100).toFixed(2)
                                          }
                                          onChange={(e) =>
                                            setRefundInputs((prev) => ({
                                              ...prev,
                                              [tx.id]: {
                                                amount: e.target.value,
                                                reason:
                                                  prev[tx.id]?.reason ?? 'Customer requested refund',
                                              },
                                            }))
                                          }
                                          className="w-28 rounded border border-slate-200 bg-slate-50 px-2.5 py-1.5 font-mono text-xs tabular-nums dark:border-slate-700 dark:bg-slate-950"
                                        />
                                        <input
                                          type="text"
                                          value={
                                            refundInputs[tx.id]?.reason ?? 'Customer requested refund'
                                          }
                                          onChange={(e) =>
                                            setRefundInputs((prev) => ({
                                              ...prev,
                                              [tx.id]: {
                                                amount:
                                                  prev[tx.id]?.amount ??
                                                  ((tx.amountCents - (tx.refundedCents ?? 0)) / 100).toFixed(2),
                                                reason: e.target.value,
                                              },
                                            }))
                                          }
                                          placeholder="Refund reason"
                                          className="flex-1 rounded border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs dark:border-slate-700 dark:bg-slate-950"
                                        />
                                        <button
                                          type="button"
                                          disabled={refundBusyId === tx.id}
                                          onClick={() => void handleRefundSubmit(tx)}
                                          className="inline-flex items-center gap-1.5 rounded bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 dark:bg-slate-100 dark:text-slate-900"
                                        >
                                          <RotateCcw className="h-3 w-3" />
                                          <span>
                                            {refundBusyId === tx.id ? 'Refunding...' : 'Issue Refund'}
                                          </span>
                                        </button>
                                      </div>
                                      {refundMsg[tx.id] && (
                                        <p className="text-xs text-slate-600 dark:text-slate-300">
                                          {refundMsg[tx.id]}
                                        </p>
                                      )}
                                    </div>
                                  )}

                                {tx.refunds && tx.refunds.length > 0 && (
                                  <div className="mt-2 space-y-1 text-xs">
                                    <p className="font-medium text-slate-700 dark:text-slate-300">
                                      Refund Ledger ({tx.refunds.length})
                                    </p>
                                    {tx.refunds.map((rf) => (
                                      <div
                                        key={rf.id}
                                        className="flex items-center justify-between rounded border border-slate-200 bg-white px-2.5 py-1.5 font-mono dark:border-slate-800 dark:bg-slate-900"
                                      >
                                        <span>
                                          {rf.refundCode} · {rf.reason}
                                        </span>
                                        <span className="tabular-nums text-blue-700 dark:text-blue-400">
                                          -{formatMoney(rf.amountCents, tx.currency)}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>

                              <div className="space-y-2 text-xs">
                                <p className="font-semibold text-slate-900 dark:text-slate-100">
                                  Gateway Attempt Hop Chain ({tx.attempts.length})
                                </p>
                                {tx.attempts.length === 0 ? (
                                  <p className="text-slate-500 dark:text-slate-400">
                                    No provider attempts executed (blocked at pre-dispatch risk check).
                                  </p>
                                ) : (
                                  <div className="divide-y divide-slate-200 rounded-lg border border-slate-200 bg-white dark:divide-slate-800 dark:border-slate-800 dark:bg-slate-900">
                                    {tx.attempts.map((att) => (
                                      <div
                                        key={att.id}
                                        className="flex items-center justify-between px-3 py-2"
                                      >
                                        <div>
                                          <span className="font-mono font-medium text-slate-900 dark:text-slate-100">
                                            #{att.attemptNumber} · {att.gatewayCode}
                                          </span>
                                          <span className="ml-2 text-slate-500 dark:text-slate-400">
                                            Circuit: {att.circuitStateAtAttempt}
                                          </span>
                                          {att.errorMessage && (
                                            <p className="mt-0.5 text-rose-600 dark:text-rose-400">
                                              {att.errorCode}: {att.errorMessage}
                                            </p>
                                          )}
                                        </div>
                                        <div className="text-right font-mono tabular-nums">
                                          <span
                                            className={
                                              att.status === 'SUCCEEDED'
                                                ? 'text-emerald-700 dark:text-emerald-400'
                                                : 'text-rose-600 dark:text-rose-400'
                                            }
                                          >
                                            {att.status}
                                          </span>
                                          <div className="text-slate-500 dark:text-slate-400">
                                            {att.latencyMs} ms
                                          </div>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
};
