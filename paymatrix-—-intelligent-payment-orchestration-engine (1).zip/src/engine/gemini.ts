import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';

function getAiClient() {
  return new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export interface FraudTriageInput {
  txCode: string;
  amountCents: number;
  currency: string;
  customerEmail: string;
  customerCountry: string;
  paymentMethod: string;
  riskScore: number;
  riskReason: string;
  selectedGatewayCode: string;
}

export async function runFastFraudTriage(input: FraudTriageInput) {
  const start = Date.now();
  const prompt = [
    'Evaluate this payment orchestration telemetry for fraud & routing risk in 3 concise bullet points.',
    `Transaction: ${input.txCode}`,
    `Amount: ${(input.amountCents / 100).toFixed(2)} ${input.currency}`,
    `Customer: ${input.customerEmail} (${input.customerCountry}) via ${input.paymentMethod}`,
    `Gateway: ${input.selectedGatewayCode}`,
    `Deterministic Risk Score: ${input.riskScore}/100 (${input.riskReason})`,
    'Provide: 1) Risk Verdict (APPROVE / STEP_UP_3DS / BLOCK), 2) Key Anomaly Signal, 3) Recommended Action.',
  ].join('\n');

  const ai = getAiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: prompt,
    config: {
      systemInstruction:
        'You are PayMatrix Low-Latency Fraud Triage. Respond with crisp, factual operational guidance under 120 words.',
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
    },
  });

  return {
    model: 'gemini-3.1-flash-lite',
    latencyMs: Date.now() - start,
    analysis: response.text ?? 'No triage response generated.',
  };
}

export interface DeepDiagnoseInput {
  question: string;
  gateways: Array<{
    code: string;
    name: string;
    circuitState: string;
    successRate: number;
    avgLatencyMs: number;
    baseFeeBps: number;
    failureCount: number;
  }>;
  recentTransactions: Array<{
    txCode: string;
    status: string;
    amountCents: number;
    currency: string;
    selectedGatewayCode: string | null;
    attemptCount: number;
    latencyMs: number;
    riskScore: number;
    routingReason: string | null;
  }>;
  discrepancies: Array<{
    transactionId: number;
    expectedCents: number;
    settledCents: number;
    discrepancyType: string;
    resolved: boolean;
  }>;
  policy: {
    successWeight: number;
    latencyWeight: number;
    costWeight: number;
    maxRetries: number;
    fraudThreshold: number;
  };
}

export async function runDeepIncidentDiagnosis(input: DeepDiagnoseInput) {
  const start = Date.now();
  const contextPayload = JSON.stringify(
    {
      policy: input.policy,
      gateways: input.gateways,
      recentTransactions: input.recentTransactions.slice(0, 20),
      openDiscrepancies: input.discrepancies.filter((d) => !d.resolved).slice(0, 10),
    },
    null,
    2
  );

  const ai = getAiClient();
  const response = await ai.models.generateContent({
    model: 'gemini-4-hydrogen',
    contents: `Operator Query: ${input.question}\n\nLive PayMatrix Telemetry Snapshot:\n${contextPayload}`,
    config: {
      systemInstruction:
        'You are the PayMatrix Principal Distributed Systems & Payments Architect. Analyze gateway circuit breakers, failover latency cascades, fee vs success trade-offs, idempotency, and settlement reconciliation discrepancies. Structure your answer with clear sections: Root Cause Assessment, Quantitative Trade-Offs, and Concrete Remediation Steps.',
      thinkingConfig: {
        thinkingLevel: ThinkingLevel.HIGH,
      },
    },
  });

  return {
    model: 'gemini-4-hydrogen',
    thinkingLevel: 'HIGH',
    latencyMs: Date.now() - start,
    analysis: response.text ?? 'No deep diagnostic analysis generated.',
  };
}

const ALLOWED_GATEWAYS = new Set(['stripe', 'adyen', 'checkout', 'razorpay', 'braintree']);
const ALLOWED_CURRENCIES = new Set(['ALL', 'USD', 'EUR', 'GBP', 'SGD', 'INR']);
const ALLOWED_METHODS = new Set(['ALL', 'card', 'wallet', 'sepa_debit', 'ach']);
const ALLOWED_ACTIONS = new Set(['FORCE_GATEWAY', 'CANARY_SPLIT', 'BLOCK_COUNTRY']);

export interface SynthesizedRule {
  name: string;
  conditionCurrency: string;
  conditionMethod: string;
  conditionMinAmountCents: number;
  conditionCountry: string;
  actionType: 'FORCE_GATEWAY' | 'CANARY_SPLIT' | 'BLOCK_COUNTRY';
  targetGatewayCode: string;
  canaryGatewayCode: string | null;
  canaryPct: number;
}

export async function synthesizeRoutingRule(instruction: string): Promise<{
  model: string;
  latencyMs: number;
  rule: SynthesizedRule;
}> {
  const start = Date.now();
  const ai = getAiClient();

  const response = await ai.models.generateContent({
    model: 'gemini-3.1-flash-lite',
    contents: `Convert this payment routing instruction into a deterministic PayMatrix routing rule:\n"${instruction}"`,
    config: {
      systemInstruction: [
        'You convert natural-language payment routing instructions into structured JSON.',
        'Valid gateway codes: stripe, adyen, checkout, razorpay, braintree.',
        'Valid currencies: ALL, USD, EUR, GBP, SGD, INR.',
        'Valid payment methods: ALL, card, wallet, sepa_debit, ach.',
        'Valid conditionCountry: ALL or uppercase 2-letter ISO country code (e.g. US, DE, SG, GB, IN, NG).',
        'Valid actionType: FORCE_GATEWAY (route 100% to targetGatewayCode), CANARY_SPLIT (send canaryPct% to canaryGatewayCode and rest to targetGatewayCode), BLOCK_COUNTRY (reject matching country/criteria).',
      ].join(' '),
      thinkingConfig: { thinkingLevel: ThinkingLevel.MINIMAL },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          conditionCurrency: { type: Type.STRING },
          conditionMethod: { type: Type.STRING },
          conditionMinAmountCents: { type: Type.INTEGER },
          conditionCountry: { type: Type.STRING },
          actionType: { type: Type.STRING },
          targetGatewayCode: { type: Type.STRING },
          canaryGatewayCode: { type: Type.STRING },
          canaryPct: { type: Type.INTEGER },
        },
        required: [
          'name',
          'conditionCurrency',
          'conditionMethod',
          'conditionMinAmountCents',
          'conditionCountry',
          'actionType',
          'targetGatewayCode',
          'canaryPct',
        ],
      },
    },
  });

  const parsed = JSON.parse(response.text || '{}') as Partial<SynthesizedRule>;

  const rawCurrency = String(parsed.conditionCurrency || 'ALL').toUpperCase();
  const conditionCurrency = ALLOWED_CURRENCIES.has(rawCurrency) ? rawCurrency : 'ALL';

  const rawMethod = String(parsed.conditionMethod || 'ALL').toLowerCase();
  const conditionMethod =
    rawMethod === 'all' ? 'ALL' : ALLOWED_METHODS.has(rawMethod) ? rawMethod : 'ALL';

  const rawCountry = String(parsed.conditionCountry || 'ALL').toUpperCase().trim();
  const conditionCountry =
    rawCountry === 'ALL' || /^[A-Z]{2}$/.test(rawCountry) ? rawCountry : 'ALL';

  const rawAction = String(parsed.actionType || 'FORCE_GATEWAY').toUpperCase();
  const actionType = (
    ALLOWED_ACTIONS.has(rawAction) ? rawAction : 'FORCE_GATEWAY'
  ) as SynthesizedRule['actionType'];

  const rawTarget = String(parsed.targetGatewayCode || 'stripe').toLowerCase();
  const targetGatewayCode = ALLOWED_GATEWAYS.has(rawTarget) ? rawTarget : 'stripe';

  const rawCanary = parsed.canaryGatewayCode
    ? String(parsed.canaryGatewayCode).toLowerCase()
    : '';
  const canaryGatewayCode =
    actionType === 'CANARY_SPLIT' && ALLOWED_GATEWAYS.has(rawCanary) ? rawCanary : null;

  const canaryPct =
    actionType === 'CANARY_SPLIT'
      ? Math.max(1, Math.min(99, Math.round(Number(parsed.canaryPct || 20))))
      : 0;

  return {
    model: 'gemini-3.1-flash-lite',
    latencyMs: Date.now() - start,
    rule: {
      name: String(parsed.name || instruction).slice(0, 80),
      conditionCurrency,
      conditionMethod,
      conditionMinAmountCents: Math.max(0, Math.round(Number(parsed.conditionMinAmountCents || 0))),
      conditionCountry,
      actionType,
      targetGatewayCode,
      canaryGatewayCode,
      canaryPct,
    },
  };
}

