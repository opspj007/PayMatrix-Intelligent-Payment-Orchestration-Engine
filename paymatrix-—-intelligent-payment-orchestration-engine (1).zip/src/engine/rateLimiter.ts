interface TokenBucket {
  tokens: number;
  lastRefillMs: number;
  rejectedCount: number;
  acceptedCount: number;
}

const buckets = new Map<number, TokenBucket>();

export interface RateLimitDecision {
  allowed: boolean;
  remainingTokens: number;
  capacity: number;
  rps: number;
  retryAfterMs: number;
  rejectedCount: number;
  acceptedCount: number;
}

export function consumeRateLimitToken(
  userId: number,
  rps: number,
  burstCapacity: number
): RateLimitDecision {
  const safeRps = Math.max(1, Math.min(200, rps));
  const safeCap = Math.max(1, Math.min(500, burstCapacity));
  const now = Date.now();

  let bucket = buckets.get(userId);
  if (!bucket) {
    bucket = {
      tokens: safeCap,
      lastRefillMs: now,
      rejectedCount: 0,
      acceptedCount: 0,
    };
    buckets.set(userId, bucket);
  }

  const elapsedSec = Math.max(0, (now - bucket.lastRefillMs) / 1000);
  bucket.tokens = Math.min(safeCap, bucket.tokens + elapsedSec * safeRps);
  bucket.lastRefillMs = now;

  if (bucket.tokens >= 1) {
    bucket.tokens -= 1;
    bucket.acceptedCount += 1;
    return {
      allowed: true,
      remainingTokens: Math.floor(bucket.tokens),
      capacity: safeCap,
      rps: safeRps,
      retryAfterMs: 0,
      rejectedCount: bucket.rejectedCount,
      acceptedCount: bucket.acceptedCount,
    };
  }

  bucket.rejectedCount += 1;
  const deficit = 1 - bucket.tokens;
  const retryAfterMs = Math.ceil((deficit / safeRps) * 1000);
  return {
    allowed: false,
    remainingTokens: 0,
    capacity: safeCap,
    rps: safeRps,
    retryAfterMs,
    rejectedCount: bucket.rejectedCount,
    acceptedCount: bucket.acceptedCount,
  };
}

export function getRateLimiterStatus(userId: number, rps: number, burstCapacity: number) {
  const safeRps = Math.max(1, Math.min(200, rps));
  const safeCap = Math.max(1, Math.min(500, burstCapacity));
  const now = Date.now();
  const bucket = buckets.get(userId);
  if (!bucket) {
    return {
      remainingTokens: safeCap,
      capacity: safeCap,
      rps: safeRps,
      rejectedCount: 0,
      acceptedCount: 0,
    };
  }
  const elapsedSec = Math.max(0, (now - bucket.lastRefillMs) / 1000);
  const currentTokens = Math.min(safeCap, bucket.tokens + elapsedSec * safeRps);
  return {
    remainingTokens: Math.floor(currentTokens),
    capacity: safeCap,
    rps: safeRps,
    rejectedCount: bucket.rejectedCount,
    acceptedCount: bucket.acceptedCount,
  };
}
