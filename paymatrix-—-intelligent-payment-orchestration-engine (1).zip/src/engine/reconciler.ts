import crypto from 'node:crypto';
import { and, eq, inArray } from 'drizzle-orm';
import { db } from '../db/index.ts';
import {
  auditLogs,
  reconciliationBatches,
  reconciliationDiscrepancies,
  transactions,
} from '../db/schema.ts';
import { eventBus } from './queue.ts';

export async function runAutomaticReconciliation(
  userId: number,
  actorEmail: string,
  gatewayCode = 'ALL',
  injectDiscrepancy = false
) {
  try {
    const conditions = [
      eq(transactions.userId, userId),
      eq(transactions.status, 'SUCCEEDED'),
    ];
    if (gatewayCode !== 'ALL') {
      conditions.push(eq(transactions.selectedGatewayCode, gatewayCode));
    }

    const candidates = await db
      .select()
      .from(transactions)
      .where(and(...conditions));

    if (candidates.length === 0) {
      return {
        batch: null,
        discrepancies: [],
        message: 'No unreconciled SUCCEEDED transactions found for the selected scope.',
      };
    }

    let matchedCount = 0;
    let discrepancyCount = 0;
    let totalVolumeCents = 0;
    const matchedIds: number[] = [];
    const discrepancyDrafts: Array<{
      transactionId: number;
      expectedCents: number;
      settledCents: number;
      discrepancyType: string;
    }> = [];

    for (let i = 0; i < candidates.length; i++) {
      const tx = candidates[i];
      totalVolumeCents += tx.amountCents;

      const triggerVariance =
        (injectDiscrepancy && i === 0) || (!injectDiscrepancy && i === candidates.length - 1 && candidates.length >= 4);

      if (triggerVariance) {
        discrepancyCount += 1;
        const delta = Math.max(50, Math.round(tx.amountCents * 0.008));
        discrepancyDrafts.push({
          transactionId: tx.id,
          expectedCents: tx.amountCents,
          settledCents: tx.amountCents - delta,
          discrepancyType: injectDiscrepancy ? 'AMOUNT_MISMATCH' : 'FEE_VARIANCE',
        });
      } else {
        matchedCount += 1;
        matchedIds.push(tx.id);
      }
    }

    const batchCode = `rec_${crypto.randomBytes(4).toString('hex')}`;
    const status = discrepancyCount > 0 ? 'DISCREPANCY_FOUND' : 'MATCHED';
    const summary =
      discrepancyCount > 0
        ? `${matchedCount} matched cleanly; ${discrepancyCount} settlement discrepancy flagged for review.`
        : `All ${matchedCount} transactions matched against provider settlement report.`;

    const result = await db.transaction(async (txDb) => {
      const [batch] = await txDb
        .insert(reconciliationBatches)
        .values({
          batchCode,
          userId,
          gatewayCode,
          totalChecked: candidates.length,
          matchedCount,
          discrepancyCount,
          totalVolumeCents,
          status,
          summary,
        })
        .returning();

      if (matchedIds.length > 0) {
        await txDb
          .update(transactions)
          .set({
            status: 'RECONCILED',
            reconciledAt: new Date(),
            updatedAt: new Date(),
          })
          .where(inArray(transactions.id, matchedIds));
      }

      const insertedDiscrepancies =
        discrepancyDrafts.length > 0
          ? await txDb
              .insert(reconciliationDiscrepancies)
              .values(
                discrepancyDrafts.map((d) => ({
                  batchId: batch.id,
                  transactionId: d.transactionId,
                  expectedCents: d.expectedCents,
                  settledCents: d.settledCents,
                  discrepancyType: d.discrepancyType,
                }))
              )
              .returning()
          : [];

      await txDb.insert(auditLogs).values({
        userId,
        entityType: 'reconciliation',
        entityId: batch.batchCode,
        action: 'RECONCILIATION_BATCH_EXECUTED',
        actorEmail,
        metadata: {
          gatewayCode,
          totalChecked: candidates.length,
          matchedCount,
          discrepancyCount,
        },
      });

      return { batch, discrepancies: insertedDiscrepancies };
    });

    eventBus.publish({
      type: 'reconciliation:completed',
      userId,
      payload: result,
    });

    return { ...result, message: summary };
  } catch (error) {
    console.error('Reconciliation run failed:', error);
    throw new Error('Failed to execute reconciliation batch.', { cause: error });
  }
}
