import { EventEmitter } from 'node:events';
import { WebSocket, WebSocketServer } from 'ws';

export interface RealtimeEvent {
  type:
    | 'tx:created'
    | 'tx:updated'
    | 'circuit:changed'
    | 'webhook:queued'
    | 'webhook:delivered'
    | 'fraud:flagged'
    | 'reconciliation:completed'
    | 'policy:updated';
  userId?: number;
  payload: Record<string, unknown>;
  timestamp: string;
}

class OrchestrationEventBus extends EventEmitter {
  private wss: WebSocketServer | null = null;
  private clientUserMap = new Map<WebSocket, number>();
  private queueDepth = 0;

  attachWebSocketServer(wss: WebSocketServer) {
    this.wss = wss;
  }

  registerClient(ws: WebSocket, userId: number) {
    this.clientUserMap.set(ws, userId);
    ws.on('close', () => {
      this.clientUserMap.delete(ws);
    });
  }

  incrementQueue() {
    this.queueDepth += 1;
  }

  decrementQueue() {
    this.queueDepth = Math.max(0, this.queueDepth - 1);
  }

  getQueueDepth() {
    return this.queueDepth;
  }

  publish(event: Omit<RealtimeEvent, 'timestamp'>) {
    const fullEvent: RealtimeEvent = {
      ...event,
      timestamp: new Date().toISOString(),
    };
    this.emit('event', fullEvent);

    if (!this.wss) return;
    const serialized = JSON.stringify(fullEvent);

    for (const [client, uid] of this.clientUserMap.entries()) {
      if (client.readyState === WebSocket.OPEN) {
        if (event.userId === undefined || event.userId === uid) {
          client.send(serialized);
        }
      }
    }
  }
}

export const eventBus = new OrchestrationEventBus();
