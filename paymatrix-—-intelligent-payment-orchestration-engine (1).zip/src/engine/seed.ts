import crypto from 'node:crypto';
import { count, eq } from 'drizzle-orm';
import { db } from '../db/index.ts';
import {
  auditLogs,
  gateways,
  reconciliationBatches,
  reconciliationDiscrepancies,
  routingRules,
  transactionAttempts,
  transactions,
  webhookEvents,
} from '../db/schema.ts';

const SANDBOX_GATEWAYS = [
  {
    code: 'stripe',
    name: 'Stripe Sandbox',
    region: 'US-EAST / GLOBAL',
    baseFeeBps: 290,
    fixedFeeCents: 30,
    avgLatencyMs: 142,
    successRate: 0.992,
    circuitState: 'CLOSED',
    failureCount: 0,
    failureThreshold: 3,
    isActive: true,
    simulatedFailureRate: 0.02,
    simulatedLatencyMs: 140,
    totalVolumeCents: 18425000,
    totalTransactions: 1420,
  },
  {
    code: 'adyen',
    name: 'Adyen Sandbox',
    region: 'EU-WEST / GLOBAL',
    baseFeeBps: 245,
    fixedFeeCents: 12,
    avgLatencyMs: 168,
    successRate: 0.988,
    circuitState: 'CLOSED',
    failureCount: 0,
    failureThreshold: 3,
    isActive: true,
    simulatedFailureRate: 0.03,
    simulatedLatencyMs: 165,
    totalVolumeCents: 12650000,
    totalTransactions: 980,
  },
  {
    code: 'checkout',
    name: 'Checkout.com Sandbox',
    region: 'UK / MENA',
    baseFeeBps: 260,
    fixedFeeCents: 20,
    avgLatencyMs: 184,
    successRate: 0.981,
    circuitState: 'CLOSED',
    failureCount: 0,
    failureThreshold: 3,
    isActive: true,
    simulatedFailureRate: 0.04,
    simulatedLatencyMs: 185,
    totalVolumeCents: 7420000,
    totalTransactions: 615,
  },
  {
    code: 'razorpay',
    name: 'Razorpay Sandbox',
    region: 'APAC / IN-SG',
    baseFeeBps: 200,
    fixedFeeCents: 0,
    avgLatencyMs: 215,
    successRate: 0.972,
    circuitState: 'CLOSED',
    failureCount: 0,
    failureThreshold: 3,
    isActive: true,
    simulatedFailureRate: 0.05,
    simulatedLatencyMs: 210,
    totalVolumeCents: 5190000,
    totalTransactions: 840,
  },
  {
    code: 'braintree',
    name: 'Braintree Sandbox',
    region: 'US-WEST',
    baseFeeBps: 275,
    fixedFeeCents: 25,
    avgLatencyMs: 196,
    successRate: 0.978,
    circuitState: 'CLOSED',
    failureCount: 0,
    failureThreshold: 3,
    isActive: true,
    simulatedFailureRate: 0.04,
    simulatedLatencyMs: 195,
    totalVolumeCents: 4310000,
    totalTransactions: 410,
  },
];

export async function ensureGatewaysSeeded() {
  try {
    await db
      .insert(gateways)
      .values(SANDBOX_GATEWAYS)
      .onConflictDoNothing({ target: gateways.code });

    return await db.select().from(gateways);
  } catch (error) {
    console.error('Failed to ensure sandbox gateways seeded:', error);
    throw new Error('Failed to initialize payment gateway registry.', { cause: error });
  }
}

export async function ensureUserWorkspaceSeeded(userId: number, email: string) {
  try {
    const existingCount = await db
      .select({ value: count() })
      .from(transactions)
      .where(eq(transactions.userId, userId));

    if ((existingCount[0]?.value ?? 0) > 0) {
      return;
    }

    const allGateways = await ensureGatewaysSeeded();
    const gwMap = new Map(allGateways.map((g) => [g.code, g]));

    const now = Date.now();
    const sampleTxs = [
      {
        txCode: `pmx_${crypto.randomBytes(4).toString('hex')}`,
        idempotencyKey: `idem_seed_${userId}_1001`,
        orderRef: 'ORD-88412',
        amountCents: 42900,
        currency: 'USD',
        paymentMethod: 'card',
        customerEmail: 'billing@acme-cloud.io',
        customerCountry: 'US',
        gatewayCode: 'stripe',
        status: 'RECONCILED',
        attemptCount: 1,
        latencyMs: 138,
        riskScore: 8,
        riskReason: 'Nominal velocity and verified domain',
        routingScore: 91.4,
        routingReason: 'Optimal composite score (99.2% SR, 142ms, 290bps)',
        minutesAgo: 45,
      },
      {
        txCode: `pmx_${crypto.randomBytes(4).toString('hex')}`,
        idempotencyKey: `idem_seed_${userId}_1002`,
        orderRef: 'ORD-88413',
        amountCents: 128500,
        currency: 'EUR',
        paymentMethod: 'sepa_debit',
        customerEmail: 'treasury@nordic-freight.eu',
        customerCountry: 'DE',
        gatewayCode: 'adyen',
        status: 'RECONCILED',
        attemptCount: 1,
        latencyMs: 162,
        riskScore: 14,
        riskReason: 'Nominal EU cross-border settlement',
        routingScore: 90.8,
        routingReason: 'Lower EU bps cost (245bps) with 98.8% SR',
        minutesAgo: 34,
      },
      {
        txCode: `pmx_${crypto.randomBytes(4).toString('hex')}`,
        idempotencyKey: `idem_seed_${userId}_1003`,
        orderRef: 'ORD-88414',
        amountCents: 89900,
        currency: 'GBP',
        paymentMethod: 'card',
        customerEmail: 'ops@kensington-retail.co.uk',
        customerCountry: 'GB',
        gatewayCode: 'checkout',
        status: 'SUCCEEDED',
        attemptCount: 2,
        latencyMs: 392,
        riskScore: 19,
        riskReason: 'Automatic failover succeeded on attempt 2',
        routingScore: 87.2,
        routingReason: 'Failover from primary timeout to Checkout.com Sandbox',
        minutesAgo: 21,
        retriedFrom: 'stripe',
      },
      {
        txCode: `pmx_${crypto.randomBytes(4).toString('hex')}`,
        idempotencyKey: `idem_seed_${userId}_1004`,
        orderRef: 'ORD-88415',
        amountCents: 24500,
        currency: 'SGD',
        paymentMethod: 'wallet',
        customerEmail: 'finance@merlion-tech.sg',
        customerCountry: 'SG',
        gatewayCode: 'razorpay',
        status: 'SUCCEEDED',
        attemptCount: 1,
        latencyMs: 204,
        riskScore: 11,
        riskReason: 'Low-fee APAC rail matched',
        routingScore: 86.1,
        routingReason: 'Zero fixed fee (200bps) favored for APAC wallet',
        minutesAgo: 12,
      },
      {
        txCode: `pmx_${crypto.randomBytes(4).toString('hex')}`,
        idempotencyKey: `idem_seed_${userId}_1005`,
        orderRef: 'ORD-88416',
        amountCents: 985000,
        currency: 'USD',
        paymentMethod: 'card',
        customerEmail: 'temp8812@disposable-mail.xyz',
        customerCountry: 'NG',
        gatewayCode: 'stripe',
        status: 'FLAGGED_FRAUD',
        attemptCount: 0,
        latencyMs: 14,
        riskScore: 88,
        riskReason: 'High-ticket anomaly ($9,850) + disposable domain + geo mismatch',
        routingScore: 0,
        routingReason: 'Blocked prior to gateway dispatch by fraud engine',
        minutesAgo: 6,
      },
    ];

    const insertedTxs = [];
    for (const s of sampleTxs) {
      const gw = gwMap.get(s.gatewayCode);
      const feeCents =
        s.status === 'FLAGGED_FRAUD' || !gw
          ? 0
          : Math.round(s.amountCents * (gw.baseFeeBps / 10000)) + gw.fixedFeeCents;
      const createdAt = new Date(now - s.minutesAgo * 60_000);
      const payloadHash = crypto
        .createHash('sha256')
        .update(`${s.orderRef}:${s.amountCents}:${s.currency}`)
        .digest('hex');

      const [tx] = await db
        .insert(transactions)
        .values({
          txCode: s.txCode,
          userId,
          idempotencyKey: s.idempotencyKey,
          payloadHash,
          orderRef: s.orderRef,
          amountCents: s.amountCents,
          currency: s.currency,
          paymentMethod: s.paymentMethod,
          customerEmail: s.customerEmail,
          customerCountry: s.customerCountry,
          selectedGatewayId: gw?.id ?? null,
          selectedGatewayCode: s.status === 'FLAGGED_FRAUD' ? null : s.gatewayCode,
          status: s.status,
          attemptCount: s.attemptCount,
          latencyMs: s.latencyMs,
          feeCents,
          riskScore: s.riskScore,
          riskReason: s.riskReason,
          routingScore: s.routingScore,
          routingReason: s.routingReason,
          reconciledAt: s.status === 'RECONCILED' ? createdAt : null,
          createdAt,
          updatedAt: createdAt,
        })
        .onConflictDoNothing()
        .returning();

      if (!tx) continue;
      insertedTxs.push(tx);

      if (s.retriedFrom) {
        await db.insert(transactionAttempts).values([
          {
            transactionId: tx.id,
            gatewayCode: s.retriedFrom,
            attemptNumber: 1,
            status: 'FAILED',
            latencyMs: 210,
            errorCode: 'GATEWAY_TIMEOUT',
            errorMessage: 'Upstream sandbox timeout after 210ms',
            circuitStateAtAttempt: 'CLOSED',
            createdAt,
          },
          {
            transactionId: tx.id,
            gatewayCode: s.gatewayCode,
            attemptNumber: 2,
            status: 'SUCCEEDED',
            latencyMs: 182,
            circuitStateAtAttempt: 'CLOSED',
            createdAt,
          },
        ]);
      } else if (s.attemptCount > 0) {
        await db.insert(transactionAttempts).values({
          transactionId: tx.id,
          gatewayCode: s.gatewayCode,
          attemptNumber: 1,
          status: 'SUCCEEDED',
          latencyMs: s.latencyMs,
          circuitStateAtAttempt: 'CLOSED',
          createdAt,
        });
      }

      const eventPayload = {
        txCode: tx.txCode,
        orderRef: tx.orderRef,
        amountCents: tx.amountCents,
        currency: tx.currency,
        status: tx.status,
        gateway: s.gatewayCode,
      };
      const hmacSignature = crypto
        .createHmac('sha256', 'paymatrix_sandbox_webhook_secret')
        .update(JSON.stringify(eventPayload))
        .digest('hex');

      await db.insert(webhookEvents).values({
        eventCode: `evt_${crypto.randomBytes(5).toString('hex')}`,
        userId,
        transactionId: tx.id,
        gatewayCode: s.gatewayCode,
        eventType:
          s.status === 'FLAGGED_FRAUD'
            ? 'fraud.blocked'
            : s.retriedFrom
              ? 'payment.retried'
              : 'payment.succeeded',
        deliveryStatus: s.retriedFrom ? 'RETRYING' : 'DELIVERED',
        signatureValid: true,
        hmacSignature,
        attemptCount: s.retriedFrom ? 2 : 1,
        payload: eventPayload,
        createdAt,
      });
    }

    if (insertedTxs.length >= 2) {
      const [batch] = await db
        .insert(reconciliationBatches)
        .values({
          batchCode: `rec_${crypto.randomBytes(4).toString('hex')}`,
          userId,
          gatewayCode: 'adyen',
          totalChecked: 2,
          matchedCount: 1,
          discrepancyCount: 1,
          totalVolumeCents: 171400,
          status: 'DISCREPANCY_FOUND',
          summary: '1 settled transaction matched; 1 minor fee variance detected in Adyen EUR batch.',
        })
        .returning();

      if (batch) {
        await db.insert(reconciliationDiscrepancies).values({
          batchId: batch.id,
          transactionId: insertedTxs[1].id,
          expectedCents: insertedTxs[1].amountCents,
          settledCents: insertedTxs[1].amountCents - 140,
          discrepancyType: 'FEE_VARIANCE',
          resolved: false,
        });
      }
    }

    const existingRuleCount = await db
      .select({ value: count() })
      .from(routingRules)
      .where(eq(routingRules.userId, userId));

    if ((existingRuleCount[0]?.value ?? 0) === 0) {
      await db.insert(routingRules).values([
        {
          userId,
          name: 'EUR SEPA Direct -> Adyen',
          priority: 10,
          isActive: true,
          conditionCurrency: 'EUR',
          conditionMethod: 'sepa_debit',
          conditionMinAmountCents: 0,
          conditionCountry: 'ALL',
          actionType: 'FORCE_GATEWAY',
          targetGatewayCode: 'adyen',
          canaryGatewayCode: null,
          canaryPct: 0,
          hitCount: 1,
        },
        {
          userId,
          name: 'APAC SGD Wallet 20% Canary -> Razorpay',
          priority: 20,
          isActive: true,
          conditionCurrency: 'SGD',
          conditionMethod: 'wallet',
          conditionMinAmountCents: 0,
          conditionCountry: 'ALL',
          actionType: 'CANARY_SPLIT',
          targetGatewayCode: 'stripe',
          canaryGatewayCode: 'razorpay',
          canaryPct: 20,
          hitCount: 1,
        },
      ]);
    }

    await db.insert(auditLogs).values({
      userId,
      entityType: 'workspace',
      entityId: String(userId),
      action: 'SANDBOX_WORKSPACE_INITIALIZED',
      actorEmail: email,
      metadata: {
        seededTransactions: insertedTxs.length,
        gatewaysActive: allGateways.length,
      },
    });
  } catch (error) {
    console.error('Failed to seed initial workspace:', error);
    throw new Error('Failed to initialize workspace records.', { cause: error });
  }
}
