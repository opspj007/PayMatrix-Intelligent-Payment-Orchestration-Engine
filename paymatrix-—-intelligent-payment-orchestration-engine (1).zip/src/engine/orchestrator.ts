import crypto from 'node:crypto';
import { and, asc, desc, eq, gte, sql } from 'drizzle-orm';
import { db } from '../db/index.ts';
import {
  auditLogs,
  gateways,
  refunds,
  routingPolicies,
  routingRules,
  transactionAttempts,
  transactions,
  webhookEvents,
} from '../db/schema.ts';
import { eventBus } from './queue.ts';
import { ensureGatewaysSeeded } from './seed.ts';

export interface DispatchPaymentInput {
  userId: number;
  actorEmail: string;
  idempotencyKey: string;
  orderRef: string;
  amountCents: number;
  currency: string;
  paymentMethod: string;
  customerEmail: string;
  customerCountry: string;
  preferredGatewayCode?: string;
  forceFailGatewayCode?: string;
}

export interface OrchestrationResult {
  transaction: typeof transactions.$inferSelect;
  attempts: Array<typeof transactionAttempts.$inferSelect>;
  idempotentReplay: boolean;
  cacheLayer: 'NONE' | 'IN_MEMORY_REDIS_CACHE' | 'IN_FLIGHT_COALESCED' | 'POSTGRES_UNIQUE_GUARD';
}

interface CacheEntry {
  payloadHash: string;
  result: OrchestrationResult;
  expiresAt: number;
}

const idempotencyCache = new Map<string, CacheEntry>();
const inFlightMutex = new Map<string, Promise<OrchestrationResult>>();

function computePayloadHash(input: DispatchPaymentInput): string {
  const canonical = JSON.stringify({
    orderRef: input.orderRef,
    amountCents: input.amountCents,
    currency: input.currency.toUpperCase(),
    paymentMethod: input.paymentMethod,
    customerEmail: input.customerEmail.toLowerCase(),
  });
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function evaluateFraudRisk(
  userId: number,
  input: DispatchPaymentInput
): Promise<{ riskScore: number; riskReason: string }> {
  let score = 5;
  const reasons: string[] = [];

  if (input.amountCents >= 500_000) {
    score += 38;
    reasons.push('High-value transaction (>= $5,000)');
  } else if (input.amountCents >= 200_000) {
    score += 18;
    reasons.push('Elevated ticket size (>= $2,000)');
  }

  const emailLower = input.customerEmail.toLowerCase();
  if (
    emailLower.endsWith('.xyz') ||
    emailLower.includes('disposable') ||
    emailLower.includes('temp') ||
    emailLower.includes('fraud')
  ) {
    score += 34;
    reasons.push('High-risk or disposable email domain');
  }

  if (
    (input.currency === 'USD' && ['NG', 'RU', 'KP'].includes(input.customerCountry.toUpperCase())) ||
    (input.currency === 'EUR' && !['DE', 'FR', 'NL', 'ES', 'IT', 'GB', 'US'].includes(input.customerCountry.toUpperCase()))
  ) {
    score += 22;
    reasons.push('Geo-currency mismatch signal');
  }

  // Velocity check: transactions in last 60 seconds for same customer email
  const sixtySecAgo = new Date(Date.now() - 60_000);
  const recentVelocity = await db
    .select({ id: transactions.id })
    .from(transactions)
    .where(
      and(
        eq(transactions.userId, userId),
        eq(transactions.customerEmail, input.customerEmail),
        gte(transactions.createdAt, sixtySecAgo)
      )
    );

  if (recentVelocity.length >= 3) {
    score += 30;
    reasons.push(`Velocity burst (${recentVelocity.length} attempts in 60s)`);
  }

  const clamped = Math.min(100, score);
  return {
    riskScore: clamped,
    riskReason: reasons.length > 0 ? reasons.join(' + ') : 'Nominal transaction profile',
  };
}

function scoreGateway(
  gw: typeof gateways.$inferSelect,
  policy: typeof routingPolicies.$inferSelect,
  preferredCode?: string
) {
  const wSum = policy.successWeight + policy.latencyWeight + policy.costWeight || 1;
  const wSuccess = policy.successWeight / wSum;
  const wLatency = policy.latencyWeight / wSum;
  const wCost = policy.costWeight / wSum;

  const successScore = gw.successRate * 100;
  const latencyScore = Math.max(0, 100 - gw.avgLatencyMs / 6);
  const costScore = Math.max(0, 100 - (gw.baseFeeBps / 6 + gw.fixedFeeCents / 4));

  let composite = wSuccess * successScore + wLatency * latencyScore + wCost * costScore;
  if (preferredCode && gw.code === preferredCode) {
    composite += 250; // Honor explicit preferred route test
  }

  return Number(composite.toFixed(2));
}

function enqueueWebhookAsync(
  userId: number,
  transactionId: number | null,
  gatewayCode: string,
  eventType: string,
  payload: Record<string, unknown>,
  simulateRetry = false
) {
  eventBus.incrementQueue();
  const hmacSignature = crypto
    .createHmac('sha256', 'paymatrix_sandbox_webhook_secret')
    .update(JSON.stringify(payload))
    .digest('hex');
  const eventCode = `evt_${crypto.randomBytes(5).toString('hex')}`;

  setTimeout(async () => {
    try {
      const [inserted] = await db
        .insert(webhookEvents)
        .values({
          eventCode,
          userId,
          transactionId,
          gatewayCode,
          eventType,
          deliveryStatus: simulateRetry ? 'RETRYING' : 'DELIVERED',
          signatureValid: true,
          hmacSignature,
          attemptCount: simulateRetry ? 2 : 1,
          payload,
        })
        .returning();

      eventBus.decrementQueue();
      if (inserted) {
        eventBus.publish({
          type: 'webhook:delivered',
          userId,
          payload: { webhook: inserted },
        });
      }
    } catch (err) {
      eventBus.decrementQueue();
      console.error('Async webhook queue error:', err);
    }
  }, 180);
}

export class IdempotencyConflictError extends Error {
  statusCode = 409;
  constructor(message: string) {
    super(message);
    this.name = 'IdempotencyConflictError';
  }
}

export async function dispatchPayment(
  input: DispatchPaymentInput
): Promise<OrchestrationResult> {
  const cacheKey = `${input.userId}:${input.idempotencyKey}`;
  const payloadHash = computePayloadHash(input);

  // 1. Fast Redis-style TTL memory cache check
  const cached = idempotencyCache.get(cacheKey);
  if (cached && cached.expiresAt > Date.now()) {
    if (cached.payloadHash !== payloadHash) {
      throw new IdempotencyConflictError(
        `Idempotency key "${input.idempotencyKey}" already used with a different payment payload.`
      );
    }
    return {
      ...cached.result,
      idempotentReplay: true,
      cacheLayer: 'IN_MEMORY_REDIS_CACHE',
    };
  }

  // 2. Concurrency control: coalesce concurrent identical requests
  const existingInFlight = inFlightMutex.get(cacheKey);
  if (existingInFlight) {
    const coalescedResult = await existingInFlight;
    if (coalescedResult.transaction.payloadHash !== payloadHash) {
      throw new IdempotencyConflictError(
        `Concurrent idempotency conflict for key "${input.idempotencyKey}".`
      );
    }
    return {
      ...coalescedResult,
      idempotentReplay: true,
      cacheLayer: 'IN_FLIGHT_COALESCED',
    };
  }

  const executionPromise = (async (): Promise<OrchestrationResult> => {
    // 3. Persistent PostgreSQL idempotency guard
    const existingDbRows = await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.userId, input.userId),
          eq(transactions.idempotencyKey, input.idempotencyKey)
        )
      )
      .limit(1);

    if (existingDbRows.length > 0) {
      const existingTx = existingDbRows[0];
      if (existingTx.payloadHash !== payloadHash) {
        throw new IdempotencyConflictError(
          `Idempotency key "${input.idempotencyKey}" conflicts with persisted payload hash.`
        );
      }
      const existingAttempts = await db
        .select()
        .from(transactionAttempts)
        .where(eq(transactionAttempts.transactionId, existingTx.id));

      return {
        transaction: existingTx,
        attempts: existingAttempts,
        idempotentReplay: true,
        cacheLayer: 'POSTGRES_UNIQUE_GUARD',
      };
    }

    await ensureGatewaysSeeded();

    // Load user routing policy
    const policyRows = await db
      .select()
      .from(routingPolicies)
      .where(eq(routingPolicies.userId, input.userId))
      .limit(1);

    const policy = policyRows[0] ?? {
      id: 0,
      userId: input.userId,
      successWeight: 0.5,
      latencyWeight: 0.25,
      costWeight: 0.25,
      autoRetryEnabled: true,
      maxRetries: 2,
      fraudThreshold: 75,
      idempotencyTtlSec: 86400,
      latencyAlertThresholdMs: 250,
      rateLimitRps: 15,
      rateLimitBurst: 25,
      updatedAt: new Date(),
    };

    const txCode = `pmx_${crypto.randomBytes(5).toString('hex')}`;

    // 4. Fraud & Suspicious Transaction Detection
    const { riskScore, riskReason } = await evaluateFraudRisk(input.userId, input);
    if (riskScore >= policy.fraudThreshold) {
      const result = await db.transaction(async (txDb) => {
        const [createdTx] = await txDb
          .insert(transactions)
          .values({
            txCode,
            userId: input.userId,
            idempotencyKey: input.idempotencyKey,
            payloadHash,
            orderRef: input.orderRef,
            amountCents: input.amountCents,
            currency: input.currency.toUpperCase(),
            paymentMethod: input.paymentMethod,
            customerEmail: input.customerEmail,
            customerCountry: input.customerCountry.toUpperCase(),
            status: 'FLAGGED_FRAUD',
            attemptCount: 0,
            latencyMs: 12,
            feeCents: 0,
            riskScore,
            riskReason,
            routingScore: 0,
            routingReason: 'Blocked pre-dispatch by PayMatrix fraud risk threshold.',
          })
          .returning();

        await txDb.insert(auditLogs).values({
          userId: input.userId,
          entityType: 'transaction',
          entityId: createdTx.txCode,
          action: 'FRAUD_TRANSACTION_BLOCKED',
          actorEmail: input.actorEmail,
          metadata: { riskScore, riskReason, amountCents: input.amountCents },
        });

        return {
          transaction: createdTx,
          attempts: [],
          idempotentReplay: false,
          cacheLayer: 'NONE' as const,
        };
      });

      eventBus.publish({
        type: 'fraud:flagged',
        userId: input.userId,
        payload: { transaction: result.transaction },
      });

      enqueueWebhookAsync(input.userId, result.transaction.id, 'risk-engine', 'fraud.blocked', {
        txCode: result.transaction.txCode,
        riskScore,
        riskReason,
      });

      idempotencyCache.set(cacheKey, {
        payloadHash,
        result,
        expiresAt: Date.now() + policy.idempotencyTtlSec * 1000,
      });
      return result;
    }

    // 4.5. Deterministic Conditional Routing Rules & Canary Splitting
    const activeRules = await db
      .select()
      .from(routingRules)
      .where(and(eq(routingRules.userId, input.userId), eq(routingRules.isActive, true)))
      .orderBy(asc(routingRules.priority));

    const upperCurrency = input.currency.toUpperCase();
    const upperCountry = input.customerCountry.toUpperCase();
    const lowerMethod = input.paymentMethod.toLowerCase();

    const matchedRule = activeRules.find((r) => {
      const currencyMatch =
        r.conditionCurrency === 'ALL' || r.conditionCurrency.toUpperCase() === upperCurrency;
      const methodMatch =
        r.conditionMethod === 'ALL' || r.conditionMethod.toLowerCase() === lowerMethod;
      const countryMatch =
        r.conditionCountry === 'ALL' || r.conditionCountry.toUpperCase() === upperCountry;
      const amountMatch = input.amountCents >= (r.conditionMinAmountCents ?? 0);
      return currencyMatch && methodMatch && countryMatch && amountMatch;
    });

    let effectivePreferredGateway = input.preferredGatewayCode;
    let appliedRuleTag = '';

    if (matchedRule) {
      await db
        .update(routingRules)
        .set({ hitCount: sql`${routingRules.hitCount} + 1`, updatedAt: new Date() })
        .where(eq(routingRules.id, matchedRule.id));

      if (matchedRule.actionType === 'BLOCK_COUNTRY') {
        const blockedResult = await db.transaction(async (txDb) => {
          const [createdTx] = await txDb
            .insert(transactions)
            .values({
              txCode,
              userId: input.userId,
              idempotencyKey: input.idempotencyKey,
              payloadHash,
              orderRef: input.orderRef,
              amountCents: input.amountCents,
              currency: upperCurrency,
              paymentMethod: input.paymentMethod,
              customerEmail: input.customerEmail,
              customerCountry: upperCountry,
              status: 'FAILED',
              attemptCount: 0,
              latencyMs: 8,
              feeCents: 0,
              riskScore,
              riskReason,
              routingScore: 0,
              routingReason: `Blocked by conditional rule "${matchedRule.name}" (${matchedRule.conditionCountry}).`,
            })
            .returning();

          await txDb.insert(auditLogs).values({
            userId: input.userId,
            entityType: 'transaction',
            entityId: createdTx.txCode,
            action: 'ROUTING_RULE_BLOCKED',
            actorEmail: input.actorEmail,
            metadata: {
              ruleId: matchedRule.id,
              ruleName: matchedRule.name,
              country: upperCountry,
              currency: upperCurrency,
            },
          });

          return {
            transaction: createdTx,
            attempts: [],
            idempotentReplay: false,
            cacheLayer: 'NONE' as const,
          };
        });

        eventBus.publish({
          type: 'tx:created',
          userId: input.userId,
          payload: { transaction: blockedResult.transaction, attempts: [] },
        });

        idempotencyCache.set(cacheKey, {
          payloadHash,
          result: blockedResult,
          expiresAt: Date.now() + policy.idempotencyTtlSec * 1000,
        });
        return blockedResult;
      }

      if (!input.preferredGatewayCode) {
        if (
          matchedRule.actionType === 'CANARY_SPLIT' &&
          matchedRule.canaryGatewayCode &&
          matchedRule.canaryPct > 0
        ) {
          const roll = Math.random() * 100;
          const pickedCanary = roll < matchedRule.canaryPct;
          effectivePreferredGateway = pickedCanary
            ? matchedRule.canaryGatewayCode
            : matchedRule.targetGatewayCode;
          appliedRuleTag = ` [Rule: ${matchedRule.name} -> ${
            pickedCanary ? `Canary ${matchedRule.canaryPct}%` : 'Primary'
          }]`;
        } else {
          effectivePreferredGateway = matchedRule.targetGatewayCode;
          appliedRuleTag = ` [Rule: ${matchedRule.name}]`;
        }
      } else {
        appliedRuleTag = ` [Rule "${matchedRule.name}" overridden by Sandbox preference]`;
      }
    }

    // 5. Intelligent Gateway Ranking & Circuit Breaker Evaluation
    const allGateways = await db.select().from(gateways).orderBy(desc(gateways.successRate));
    const now = new Date();
    const eligible: Array<{ gw: typeof gateways.$inferSelect; score: number }> = [];

    for (const gw of allGateways) {
      if (!gw.isActive) continue;
      let effectiveState = gw.circuitState;
      if (gw.circuitState === 'OPEN' && gw.cooldownUntil && gw.cooldownUntil <= now) {
        effectiveState = 'HALF_OPEN';
        await db
          .update(gateways)
          .set({ circuitState: 'HALF_OPEN', updatedAt: now })
          .where(eq(gateways.id, gw.id));
        eventBus.publish({
          type: 'circuit:changed',
          payload: { gatewayCode: gw.code, circuitState: 'HALF_OPEN' },
        });
      }
      if (effectiveState === 'OPEN') continue;
      eligible.push({
        gw: { ...gw, circuitState: effectiveState },
        score: scoreGateway(gw, policy, effectivePreferredGateway),
      });
    }

    eligible.sort((a, b) => b.score - a.score);

    const maxAttempts = policy.autoRetryEnabled ? Math.min(eligible.length, policy.maxRetries + 1) : Math.min(eligible.length, 1);

    const attemptLogs: Array<{
      gatewayCode: string;
      attemptNumber: number;
      status: string;
      latencyMs: number;
      errorCode?: string;
      errorMessage?: string;
      circuitStateAtAttempt: string;
    }> = [];

    let winningGateway: typeof gateways.$inferSelect | null = null;
    let winningScore = 0;
    let totalLatency = 0;

    for (let idx = 0; idx < maxAttempts; idx++) {
      const candidate = eligible[idx];
      const gw = candidate.gw;
      const attemptNumber = idx + 1;

      const jitter = Math.floor(Math.random() * 45);
      const stepLatency = Math.max(40, Math.min(450, gw.simulatedLatencyMs + jitter));
      await sleep(Math.min(180, Math.round(stepLatency * 0.45)));
      totalLatency += stepLatency;

      const shouldFail =
        (input.forceFailGatewayCode && input.forceFailGatewayCode === gw.code) ||
        Math.random() < gw.simulatedFailureRate;

      if (shouldFail) {
        const nextFailureCount = gw.failureCount + 1;
        const nextSuccessRate = Math.max(0.5, Number((gw.successRate * 0.992).toFixed(4)));
        const nextErrorRatePct = Number(((1 - nextSuccessRate) * 100).toFixed(2));
        const errorRateExceeded =
          gw.errorRateThresholdEnabled && nextErrorRatePct >= gw.errorRateThresholdPct;
        const trippedOpen =
          nextFailureCount >= gw.failureThreshold ||
          gw.circuitState === 'HALF_OPEN' ||
          errorRateExceeded;
        const nextCircuitState = trippedOpen ? 'OPEN' : gw.circuitState;
        const cooldownUntil = trippedOpen ? new Date(Date.now() + 30_000) : gw.cooldownUntil;

        await db
          .update(gateways)
          .set({
            failureCount: nextFailureCount,
            circuitState: nextCircuitState,
            cooldownUntil,
            successRate: nextSuccessRate,
            updatedAt: new Date(),
          })
          .where(eq(gateways.id, gw.id));

        if (trippedOpen && gw.circuitState !== 'OPEN') {
          await db.insert(auditLogs).values({
            userId: input.userId,
            entityType: 'gateway',
            entityId: gw.code,
            action: 'CIRCUIT_BREAKER_TRIPPED_OPEN',
            actorEmail: input.actorEmail,
            metadata: {
              failureCount: nextFailureCount,
              threshold: gw.failureThreshold,
              errorRatePct: nextErrorRatePct,
              errorRateThresholdEnabled: gw.errorRateThresholdEnabled,
              errorRateThresholdPct: gw.errorRateThresholdPct,
              tripReason: errorRateExceeded
                ? 'ERROR_RATE_THRESHOLD_EXCEEDED'
                : 'CONSECUTIVE_FAILURES',
              cooldownSeconds: 30,
            },
          });

          eventBus.publish({
            type: 'circuit:changed',
            payload: { gatewayCode: gw.code, circuitState: 'OPEN', failureCount: nextFailureCount },
          });

          enqueueWebhookAsync(input.userId, null, gw.code, 'circuit.opened', {
            gatewayCode: gw.code,
            failureCount: nextFailureCount,
            errorRatePct: nextErrorRatePct,
            tripReason: errorRateExceeded
              ? 'ERROR_RATE_THRESHOLD_EXCEEDED'
              : 'CONSECUTIVE_FAILURES',
          });
        }

        attemptLogs.push({
          gatewayCode: gw.code,
          attemptNumber,
          status: 'FAILED',
          latencyMs: stepLatency,
          errorCode: input.forceFailGatewayCode === gw.code ? 'FORCED_SANDBOX_FAULT' : 'UPSTREAM_502_TIMEOUT',
          errorMessage: `${gw.name} returned transient 502/timeout on attempt ${attemptNumber}.`,
          circuitStateAtAttempt: gw.circuitState,
        });
      } else {
        // Success!
        const updatedAvgLatency = Math.round(gw.avgLatencyMs * 0.8 + stepLatency * 0.2);
        const feeCents = Math.round(input.amountCents * (gw.baseFeeBps / 10000)) + gw.fixedFeeCents;
        await db
          .update(gateways)
          .set({
            failureCount: 0,
            circuitState: 'CLOSED',
            cooldownUntil: null,
            avgLatencyMs: updatedAvgLatency,
            successRate: Math.min(0.999, Number((gw.successRate * 0.99 + 0.01).toFixed(4))),
            totalVolumeCents: sql`${gateways.totalVolumeCents} + ${input.amountCents}`,
            totalTransactions: sql`${gateways.totalTransactions} + 1`,
            updatedAt: new Date(),
          })
          .where(eq(gateways.id, gw.id));

        if (gw.circuitState !== 'CLOSED') {
          eventBus.publish({
            type: 'circuit:changed',
            payload: { gatewayCode: gw.code, circuitState: 'CLOSED', failureCount: 0 },
          });
        }

        attemptLogs.push({
          gatewayCode: gw.code,
          attemptNumber,
          status: 'SUCCEEDED',
          latencyMs: stepLatency,
          circuitStateAtAttempt: gw.circuitState,
        });

        winningGateway = gw;
        winningScore = candidate.score;
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        void feeCents;
        break;
      }
    }

    const finalStatus = winningGateway ? 'SUCCEEDED' : 'FAILED';
    const feeCents = winningGateway
      ? Math.round(input.amountCents * (winningGateway.baseFeeBps / 10000)) +
        winningGateway.fixedFeeCents
      : 0;

    const baseRoutingReason = winningGateway
      ? attemptLogs.length > 1
        ? `Automatic failover to ${winningGateway.name} after ${attemptLogs.length - 1} failed attempt(s) (score ${winningScore}).`
        : `Routed to ${winningGateway.name} (score ${winningScore}: ${(winningGateway.successRate * 100).toFixed(1)}% SR, ${winningGateway.avgLatencyMs}ms, ${winningGateway.baseFeeBps}bps).`
      : eligible.length === 0
        ? 'No healthy gateways available (all circuits OPEN or disabled).'
        : `Exhausted ${attemptLogs.length} gateway attempt(s) across available providers.`;
    const routingReason = `${baseRoutingReason}${appliedRuleTag}`;

    const persisted = await db.transaction(async (txDb) => {
      const [createdTx] = await txDb
        .insert(transactions)
        .values({
          txCode,
          userId: input.userId,
          idempotencyKey: input.idempotencyKey,
          payloadHash,
          orderRef: input.orderRef,
          amountCents: input.amountCents,
          currency: input.currency.toUpperCase(),
          paymentMethod: input.paymentMethod,
          customerEmail: input.customerEmail,
          customerCountry: input.customerCountry.toUpperCase(),
          selectedGatewayId: winningGateway?.id ?? null,
          selectedGatewayCode: winningGateway?.code ?? null,
          status: finalStatus,
          attemptCount: attemptLogs.length,
          latencyMs: totalLatency,
          feeCents,
          riskScore,
          riskReason,
          routingScore: winningScore,
          routingReason,
        })
        .returning();

      const insertedAttempts =
        attemptLogs.length > 0
          ? await txDb
              .insert(transactionAttempts)
              .values(
                attemptLogs.map((a) => ({
                  transactionId: createdTx.id,
                  gatewayCode: a.gatewayCode,
                  attemptNumber: a.attemptNumber,
                  status: a.status,
                  latencyMs: a.latencyMs,
                  errorCode: a.errorCode ?? null,
                  errorMessage: a.errorMessage ?? null,
                  circuitStateAtAttempt: a.circuitStateAtAttempt,
                }))
              )
              .returning()
          : [];

      await txDb.insert(auditLogs).values({
        userId: input.userId,
        entityType: 'transaction',
        entityId: createdTx.txCode,
        action:
          finalStatus === 'SUCCEEDED'
            ? attemptLogs.length > 1
              ? 'PAYMENT_SUCCEEDED_WITH_FAILOVER'
              : 'PAYMENT_SUCCEEDED'
            : 'PAYMENT_FAILED_ALL_RETRIES',
        actorEmail: input.actorEmail,
        metadata: {
          gateway: winningGateway?.code ?? null,
          attempts: attemptLogs.length,
          latencyMs: totalLatency,
          feeCents,
          idempotencyKey: input.idempotencyKey,
        },
      });

      return {
        transaction: createdTx,
        attempts: insertedAttempts,
        idempotentReplay: false,
        cacheLayer: 'NONE' as const,
      };
    });

    eventBus.publish({
      type: 'tx:created',
      userId: input.userId,
      payload: {
        transaction: persisted.transaction,
        attempts: persisted.attempts,
      },
    });

    enqueueWebhookAsync(
      input.userId,
      persisted.transaction.id,
      winningGateway?.code ?? attemptLogs[0]?.gatewayCode ?? 'orchestrator',
      finalStatus === 'SUCCEEDED'
        ? attemptLogs.length > 1
          ? 'payment.retried'
          : 'payment.succeeded'
        : 'payment.failed',
      {
        txCode: persisted.transaction.txCode,
        orderRef: persisted.transaction.orderRef,
        amountCents: persisted.transaction.amountCents,
        currency: persisted.transaction.currency,
        status: finalStatus,
        attempts: attemptLogs.length,
      },
      finalStatus === 'FAILED'
    );

    idempotencyCache.set(cacheKey, {
      payloadHash,
      result: persisted,
      expiresAt: Date.now() + policy.idempotencyTtlSec * 1000,
    });

    return persisted;
  })();

  inFlightMutex.set(cacheKey, executionPromise);
  try {
    return await executionPromise;
  } finally {
    inFlightMutex.delete(cacheKey);
  }
}

export class RefundValidationError extends Error {
  statusCode: number;
  constructor(message: string, statusCode = 400) {
    super(message);
    this.name = 'RefundValidationError';
    this.statusCode = statusCode;
  }
}

export async function issueTransactionRefund(
  userId: number,
  actorEmail: string,
  transactionId: number,
  amountCents: number,
  reason: string
) {
  const cleanAmount = Math.round(amountCents);
  if (!Number.isFinite(cleanAmount) || cleanAmount <= 0) {
    throw new RefundValidationError('Refund amount must be greater than 0 cents.', 400);
  }
  const cleanReason = reason.trim() || 'Operator-initiated refund';

  const result = await db.transaction(async (txDb) => {
    const txRows = await txDb
      .select()
      .from(transactions)
      .where(and(eq(transactions.id, transactionId), eq(transactions.userId, userId)))
      .limit(1);

    if (txRows.length === 0) {
      throw new RefundValidationError('Transaction not found.', 404);
    }

    const tx = txRows[0];
    if (tx.status !== 'SUCCEEDED' && tx.status !== 'RECONCILED') {
      throw new RefundValidationError(
        `Only SUCCEEDED or RECONCILED transactions can be refunded (current status: ${tx.status}).`,
        400
      );
    }

    const remainingCents = tx.amountCents - tx.refundedCents;
    if (cleanAmount > remainingCents) {
      throw new RefundValidationError(
        `Refund exceeds remaining refundable balance (${remainingCents} cents remaining).`,
        400
      );
    }

    const nextRefundedCents = tx.refundedCents + cleanAmount;
    const isFullRefund = nextRefundedCents >= tx.amountCents;
    const nextStatus = isFullRefund ? 'REFUNDED' : tx.status;
    const refundCode = `ref_${crypto.randomBytes(5).toString('hex')}`;
    const gatewayCode = tx.selectedGatewayCode ?? 'orchestrator';

    const [createdRefund] = await txDb
      .insert(refunds)
      .values({
        refundCode,
        userId,
        transactionId: tx.id,
        gatewayCode,
        amountCents: cleanAmount,
        reason: cleanReason,
        status: 'SUCCEEDED',
      })
      .returning();

    const [updatedTx] = await txDb
      .update(transactions)
      .set({
        refundedCents: nextRefundedCents,
        status: nextStatus,
        updatedAt: new Date(),
      })
      .where(eq(transactions.id, tx.id))
      .returning();

    await txDb.insert(auditLogs).values({
      userId,
      entityType: 'refund',
      entityId: refundCode,
      action: 'PAYMENT_REFUND_ISSUED',
      actorEmail,
      metadata: {
        txCode: tx.txCode,
        gatewayCode,
        refundedCents: cleanAmount,
        totalRefundedCents: nextRefundedCents,
        isFullRefund,
        reason: cleanReason,
      },
    });

    return { refund: createdRefund, transaction: updatedTx };
  });

  enqueueWebhookAsync(
    userId,
    result.transaction.id,
    result.refund.gatewayCode,
    'charge.refunded',
    {
      refundCode: result.refund.refundCode,
      txCode: result.transaction.txCode,
      amountCents: result.refund.amountCents,
      totalRefundedCents: result.transaction.refundedCents,
      currency: result.transaction.currency,
      reason: result.refund.reason,
      status: result.transaction.status,
    }
  );

  eventBus.publish({
    type: 'tx:updated',
    userId,
    payload: { transaction: result.transaction, refund: result.refund },
  });

  return result;
}

