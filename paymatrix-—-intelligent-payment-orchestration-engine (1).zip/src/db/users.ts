import { db } from './index.ts';
import { routingPolicies, users } from './schema.ts';

export async function getOrCreateUser(uid: string, email: string, displayName?: string) {
  try {
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        displayName: displayName ?? email.split('@')[0],
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
          ...(displayName ? { displayName } : {}),
        },
      })
      .returning();

    const user = result[0];

    // Ensure default routing policy exists for this user
    await db
      .insert(routingPolicies)
      .values({
        userId: user.id,
        successWeight: 0.5,
        latencyWeight: 0.25,
        costWeight: 0.25,
        autoRetryEnabled: true,
        maxRetries: 2,
        fraudThreshold: 75,
        idempotencyTtlSec: 86400,
        latencyAlertThresholdMs: 250,
        rateLimitRps: 15,
        rateLimitBurst: 25,
      })
      .onConflictDoNothing({
        target: routingPolicies.userId,
      });

    return user;
  } catch (error) {
    console.error('Failed to upsert user:', error);
    throw new Error('Database user synchronization failed.', { cause: error });
  }
}
