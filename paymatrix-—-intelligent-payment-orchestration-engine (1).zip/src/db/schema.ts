import { relations } from 'drizzle-orm';
import {
  bigint,
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(),
  email: text('email').notNull(),
  displayName: text('display_name'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const gateways = pgTable('gateways', {
  id: serial('id').primaryKey(),
  code: text('code').notNull().unique(),
  name: text('name').notNull(),
  region: text('region').notNull(),
  baseFeeBps: integer('base_fee_bps').notNull(),
  fixedFeeCents: integer('fixed_fee_cents').notNull(),
  avgLatencyMs: integer('avg_latency_ms').notNull(),
  successRate: doublePrecision('success_rate').notNull(),
  circuitState: text('circuit_state').notNull().default('CLOSED'),
  failureCount: integer('failure_count').notNull().default(0),
  failureThreshold: integer('failure_threshold').notNull().default(3),
  cooldownUntil: timestamp('cooldown_until'),
  isActive: boolean('is_active').notNull().default(true),
  simulatedFailureRate: doublePrecision('simulated_failure_rate').notNull().default(0.03),
  simulatedLatencyMs: integer('simulated_latency_ms').notNull().default(180),
  totalVolumeCents: bigint('total_volume_cents', { mode: 'number' }).notNull().default(0),
  totalTransactions: integer('total_transactions').notNull().default(0),
  latencyAlertThresholdMs: integer('latency_alert_threshold_ms').notNull().default(250),
  errorRateThresholdEnabled: boolean('error_rate_threshold_enabled').notNull().default(false),
  errorRateThresholdPct: doublePrecision('error_rate_threshold_pct').notNull().default(10),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const routingPolicies = pgTable('routing_policies', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull()
    .unique(),
  successWeight: doublePrecision('success_weight').notNull().default(0.5),
  latencyWeight: doublePrecision('latency_weight').notNull().default(0.25),
  costWeight: doublePrecision('cost_weight').notNull().default(0.25),
  autoRetryEnabled: boolean('auto_retry_enabled').notNull().default(true),
  maxRetries: integer('max_retries').notNull().default(2),
  fraudThreshold: integer('fraud_threshold').notNull().default(75),
  idempotencyTtlSec: integer('idempotency_ttl_sec').notNull().default(86400),
  latencyAlertThresholdMs: integer('latency_alert_threshold_ms').notNull().default(250),
  rateLimitRps: integer('rate_limit_rps').notNull().default(15),
  rateLimitBurst: integer('rate_limit_burst').notNull().default(25),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const transactions = pgTable(
  'transactions',
  {
    id: serial('id').primaryKey(),
    txCode: text('tx_code').notNull().unique(),
    userId: integer('user_id')
      .references(() => users.id)
      .notNull(),
    idempotencyKey: text('idempotency_key').notNull(),
    payloadHash: text('payload_hash').notNull(),
    orderRef: text('order_ref').notNull(),
    amountCents: integer('amount_cents').notNull(),
    currency: text('currency').notNull().default('USD'),
    paymentMethod: text('payment_method').notNull().default('card'),
    customerEmail: text('customer_email').notNull(),
    customerCountry: text('customer_country').notNull().default('US'),
    selectedGatewayId: integer('selected_gateway_id').references(() => gateways.id),
    selectedGatewayCode: text('selected_gateway_code'),
    status: text('status').notNull(),
    attemptCount: integer('attempt_count').notNull().default(1),
    latencyMs: integer('latency_ms').notNull().default(0),
    feeCents: integer('fee_cents').notNull().default(0),
    refundedCents: integer('refunded_cents').notNull().default(0),
    riskScore: integer('risk_score').notNull().default(0),
    riskReason: text('risk_reason'),
    routingScore: doublePrecision('routing_score'),
    routingReason: text('routing_reason'),
    reconciledAt: timestamp('reconciled_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex('transactions_user_idempotency_idx').on(table.userId, table.idempotencyKey),
  ]
);

export const transactionAttempts = pgTable('transaction_attempts', {
  id: serial('id').primaryKey(),
  transactionId: integer('transaction_id')
    .references(() => transactions.id)
    .notNull(),
  gatewayCode: text('gateway_code').notNull(),
  attemptNumber: integer('attempt_number').notNull(),
  status: text('status').notNull(),
  latencyMs: integer('latency_ms').notNull(),
  errorCode: text('error_code'),
  errorMessage: text('error_message'),
  circuitStateAtAttempt: text('circuit_state_at_attempt').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const webhookEvents = pgTable('webhook_events', {
  id: serial('id').primaryKey(),
  eventCode: text('event_code').notNull().unique(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  transactionId: integer('transaction_id').references(() => transactions.id),
  gatewayCode: text('gateway_code').notNull(),
  eventType: text('event_type').notNull(),
  deliveryStatus: text('delivery_status').notNull().default('DELIVERED'),
  signatureValid: boolean('signature_valid').notNull().default(true),
  hmacSignature: text('hmac_signature').notNull(),
  attemptCount: integer('attempt_count').notNull().default(1),
  payload: jsonb('payload').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const reconciliationBatches = pgTable('reconciliation_batches', {
  id: serial('id').primaryKey(),
  batchCode: text('batch_code').notNull().unique(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  gatewayCode: text('gateway_code').notNull(),
  totalChecked: integer('total_checked').notNull(),
  matchedCount: integer('matched_count').notNull(),
  discrepancyCount: integer('discrepancy_count').notNull(),
  totalVolumeCents: bigint('total_volume_cents', { mode: 'number' }).notNull(),
  status: text('status').notNull(),
  summary: text('summary').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const reconciliationDiscrepancies = pgTable('reconciliation_discrepancies', {
  id: serial('id').primaryKey(),
  batchId: integer('batch_id')
    .references(() => reconciliationBatches.id)
    .notNull(),
  transactionId: integer('transaction_id')
    .references(() => transactions.id)
    .notNull(),
  expectedCents: integer('expected_cents').notNull(),
  settledCents: integer('settled_cents').notNull(),
  discrepancyType: text('discrepancy_type').notNull(),
  resolved: boolean('resolved').notNull().default(false),
  resolutionNote: text('resolution_note'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const routingRules = pgTable('routing_rules', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  name: text('name').notNull(),
  priority: integer('priority').notNull().default(10),
  isActive: boolean('is_active').notNull().default(true),
  conditionCurrency: text('condition_currency').notNull().default('ALL'),
  conditionMethod: text('condition_method').notNull().default('ALL'),
  conditionMinAmountCents: integer('condition_min_amount_cents').notNull().default(0),
  conditionCountry: text('condition_country').notNull().default('ALL'),
  actionType: text('action_type').notNull().default('FORCE_GATEWAY'),
  targetGatewayCode: text('target_gateway_code').notNull(),
  canaryGatewayCode: text('canary_gateway_code'),
  canaryPct: integer('canary_pct').notNull().default(0),
  hitCount: integer('hit_count').notNull().default(0),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const refunds = pgTable('refunds', {
  id: serial('id').primaryKey(),
  refundCode: text('refund_code').notNull().unique(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  transactionId: integer('transaction_id')
    .references(() => transactions.id)
    .notNull(),
  gatewayCode: text('gateway_code').notNull(),
  amountCents: integer('amount_cents').notNull(),
  reason: text('reason').notNull(),
  status: text('status').notNull().default('SUCCEEDED'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const auditLogs = pgTable('audit_logs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id)
    .notNull(),
  entityType: text('entity_type').notNull(),
  entityId: text('entity_id').notNull(),
  action: text('action').notNull(),
  actorEmail: text('actor_email').notNull(),
  metadata: jsonb('metadata').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const usersRelations = relations(users, ({ many, one }) => ({
  transactions: many(transactions),
  routingPolicy: one(routingPolicies),
  routingRules: many(routingRules),
  refunds: many(refunds),
  webhookEvents: many(webhookEvents),
  reconciliationBatches: many(reconciliationBatches),
  auditLogs: many(auditLogs),
}));

export const transactionsRelations = relations(transactions, ({ one, many }) => ({
  user: one(users, {
    fields: [transactions.userId],
    references: [users.id],
  }),
  gateway: one(gateways, {
    fields: [transactions.selectedGatewayId],
    references: [gateways.id],
  }),
  attempts: many(transactionAttempts),
  webhooks: many(webhookEvents),
  refunds: many(refunds),
}));

export const transactionAttemptsRelations = relations(transactionAttempts, ({ one }) => ({
  transaction: one(transactions, {
    fields: [transactionAttempts.transactionId],
    references: [transactions.id],
  }),
}));

export const reconciliationBatchesRelations = relations(reconciliationBatches, ({ many }) => ({
  discrepancies: many(reconciliationDiscrepancies),
}));

export const reconciliationDiscrepanciesRelations = relations(
  reconciliationDiscrepancies,
  ({ one }) => ({
    batch: one(reconciliationBatches, {
      fields: [reconciliationDiscrepancies.batchId],
      references: [reconciliationBatches.id],
    }),
    transaction: one(transactions, {
      fields: [reconciliationDiscrepancies.transactionId],
      references: [transactions.id],
    }),
  })
);
