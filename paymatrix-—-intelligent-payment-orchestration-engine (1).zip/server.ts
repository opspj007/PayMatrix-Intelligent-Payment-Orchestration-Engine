import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import dotenv from 'dotenv';
import express from 'express';
import { and, asc, desc, eq, gte, inArray } from 'drizzle-orm';
import { createServer as createViteServer } from 'vite';
import { WebSocketServer } from 'ws';
import { db } from './src/db/index.ts';
import {
  auditLogs,
  gateways,
  reconciliationBatches,
  reconciliationDiscrepancies,
  refunds,
  routingPolicies,
  routingRules,
  transactionAttempts,
  transactions,
  webhookEvents,
} from './src/db/schema.ts';
import { getOrCreateUser } from './src/db/users.ts';
import {
  runDeepIncidentDiagnosis,
  runFastFraudTriage,
  synthesizeRoutingRule,
} from './src/engine/gemini.ts';
import {
  dispatchPayment,
  IdempotencyConflictError,
  issueTransactionRefund,
  RefundValidationError,
} from './src/engine/orchestrator.ts';
import { eventBus } from './src/engine/queue.ts';
import { consumeRateLimitToken, getRateLimiterStatus } from './src/engine/rateLimiter.ts';
import { runAutomaticReconciliation } from './src/engine/reconciler.ts';
import { ensureGatewaysSeeded, ensureUserWorkspaceSeeded } from './src/engine/seed.ts';
import { adminAuth } from './src/lib/firebase-admin.ts';
import { requireAuth, type AuthRequest } from './src/middleware/auth.ts';

dotenv.config();

const PORT = 3000;

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });
  eventBus.attachWebSocketServer(wss);

  wss.on('connection', async (ws, req) => {
    try {
      const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
      const token = url.searchParams.get('token');
      if (!token) {
        ws.close(4001, 'Missing auth token');
        return;
      }
      const decoded = await adminAuth.verifyIdToken(token);
      if (!decoded.email) {
        ws.close(4003, 'Verified email required');
        return;
      }
      const dbUser = await getOrCreateUser(decoded.uid, decoded.email, decoded.name);
      eventBus.registerClient(ws, dbUser.id);
      ws.send(
        JSON.stringify({
          type: 'ws:connected',
          payload: { userId: dbUser.id, queueDepth: eventBus.getQueueDepth() },
          timestamp: new Date().toISOString(),
        })
      );
    } catch (error) {
      console.error('WebSocket auth failed:', error);
      ws.close(4001, 'Invalid token');
    }
  });

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'paymatrix-orchestrator' });
  });

  app.get('/api/dashboard', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      await ensureGatewaysSeeded();
      await ensureUserWorkspaceSeeded(user.id, user.email);

      const twentyFourHoursAgo = new Date(Date.now() - 24 * 3600_000);

      const [
        allGateways,
        userTransactions,
        txsLast24h,
        policyRows,
        userRules,
        userRefunds,
        userWebhooks,
        userBatches,
        userAuditLogs,
      ] = await Promise.all([
        db.select().from(gateways).orderBy(gateways.id),
        db
          .select()
          .from(transactions)
          .where(eq(transactions.userId, user.id))
          .orderBy(desc(transactions.createdAt))
          .limit(60),
        db
          .select({
            createdAt: transactions.createdAt,
            status: transactions.status,
            selectedGatewayCode: transactions.selectedGatewayCode,
          })
          .from(transactions)
          .where(
            and(
              eq(transactions.userId, user.id),
              gte(transactions.createdAt, twentyFourHoursAgo)
            )
          ),
        db.select().from(routingPolicies).where(eq(routingPolicies.userId, user.id)).limit(1),
        db
          .select()
          .from(routingRules)
          .where(eq(routingRules.userId, user.id))
          .orderBy(asc(routingRules.priority), asc(routingRules.id)),
        db
          .select()
          .from(refunds)
          .where(eq(refunds.userId, user.id))
          .orderBy(desc(refunds.createdAt))
          .limit(50),
        db
          .select()
          .from(webhookEvents)
          .where(eq(webhookEvents.userId, user.id))
          .orderBy(desc(webhookEvents.createdAt))
          .limit(40),
        db
          .select()
          .from(reconciliationBatches)
          .where(eq(reconciliationBatches.userId, user.id))
          .orderBy(desc(reconciliationBatches.createdAt))
          .limit(20),
        db
          .select()
          .from(auditLogs)
          .where(eq(auditLogs.userId, user.id))
          .orderBy(desc(auditLogs.createdAt))
          .limit(50),
      ]);

      const txIds = userTransactions.map((t) => t.id);
      const attempts =
        txIds.length > 0
          ? await db
              .select()
              .from(transactionAttempts)
              .where(inArray(transactionAttempts.transactionId, txIds))
          : [];

      const batchIds = userBatches.map((b) => b.id);
      const discrepancies =
        batchIds.length > 0
          ? await db
              .select()
              .from(reconciliationDiscrepancies)
              .where(inArray(reconciliationDiscrepancies.batchId, batchIds))
              .orderBy(desc(reconciliationDiscrepancies.createdAt))
          : [];

      const attemptsByTx = new Map<number, typeof attempts>();
      for (const att of attempts) {
        const list = attemptsByTx.get(att.transactionId) ?? [];
        list.push(att);
        attemptsByTx.set(att.transactionId, list);
      }

      const refundsByTx = new Map<number, typeof userRefunds>();
      for (const ref of userRefunds) {
        const list = refundsByTx.get(ref.transactionId) ?? [];
        list.push(ref);
        refundsByTx.set(ref.transactionId, list);
      }

      const enrichedTransactions = userTransactions.map((t) => ({
        ...t,
        attempts: (attemptsByTx.get(t.id) ?? []).sort((a, b) => a.attemptNumber - b.attemptNumber),
        refunds: refundsByTx.get(t.id) ?? [],
      }));

      const totalTxs = userTransactions.length;
      const settledStatuses = new Set(['SUCCEEDED', 'RECONCILED', 'REFUNDED']);
      const succeededCount = userTransactions.filter((t) => settledStatuses.has(t.status)).length;
      const fraudCount = userTransactions.filter((t) => t.status === 'FLAGGED_FRAUD').length;
      const totalVolumeCents = userTransactions
        .filter((t) => settledStatuses.has(t.status))
        .reduce((acc, t) => acc + t.amountCents, 0);
      const avgLatencyMs =
        totalTxs > 0
          ? Math.round(userTransactions.reduce((acc, t) => acc + t.latencyMs, 0) / totalTxs)
          : 0;

      const sortedLatencies = userTransactions.map((t) => t.latencyMs).sort((a, b) => a - b);
      const getPercentile = (pct: number) => {
        if (sortedLatencies.length === 0) return 0;
        const idx = Math.min(
          sortedLatencies.length - 1,
          Math.max(0, Math.ceil((pct / 100) * sortedLatencies.length) - 1)
        );
        return sortedLatencies[idx];
      };

      const estimatedFeeSavingsCents = userTransactions
        .filter((t) => settledStatuses.has(t.status) && t.feeCents > 0)
        .reduce((acc, t) => {
          const baselineFee = Math.round(t.amountCents * 0.029) + 30;
          return acc + Math.max(0, baselineFee - t.feeCents);
        }, 0);

      const totalRefundedCents = userTransactions.reduce((acc, t) => acc + t.refundedCents, 0);

      const retrySaves = userTransactions.filter(
        (t) => settledStatuses.has(t.status) && t.attemptCount > 1
      ).length;
      const activePolicy = policyRows[0] ?? null;
      const globalLatencyThreshold = activePolicy?.latencyAlertThresholdMs ?? 250;
      const gatewayThresholdMap = new Map(
        allGateways.map((g) => [g.code, g.latencyAlertThresholdMs])
      );
      const latencyBreaches = userTransactions.filter((t) => {
        const threshold =
          (t.selectedGatewayCode && gatewayThresholdMap.get(t.selectedGatewayCode)) ||
          globalLatencyThreshold;
        return t.latencyMs > threshold;
      }).length;

      const currentHourEnd = new Date();
      currentHourEnd.setMinutes(0, 0, 0);
      const bucketMap = new Map<
        number,
        {
          hourIso: string;
          hourLabel: string;
          total: number;
          succeeded: number;
          failed: number;
          stripe: number;
          adyen: number;
          checkout: number;
          razorpay: number;
          braintree: number;
        }
      >();
      const throughput24h: Array<{
        hourIso: string;
        hourLabel: string;
        total: number;
        succeeded: number;
        failed: number;
        stripe: number;
        adyen: number;
        checkout: number;
        razorpay: number;
        braintree: number;
      }> = [];

      for (let i = 23; i >= 0; i--) {
        const slotDate = new Date(currentHourEnd.getTime() - i * 3600_000);
        const key = slotDate.getTime();
        const hh = String(slotDate.getUTCHours()).padStart(2, '0');
        const entry = {
          hourIso: slotDate.toISOString(),
          hourLabel: `${hh}:00`,
          total: 0,
          succeeded: 0,
          failed: 0,
          stripe: 0,
          adyen: 0,
          checkout: 0,
          razorpay: 0,
          braintree: 0,
        };
        bucketMap.set(key, entry);
        throughput24h.push(entry);
      }

      for (const row of txsLast24h) {
        const dt = new Date(row.createdAt);
        dt.setMinutes(0, 0, 0);
        const bucket = bucketMap.get(dt.getTime());
        if (!bucket) continue;
        bucket.total += 1;
        if (settledStatuses.has(row.status)) {
          bucket.succeeded += 1;
        } else {
          bucket.failed += 1;
        }
        const gw = row.selectedGatewayCode;
        if (
          gw === 'stripe' ||
          gw === 'adyen' ||
          gw === 'checkout' ||
          gw === 'razorpay' ||
          gw === 'braintree'
        ) {
          bucket[gw] += 1;
        }
      }

      res.json({
        user,
        gateways: allGateways,
        transactions: enrichedTransactions,
        policy: activePolicy,
        routingRules: userRules,
        refunds: userRefunds,
        webhooks: userWebhooks,
        reconciliationBatches: userBatches,
        discrepancies,
        auditLogs: userAuditLogs,
        throughput24h,
        metrics: {
          totalTransactions: totalTxs,
          successRatePct: totalTxs > 0 ? Number(((succeededCount / totalTxs) * 100).toFixed(1)) : 100,
          totalVolumeCents,
          avgLatencyMs,
          p50LatencyMs: getPercentile(50),
          p95LatencyMs: getPercentile(95),
          p99LatencyMs: getPercentile(99),
          estimatedFeeSavingsCents,
          totalRefundedCents,
          fraudBlocked: fraudCount,
          retrySaves,
          openCircuits: allGateways.filter((g) => g.circuitState === 'OPEN').length,
          queueDepth: eventBus.getQueueDepth(),
          latencyBreaches,
          rateLimiter: getRateLimiterStatus(
            user.id,
            activePolicy?.rateLimitRps ?? 15,
            activePolicy?.rateLimitBurst ?? 25
          ),
        },
      });
    } catch (error) {
      console.error('GET /api/dashboard failed:', error);
      res.status(500).json({ error: 'Failed to load orchestration dashboard.' });
    }
  });

  app.post('/api/payments/dispatch', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const policyRows = await db
        .select()
        .from(routingPolicies)
        .where(eq(routingPolicies.userId, user.id))
        .limit(1);
      const rps = policyRows[0]?.rateLimitRps ?? 15;
      const burst = policyRows[0]?.rateLimitBurst ?? 25;
      const rateDecision = consumeRateLimitToken(user.id, rps, burst);

      if (!rateDecision.allowed) {
        await db.insert(auditLogs).values({
          userId: user.id,
          entityType: 'rate_limiter',
          entityId: String(user.id),
          action: 'RATE_LIMIT_LOAD_SHED',
          actorEmail: user.email,
          metadata: {
            rps: rateDecision.rps,
            capacity: rateDecision.capacity,
            retryAfterMs: rateDecision.retryAfterMs,
            rejectedCount: rateDecision.rejectedCount,
          },
        });
        return res.status(429).json({
          error: `Token-bucket rate limit exceeded (${rateDecision.rps} req/s, burst ${rateDecision.capacity}). Retry in ${rateDecision.retryAfterMs}ms.`,
          code: 'RATE_LIMIT_EXCEEDED',
          retryAfterMs: rateDecision.retryAfterMs,
          rateLimiter: rateDecision,
        });
      }

      const body = req.body ?? {};
      const amountCents = Number(body.amountCents);
      if (!Number.isFinite(amountCents) || amountCents < 100 || amountCents > 50_000_000) {
        return res.status(400).json({ error: 'amountCents must be between 100 and 50,000,000.' });
      }

      const idempotencyKey =
        typeof body.idempotencyKey === 'string' && body.idempotencyKey.trim().length > 0
          ? body.idempotencyKey.trim()
          : `idem_${crypto.randomBytes(6).toString('hex')}`;

      const result = await dispatchPayment({
        userId: user.id,
        actorEmail: user.email,
        idempotencyKey,
        orderRef:
          typeof body.orderRef === 'string' && body.orderRef.trim()
            ? body.orderRef.trim()
            : `ORD-${Math.floor(10000 + Math.random() * 89999)}`,
        amountCents: Math.round(amountCents),
        currency: typeof body.currency === 'string' ? body.currency : 'USD',
        paymentMethod: typeof body.paymentMethod === 'string' ? body.paymentMethod : 'card',
        customerEmail:
          typeof body.customerEmail === 'string' && body.customerEmail.trim()
            ? body.customerEmail.trim()
            : user.email,
        customerCountry: typeof body.customerCountry === 'string' ? body.customerCountry : 'US',
        preferredGatewayCode:
          typeof body.preferredGatewayCode === 'string' && body.preferredGatewayCode !== 'AUTO'
            ? body.preferredGatewayCode
            : undefined,
        forceFailGatewayCode:
          typeof body.forceFailGatewayCode === 'string' && body.forceFailGatewayCode !== 'NONE'
            ? body.forceFailGatewayCode
            : undefined,
      });

      res.json(result);
    } catch (error) {
      if (error instanceof IdempotencyConflictError) {
        return res.status(409).json({ error: error.message, code: 'IDEMPOTENCY_CONFLICT' });
      }
      console.error('POST /api/payments/dispatch failed:', error);
      res.status(500).json({ error: 'Payment orchestration dispatch failed.' });
    }
  });

  app.post('/api/payments/burst', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const scenarios = [
        {
          orderRef: `ORD-${Math.floor(10000 + Math.random() * 89999)}`,
          amountCents: 18900,
          currency: 'USD',
          paymentMethod: 'card',
          customerEmail: 'procurement@vertex-labs.io',
          customerCountry: 'US',
        },
        {
          orderRef: `ORD-${Math.floor(10000 + Math.random() * 89999)}`,
          amountCents: 64200,
          currency: 'EUR',
          paymentMethod: 'sepa_debit',
          customerEmail: 'ap@rhein-logistics.de',
          customerCountry: 'DE',
        },
        {
          orderRef: `ORD-${Math.floor(10000 + Math.random() * 89999)}`,
          amountCents: 31500,
          currency: 'SGD',
          paymentMethod: 'wallet',
          customerEmail: 'finance@harbour-pay.sg',
          customerCountry: 'SG',
        },
        {
          orderRef: `ORD-${Math.floor(10000 + Math.random() * 89999)}`,
          amountCents: 740000,
          currency: 'USD',
          paymentMethod: 'card',
          customerEmail: 'temp_99@disposable-check.xyz',
          customerCountry: 'NG',
        },
      ];

      const results = [];
      for (const s of scenarios) {
        const r = await dispatchPayment({
          userId: user.id,
          actorEmail: user.email,
          idempotencyKey: `idem_burst_${crypto.randomBytes(5).toString('hex')}`,
          ...s,
        });
        results.push(r);
      }

      res.json({ dispatched: results.length, results });
    } catch (error) {
      console.error('POST /api/payments/burst failed:', error);
      res.status(500).json({ error: 'Failed to execute sandbox traffic burst.' });
    }
  });

  app.patch('/api/gateways/:code', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const code = String(req.params.code);
      const body = req.body ?? {};

      const existingRows = await db
        .select()
        .from(gateways)
        .where(eq(gateways.code, code))
        .limit(1);

      if (existingRows.length === 0) {
        return res.status(404).json({ error: 'Gateway not found.' });
      }

      const updates: Partial<typeof gateways.$inferInsert> = {
        updatedAt: new Date(),
      };

      if (typeof body.isActive === 'boolean') updates.isActive = body.isActive;
      if (typeof body.simulatedFailureRate === 'number') {
        updates.simulatedFailureRate = Math.max(0, Math.min(1, body.simulatedFailureRate));
      }
      if (typeof body.simulatedLatencyMs === 'number') {
        updates.simulatedLatencyMs = Math.max(20, Math.min(2000, Math.round(body.simulatedLatencyMs)));
      }
      if (typeof body.latencyAlertThresholdMs === 'number') {
        updates.latencyAlertThresholdMs = Math.max(
          50,
          Math.min(5000, Math.round(body.latencyAlertThresholdMs))
        );
      }
      if (typeof body.errorRateThresholdEnabled === 'boolean') {
        updates.errorRateThresholdEnabled = body.errorRateThresholdEnabled;
      }
      if (
        typeof body.errorRateThresholdPct === 'number' &&
        Number.isFinite(body.errorRateThresholdPct)
      ) {
        const clamped = Math.max(0.5, Math.min(95, body.errorRateThresholdPct));
        updates.errorRateThresholdPct = Math.round(clamped * 10) / 10;
      }
      if (
        typeof body.circuitState === 'string' &&
        ['CLOSED', 'OPEN', 'HALF_OPEN'].includes(body.circuitState)
      ) {
        updates.circuitState = body.circuitState;
        if (body.circuitState === 'CLOSED') {
          updates.failureCount = 0;
          updates.cooldownUntil = null;
        } else if (body.circuitState === 'OPEN') {
          updates.cooldownUntil = new Date(Date.now() + 30_000);
        }
      }

      const [updated] = await db
        .update(gateways)
        .set(updates)
        .where(eq(gateways.code, code))
        .returning();

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'gateway',
        entityId: code,
        action: 'GATEWAY_CONFIGURATION_UPDATED',
        actorEmail: user.email,
        metadata: updates,
      });

      eventBus.publish({
        type: 'circuit:changed',
        payload: { gateway: updated },
      });

      res.json({ gateway: updated });
    } catch (error) {
      console.error('PATCH /api/gateways/:code failed:', error);
      res.status(500).json({ error: 'Failed to update gateway configuration.' });
    }
  });

  app.put('/api/policy', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const body = req.body ?? {};

      const successWeight = Math.max(0, Math.min(1, Number(body.successWeight ?? 0.5)));
      const latencyWeight = Math.max(0, Math.min(1, Number(body.latencyWeight ?? 0.25)));
      const costWeight = Math.max(0, Math.min(1, Number(body.costWeight ?? 0.25)));
      const autoRetryEnabled = Boolean(body.autoRetryEnabled ?? true);
      const maxRetries = Math.max(0, Math.min(4, Math.round(Number(body.maxRetries ?? 2))));
      const fraudThreshold = Math.max(10, Math.min(100, Math.round(Number(body.fraudThreshold ?? 75))));
      const idempotencyTtlSec = Math.max(
        60,
        Math.min(604800, Math.round(Number(body.idempotencyTtlSec ?? 86400)))
      );
      const latencyAlertThresholdMs = Math.max(
        50,
        Math.min(5000, Math.round(Number(body.latencyAlertThresholdMs ?? 250)))
      );
      const rateLimitRps = Math.max(1, Math.min(200, Math.round(Number(body.rateLimitRps ?? 15))));
      const rateLimitBurst = Math.max(
        1,
        Math.min(500, Math.round(Number(body.rateLimitBurst ?? 25)))
      );

      const [updated] = await db
        .insert(routingPolicies)
        .values({
          userId: user.id,
          successWeight,
          latencyWeight,
          costWeight,
          autoRetryEnabled,
          maxRetries,
          fraudThreshold,
          idempotencyTtlSec,
          latencyAlertThresholdMs,
          rateLimitRps,
          rateLimitBurst,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: routingPolicies.userId,
          set: {
            successWeight,
            latencyWeight,
            costWeight,
            autoRetryEnabled,
            maxRetries,
            fraudThreshold,
            idempotencyTtlSec,
            latencyAlertThresholdMs,
            rateLimitRps,
            rateLimitBurst,
            updatedAt: new Date(),
          },
        })
        .returning();

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'routing_policy',
        entityId: String(updated.id),
        action: 'ROUTING_POLICY_UPDATED',
        actorEmail: user.email,
        metadata: {
          successWeight,
          latencyWeight,
          costWeight,
          autoRetryEnabled,
          maxRetries,
          fraudThreshold,
          latencyAlertThresholdMs,
          rateLimitRps,
          rateLimitBurst,
        },
      });

      eventBus.publish({
        type: 'policy:updated',
        userId: user.id,
        payload: { policy: updated },
      });

      res.json({ policy: updated });
    } catch (error) {
      console.error('PUT /api/policy failed:', error);
      res.status(500).json({ error: 'Failed to update routing policy.' });
    }
  });

  app.post('/api/routing-rules', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const body = req.body ?? {};
      const name = String(body.name ?? '').trim();
      if (!name) {
        return res.status(400).json({ error: 'Rule name is required.' });
      }
      const actionType = ['FORCE_GATEWAY', 'CANARY_SPLIT', 'BLOCK_COUNTRY'].includes(
        String(body.actionType)
      )
        ? String(body.actionType)
        : 'FORCE_GATEWAY';
      const targetGatewayCode = String(body.targetGatewayCode || 'stripe').toLowerCase();
      const canaryGatewayCode =
        actionType === 'CANARY_SPLIT' && body.canaryGatewayCode
          ? String(body.canaryGatewayCode).toLowerCase()
          : null;
      const canaryPct =
        actionType === 'CANARY_SPLIT'
          ? Math.max(1, Math.min(99, Math.round(Number(body.canaryPct ?? 20))))
          : 0;

      const [created] = await db
        .insert(routingRules)
        .values({
          userId: user.id,
          name: name.slice(0, 80),
          priority: Math.max(1, Math.min(999, Math.round(Number(body.priority ?? 10)))),
          isActive: body.isActive !== false,
          conditionCurrency: String(body.conditionCurrency || 'ALL').toUpperCase(),
          conditionMethod: String(body.conditionMethod || 'ALL'),
          conditionMinAmountCents: Math.max(
            0,
            Math.round(Number(body.conditionMinAmountCents ?? 0))
          ),
          conditionCountry: String(body.conditionCountry || 'ALL').toUpperCase(),
          actionType,
          targetGatewayCode,
          canaryGatewayCode,
          canaryPct,
        })
        .returning();

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'routing_rule',
        entityId: String(created.id),
        action: 'ROUTING_RULE_CREATED',
        actorEmail: user.email,
        metadata: { name: created.name, actionType: created.actionType },
      });

      res.status(201).json({ rule: created });
    } catch (error) {
      console.error('POST /api/routing-rules failed:', error);
      res.status(500).json({ error: 'Failed to create conditional routing rule.' });
    }
  });

  app.patch('/api/routing-rules/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const ruleId = Number(req.params.id);
      const isActive = Boolean(req.body?.isActive);
      const [updated] = await db
        .update(routingRules)
        .set({ isActive, updatedAt: new Date() })
        .where(and(eq(routingRules.id, ruleId), eq(routingRules.userId, user.id)))
        .returning();

      if (!updated) {
        return res.status(404).json({ error: 'Routing rule not found.' });
      }
      res.json({ rule: updated });
    } catch (error) {
      console.error('PATCH /api/routing-rules/:id failed:', error);
      res.status(500).json({ error: 'Failed to update routing rule.' });
    }
  });

  app.delete('/api/routing-rules/:id', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const ruleId = Number(req.params.id);
      const deleted = await db
        .delete(routingRules)
        .where(and(eq(routingRules.id, ruleId), eq(routingRules.userId, user.id)))
        .returning();

      if (deleted.length === 0) {
        return res.status(404).json({ error: 'Routing rule not found.' });
      }

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'routing_rule',
        entityId: String(ruleId),
        action: 'ROUTING_RULE_DELETED',
        actorEmail: user.email,
        metadata: { name: deleted[0].name },
      });

      res.json({ deletedId: ruleId });
    } catch (error) {
      console.error('DELETE /api/routing-rules/:id failed:', error);
      res.status(500).json({ error: 'Failed to delete routing rule.' });
    }
  });

  app.post('/api/ai/synthesize-rule', requireAuth, async (req: AuthRequest, res) => {
    try {
      const instruction = String(req.body?.instruction ?? '').trim();
      if (!instruction) {
        return res.status(400).json({ error: 'Rule instruction is required.' });
      }
      const result = await synthesizeRoutingRule(instruction);
      res.json(result);
    } catch (error: any) {
      console.error('POST /api/ai/synthesize-rule failed:', error);
      res.status(500).json({
        error:
          error?.message ||
          'Failed to synthesize rule with Gemini. Verify GEMINI_API_KEY in Settings > Secrets.',
      });
    }
  });

  app.post('/api/payments/:id/refund', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const txId = Number(req.params.id);
      const amountCents = Number(req.body?.amountCents);
      const reason = String(req.body?.reason ?? 'Operator-initiated refund');

      const result = await issueTransactionRefund(user.id, user.email, txId, amountCents, reason);
      res.json(result);
    } catch (error) {
      if (error instanceof RefundValidationError) {
        return res.status(error.statusCode).json({ error: error.message });
      }
      console.error('POST /api/payments/:id/refund failed:', error);
      res.status(500).json({ error: 'Failed to issue payment refund.' });
    }
  });

  app.post('/api/webhooks/:id/retry', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const webhookId = Number(req.params.id);
      const rows = await db
        .select()
        .from(webhookEvents)
        .where(eq(webhookEvents.id, webhookId))
        .limit(1);

      if (rows.length === 0 || rows[0].userId !== user.id) {
        return res.status(404).json({ error: 'Webhook event not found.' });
      }

      const evt = rows[0];
      const expectedSig = crypto
        .createHmac('sha256', 'paymatrix_sandbox_webhook_secret')
        .update(JSON.stringify(evt.payload))
        .digest('hex');

      const sigValid = evt.hmacSignature === expectedSig;
      const [updated] = await db
        .update(webhookEvents)
        .set({
          attemptCount: evt.attemptCount + 1,
          signatureValid: sigValid,
          deliveryStatus: sigValid ? 'DELIVERED' : 'DEAD_LETTER',
        })
        .where(eq(webhookEvents.id, webhookId))
        .returning();

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'webhook',
        entityId: evt.eventCode,
        action: sigValid ? 'WEBHOOK_REPLAY_DELIVERED' : 'WEBHOOK_MOVED_TO_DLQ_INVALID_HMAC',
        actorEmail: user.email,
        metadata: { attemptCount: updated.attemptCount, signatureValid: sigValid },
      });

      eventBus.publish({
        type: 'webhook:delivered',
        userId: user.id,
        payload: { webhook: updated },
      });

      res.json({ webhook: updated });
    } catch (error) {
      console.error('POST /api/webhooks/:id/retry failed:', error);
      res.status(500).json({ error: 'Failed to retry webhook delivery.' });
    }
  });

  app.post('/api/webhooks/simulate-inbound', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const body = req.body ?? {};
      const gatewayCode = typeof body.gatewayCode === 'string' ? body.gatewayCode : 'stripe';
      const eventType = typeof body.eventType === 'string' ? body.eventType : 'charge.captured';
      const tamperSignature = Boolean(body.tamperSignature);

      const payload = {
        providerEventId: `wh_${crypto.randomBytes(6).toString('hex')}`,
        gatewayCode,
        eventType,
        receivedAt: new Date().toISOString(),
        amountCents: Number(body.amountCents ?? 25000),
        currency: 'USD',
      };

      const validSig = crypto
        .createHmac('sha256', 'paymatrix_sandbox_webhook_secret')
        .update(JSON.stringify(payload))
        .digest('hex');

      const incomingSig = tamperSignature
        ? validSig.replace(/^./, validSig[0] === 'a' ? 'b' : 'a')
        : validSig;

      const signatureValid = incomingSig === validSig;
      const [inserted] = await db
        .insert(webhookEvents)
        .values({
          eventCode: `evt_${crypto.randomBytes(5).toString('hex')}`,
          userId: user.id,
          gatewayCode,
          eventType,
          deliveryStatus: signatureValid ? 'DELIVERED' : 'DEAD_LETTER',
          signatureValid,
          hmacSignature: incomingSig,
          attemptCount: 1,
          payload,
        })
        .returning();

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'webhook',
        entityId: inserted.eventCode,
        action: signatureValid ? 'INBOUND_WEBHOOK_VERIFIED' : 'INBOUND_WEBHOOK_HMAC_REJECTED',
        actorEmail: user.email,
        metadata: { gatewayCode, eventType, signatureValid },
      });

      eventBus.publish({
        type: 'webhook:delivered',
        userId: user.id,
        payload: { webhook: inserted },
      });

      res.json({ webhook: inserted });
    } catch (error) {
      console.error('POST /api/webhooks/simulate-inbound failed:', error);
      res.status(500).json({ error: 'Failed to process inbound webhook simulation.' });
    }
  });

  app.post('/api/reconciliation/run', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const body = req.body ?? {};
      const gatewayCode = typeof body.gatewayCode === 'string' ? body.gatewayCode : 'ALL';
      const injectDiscrepancy = Boolean(body.injectDiscrepancy);
      const outcome = await runAutomaticReconciliation(
        user.id,
        user.email,
        gatewayCode,
        injectDiscrepancy
      );
      res.json(outcome);
    } catch (error) {
      console.error('POST /api/reconciliation/run failed:', error);
      res.status(500).json({ error: 'Failed to execute automatic reconciliation.' });
    }
  });

  app.post(
    '/api/reconciliation/discrepancies/:id/resolve',
    requireAuth,
    async (req: AuthRequest, res) => {
      try {
        const user = req.dbUser!;
        const discId = Number(req.params.id);
        const resolutionNote =
          typeof req.body?.resolutionNote === 'string' && req.body.resolutionNote.trim()
            ? req.body.resolutionNote.trim()
            : 'Verified provider fee adjustment and reconciled ledger.';

        const discRows = await db
          .select()
          .from(reconciliationDiscrepancies)
          .where(eq(reconciliationDiscrepancies.id, discId))
          .limit(1);

        if (discRows.length === 0) {
          return res.status(404).json({ error: 'Discrepancy record not found.' });
        }

        const disc = discRows[0];
        const batchRows = await db
          .select()
          .from(reconciliationBatches)
          .where(eq(reconciliationBatches.id, disc.batchId))
          .limit(1);

        if (batchRows.length === 0 || batchRows[0].userId !== user.id) {
          return res.status(403).json({ error: 'Forbidden: Discrepancy belongs to another user.' });
        }

        const [updated] = await db
          .update(reconciliationDiscrepancies)
          .set({ resolved: true, resolutionNote })
          .where(eq(reconciliationDiscrepancies.id, discId))
          .returning();

        await db
          .update(transactions)
          .set({ status: 'RECONCILED', reconciledAt: new Date(), updatedAt: new Date() })
          .where(eq(transactions.id, disc.transactionId));

        const remaining = await db
          .select()
          .from(reconciliationDiscrepancies)
          .where(eq(reconciliationDiscrepancies.batchId, disc.batchId));

        if (remaining.every((r) => r.resolved)) {
          await db
            .update(reconciliationBatches)
            .set({ status: 'RESOLVED' })
            .where(eq(reconciliationBatches.id, disc.batchId));
        }

        await db.insert(auditLogs).values({
          userId: user.id,
          entityType: 'reconciliation_discrepancy',
          entityId: String(discId),
          action: 'DISCREPANCY_MANUALLY_RESOLVED',
          actorEmail: user.email,
          metadata: { transactionId: disc.transactionId, resolutionNote },
        });

        res.json({ discrepancy: updated });
      } catch (error) {
        console.error('POST /api/reconciliation/discrepancies/:id/resolve failed:', error);
        res.status(500).json({ error: 'Failed to resolve reconciliation discrepancy.' });
      }
    }
  );

  app.post('/api/ai/fraud-triage', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const txId = Number(req.body?.transactionId);
      const txRows = await db
        .select()
        .from(transactions)
        .where(eq(transactions.id, txId))
        .limit(1);

      if (txRows.length === 0 || txRows[0].userId !== user.id) {
        return res.status(404).json({ error: 'Transaction not found.' });
      }
      const tx = txRows[0];
      const result = await runFastFraudTriage({
        txCode: tx.txCode,
        amountCents: tx.amountCents,
        currency: tx.currency,
        customerEmail: tx.customerEmail,
        customerCountry: tx.customerCountry,
        paymentMethod: tx.paymentMethod,
        riskScore: tx.riskScore,
        riskReason: tx.riskReason ?? 'Nominal',
        selectedGatewayCode: tx.selectedGatewayCode ?? 'unassigned',
      });

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'ai_triage',
        entityId: tx.txCode,
        action: 'FAST_FRAUD_TRIAGE_EXECUTED',
        actorEmail: user.email,
        metadata: { model: result.model, latencyMs: result.latencyMs },
      });

      res.json(result);
    } catch (error: any) {
      console.error('POST /api/ai/fraud-triage failed:', error);
      res.status(500).json({
        error:
          error?.message ||
          'Gemini fraud triage failed. Verify GEMINI_API_KEY in Settings > Secrets.',
      });
    }
  });

  app.post('/api/ai/deep-diagnose', requireAuth, async (req: AuthRequest, res) => {
    try {
      const user = req.dbUser!;
      const question = String(req.body?.question ?? '').trim();
      if (!question) {
        return res.status(400).json({ error: 'Diagnostic question is required.' });
      }

      const [allGateways, recentTxs, policyRows, batches] = await Promise.all([
        db.select().from(gateways),
        db
          .select()
          .from(transactions)
          .where(eq(transactions.userId, user.id))
          .orderBy(desc(transactions.createdAt))
          .limit(20),
        db.select().from(routingPolicies).where(eq(routingPolicies.userId, user.id)).limit(1),
        db
          .select()
          .from(reconciliationBatches)
          .where(eq(reconciliationBatches.userId, user.id)),
      ]);

      const batchIds = batches.map((b) => b.id);
      const openDiscrepancies =
        batchIds.length > 0
          ? await db
              .select()
              .from(reconciliationDiscrepancies)
              .where(inArray(reconciliationDiscrepancies.batchId, batchIds))
          : [];

      const policy = policyRows[0] ?? {
        successWeight: 0.5,
        latencyWeight: 0.25,
        costWeight: 0.25,
        maxRetries: 2,
        fraudThreshold: 75,
      };

      const result = await runDeepIncidentDiagnosis({
        question,
        gateways: allGateways,
        recentTransactions: recentTxs,
        discrepancies: openDiscrepancies,
        policy,
      });

      await db.insert(auditLogs).values({
        userId: user.id,
        entityType: 'ai_diagnosis',
        entityId: `diag_${Date.now()}`,
        action: 'DEEP_THINKING_DIAGNOSIS_EXECUTED',
        actorEmail: user.email,
        metadata: {
          model: result.model,
          thinkingLevel: result.thinkingLevel,
          latencyMs: result.latencyMs,
        },
      });

      res.json(result);
    } catch (error: any) {
      console.error('POST /api/ai/deep-diagnose failed:', error);
      res.status(500).json({
        error:
          error?.message ||
          'Gemini deep diagnostic failed. Verify GEMINI_API_KEY in Settings > Secrets.',
      });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`PayMatrix server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
  process.exit(1);
});
