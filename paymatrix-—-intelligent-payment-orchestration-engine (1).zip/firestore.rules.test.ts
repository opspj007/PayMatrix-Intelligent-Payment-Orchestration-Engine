import { readFileSync } from 'node:fs';

/**
 * Dirty Dozen security verification suite specification for PayMatrix Firestore rules.
 * Designed for execution against @firebase/rules-unit-testing when emulator is running.
 */
export const dirtyDozenCases = [
  {
    name: '01. Cross-user profile read denied',
    path: 'users/userA/private/profile',
    actorUid: 'userB',
    operation: 'get',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '02. Unverified email spoof denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    emailVerified: false,
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '03. Shadow field injection denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    operation: 'create',
    payload: {
      userId: 'userA',
      name: 'Malicious',
      successWeight: 0.5,
      latencyWeight: 0.25,
      costWeight: 0.25,
      fraudThreshold: 75,
      maxRetries: 2,
      isAdmin: true,
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '04. Identity spoofing in payload denied',
    path: 'users/userB/presets/preset_1',
    actorUid: 'userB',
    operation: 'create',
    payload: {
      userId: 'userA',
      name: 'Spoofed',
      successWeight: 0.5,
      latencyWeight: 0.25,
      costWeight: 0.25,
      fraudThreshold: 75,
      maxRetries: 2,
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '05. Client-forged timestamp denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    operation: 'create',
    forgedTimestamp: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '06. Path variable ID poisoning denied',
    path: 'users/userA/presets/' + 'a'.repeat(200),
    actorUid: 'userA',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '07. Out-of-bounds routing weight denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    operation: 'create',
    payload: {
      userId: 'userA',
      name: 'Overflow',
      successWeight: 99,
      latencyWeight: 0.25,
      costWeight: 0.25,
      fraudThreshold: 75,
      maxRetries: 2,
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '08. Type poisoning on update denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    operation: 'update',
    payload: { fraudThreshold: 'high' },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '09. Immutable createdAt mutation denied',
    path: 'users/userA/presets/preset_1',
    actorUid: 'userA',
    operation: 'update',
    mutateCreatedAt: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '10. Oversized investigation summary DoS denied',
    path: 'users/userA/investigations/inv_1',
    actorUid: 'userA',
    operation: 'create',
    payload: {
      userId: 'userA',
      title: 'Oversized',
      modelUsed: 'gemini-4-hydrogen',
      summary: 'x'.repeat(20000),
    },
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '11. Cross-user list scraping denied',
    path: 'users/userA/investigations',
    actorUid: 'userB',
    operation: 'list',
    expected: 'PERMISSION_DENIED',
  },
  {
    name: '12. Unmatched collection write denied',
    path: 'admins/userB',
    actorUid: 'userB',
    operation: 'create',
    expected: 'PERMISSION_DENIED',
  },
];

export function verifyRulesFileExists(): string {
  return readFileSync('firestore.rules', 'utf8');
}
